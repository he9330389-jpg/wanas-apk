-- WANAS database schema. The server creates this automatically on first start;
-- you only need to paste it into the Supabase SQL editor if you prefer to create it by hand.

create table if not exists wanas_users (
  id text primary key,
  owner text,
  ts bigint not null default 0,
  data jsonb not null
);
create index if not exists wanas_users_ts_idx on wanas_users (ts desc);
create index if not exists wanas_users_owner_idx on wanas_users (owner);
alter table wanas_users enable row level security;
create table if not exists wanas_posts (
  id text primary key,
  owner text,
  ts bigint not null default 0,
  data jsonb not null
);
create index if not exists wanas_posts_ts_idx on wanas_posts (ts desc);
create index if not exists wanas_posts_owner_idx on wanas_posts (owner);
alter table wanas_posts enable row level security;
create table if not exists wanas_stories (
  id text primary key,
  owner text,
  ts bigint not null default 0,
  data jsonb not null
);
create index if not exists wanas_stories_ts_idx on wanas_stories (ts desc);
create index if not exists wanas_stories_owner_idx on wanas_stories (owner);
alter table wanas_stories enable row level security;
create table if not exists wanas_rooms (
  id text primary key,
  owner text,
  ts bigint not null default 0,
  data jsonb not null
);
create index if not exists wanas_rooms_ts_idx on wanas_rooms (ts desc);
create index if not exists wanas_rooms_owner_idx on wanas_rooms (owner);
alter table wanas_rooms enable row level security;
create table if not exists wanas_room_messages (
  id text primary key,
  owner text,
  ts bigint not null default 0,
  data jsonb not null
);
create index if not exists wanas_room_messages_ts_idx on wanas_room_messages (ts desc);
create index if not exists wanas_room_messages_owner_idx on wanas_room_messages (owner);
alter table wanas_room_messages enable row level security;
create table if not exists wanas_direct_messages (
  id text primary key,
  owner text,
  ts bigint not null default 0,
  data jsonb not null
);
create index if not exists wanas_direct_messages_ts_idx on wanas_direct_messages (ts desc);
create index if not exists wanas_direct_messages_owner_idx on wanas_direct_messages (owner);
alter table wanas_direct_messages enable row level security;
create table if not exists wanas_news (
  id text primary key,
  owner text,
  ts bigint not null default 0,
  data jsonb not null
);
create index if not exists wanas_news_ts_idx on wanas_news (ts desc);
create index if not exists wanas_news_owner_idx on wanas_news (owner);
alter table wanas_news enable row level security;
create table if not exists wanas_credentials (
  user_id text primary key,
  email text unique,
  phone text unique,
  password_hash text not null,
  created_at timestamptz not null default now()
);
alter table wanas_credentials enable row level security;
create table if not exists wanas_meta (
  key text primary key,
  value text not null
);
alter table wanas_meta enable row level security;
