package app.wanas.social;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
