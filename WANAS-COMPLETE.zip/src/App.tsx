import React, { useState, useEffect, useRef } from 'react';
import {
  Home,
  Video,
  Radio,
  MessageSquare,
  Menu,
  MessageCircle,
  Bookmark,
  Send,
  Plus,
  Sun,
  Moon,
  X,
  RefreshCw,
  Flame,
  MoreVertical,
  Link2,
  Share2,
  Flag,
  Pin,
  Trash2,
  Mic,
  FileAudio,
  Image as ImageIcon,
  Film,
  Globe,
  Square,
  User as UserIcon,
  Lock,
  ExternalLink,
  Newspaper,
  Camera,
  Repeat2,
  Download,
  Copy,
  Sparkles,
  BarChart2,
  Bell,
  Search,
  Users,
  Shield,
  CheckCircle2,
  PhoneOff,
  MicOff,
  WifiOff,
} from 'lucide-react';
import type {
  Language,
  Post,
  PostAudience,
  ReactionType,
  StoryItem,
  MajlisRoom,
  DirectMessage,
  User,
  NewsItem,
  NotificationItem,
  CommunityPage,
} from './types.ts';
import {
  DEFAULT_USER_SETTINGS,
  DEFAULT_USERS,
  DEFAULT_STORIES,
  DEFAULT_POSTS,
  DEFAULT_ROOMS,
  DEFAULT_DIRECT_MESSAGES,
  DEFAULT_NEWS,
  DEFAULT_COMMUNITY_PAGES,
} from './defaultData.ts';
import {
  WanasBrandIcon,
  UserAvatar,
  PostMediaVisual,
  CoverBannerVisual,
  AudioWavePlayer,
} from './components/VisualAssets.tsx';
import { MajlisRoomsView } from './components/MajlisRoomsView.tsx';
import { DirectMessagesView } from './components/DirectMessagesView.tsx';
import { AuthView } from './components/AuthView.tsx';
import { CommentsSheetModal } from './components/CommentsSheetModal.tsx';
import { CreateStoryModal } from './components/CreateStoryModal.tsx';
import { VideosView } from './components/VideosView.tsx';
import { ProfileView } from './components/ProfileView.tsx';
import { SettingsView } from './components/SettingsView.tsx';
import { PhotoStudioModal } from './components/PhotoStudioModal.tsx';
import { ReactionPickerBar } from './components/ReactionPickerBar.tsx';
import { ShareToFriendsModal } from './components/ShareToFriendsModal.tsx';
import { StartupSplashModal } from './components/StartupSplashModal.tsx';
import { PeopleDiscoverySection } from './components/PeopleDiscoverySection.tsx';
import { UniversalSearchModal } from './components/UniversalSearchModal.tsx';
import {
  readFileAsCompressedDataUrl,
  readMediaFileWithDuration,
  downloadMediaToDevice,
  getApiUrl,
  getWsUrl,
} from './utils/mediaUtils.ts';
import { formatDynamicTime, formatUserPresence } from './utils/timeUtils.ts';
import { idbGet, idbSet } from './utils/storageDB.ts';
import { realtime } from './utils/realtime.ts';
import { getToken, clearToken } from './utils/auth.ts';
import { useRoomVoice } from './hooks/useRoomVoice.ts';
import { AppDrawer, CreateSheet } from './components/AppDrawer.tsx';

type MainTab = 'feed' | 'videos' | 'rooms' | 'messages' | 'settings' | 'profile';

const TRENDING_HASHTAGS = ['#ونس', '#فيديو', '#المجلس', '#تقنية', '#مصر'];

export function App() {
  const [authUser, setAuthUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem('wanas_auth_user_v3');
      // A saved profile without a server session token comes from an older version: ask for a fresh login.
      if (saved && getToken()) {
        const { password: _legacyPassword, ...parsed } = JSON.parse(saved) as User;
        return {
          ...parsed,
          settings: { ...DEFAULT_USER_SETTINGS, ...(parsed.settings || {}) },
        };
      }
      return null;
    } catch {
      return null;
    }
  });

  const [lang, setLang] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem('wanas_lang');
      return saved === 'en' ? 'en' : 'ar';
    } catch {
      return 'ar';
    }
  });

  const [darkMode, setDarkMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('wanas_theme');
      return saved ? saved === 'dark' : false;
    } catch {
      return false;
    }
  });

  const [activeTab, setActiveTab] = useState<MainTab>('feed');
  const [showStartupSplash, setShowStartupSplash] = useState<boolean>(true);
  const [showUniversalSearchModal, setShowUniversalSearchModal] =
    useState<boolean>(false);
  const [selectedDmUserId, setSelectedDmUserId] = useState<string | null>(null);

  const [users, setUsers] = useState<User[]>(() => {
    try {
      const saved = localStorage.getItem('wanas_users_v3');
      if (saved) {
        const parsed = JSON.parse(saved) as User[];
        const map = new Map<string, User>();
        [...DEFAULT_USERS, ...(Array.isArray(parsed) ? parsed : [])].forEach(
          ({ password: _legacyPassword, ...u }: User) => map.set(u.id, u)
        );
        return Array.from(map.values());
      }
    } catch {
      // ignore
    }
    return DEFAULT_USERS;
  });

  const [communityPages, setCommunityPages] = useState<CommunityPage[]>(() => {
    try {
      const saved = localStorage.getItem('wanas_pages_v3');
      if (saved) {
        const parsed = JSON.parse(saved) as CommunityPage[];
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // ignore
    }
    return DEFAULT_COMMUNITY_PAGES;
  });

  useEffect(() => {
    try {
      localStorage.setItem('wanas_pages_v3', JSON.stringify(communityPages));
    } catch {
      // ignore
    }
  }, [communityPages]);

  const [stories, setStories] = useState<StoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('wanas_stories_v3');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return DEFAULT_STORIES;
  });

  const [posts, setPosts] = useState<Post[]>(() => {
    try {
      const saved = localStorage.getItem('wanas_posts_v3');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return DEFAULT_POSTS;
  });

  const [rooms, setRooms] = useState<MajlisRoom[]>(
    DEFAULT_ROOMS.map((r) => ({ ...r, participants: [] }))
  );
  const [directMessages, setDirectMessages] = useState<DirectMessage[]>(
    DEFAULT_DIRECT_MESSAGES
  );
  const [news, setNews] = useState<NewsItem[]>(DEFAULT_NEWS);

  // Live Clock Tick so relative timestamps ("منذ دقيقة", "منذ دقيقتين", etc.) update automatically
  const [nowTick, setNowTick] = useState<number>(() => Date.now());
  useEffect(() => {
    const id = window.setInterval(() => {
      setNowTick(Date.now());
    }, 20000);
    return () => window.clearInterval(id);
  }, []);

  // Load high-capacity IndexedDB state on startup (for large videos/audio clips)
  useEffect(() => {
    idbGet<Post[]>('wanas_posts_idb').then((savedPosts) => {
      if (Array.isArray(savedPosts) && savedPosts.length > 0) {
        setPosts((prev) => {
          const map = new Map<string, Post>();
          [...savedPosts, ...prev].forEach((p) => map.set(p.id, p));
          return Array.from(map.values()).sort(
            (a, b) => (b.createdAtMs || 0) - (a.createdAtMs || 0)
          );
        });
      }
    });
    idbGet<StoryItem[]>('wanas_stories_idb').then((savedStories) => {
      if (Array.isArray(savedStories) && savedStories.length > 0) {
        setStories((prev) => {
          const map = new Map<string, StoryItem>();
          [...savedStories, ...prev].forEach((s) => map.set(s.id, s));
          return Array.from(map.values()).sort(
            (a, b) => (b.createdAtMs || 0) - (a.createdAtMs || 0)
          );
        });
      }
    });
  }, []);

  // Sync user, posts, stories to both localStorage and IndexedDB
  useEffect(() => {
    try {
      localStorage.setItem('wanas_users_v3', JSON.stringify(users));
    } catch {
      // ignore
    }
    idbSet('wanas_users_idb', users);
  }, [users]);

  useEffect(() => {
    try {
      localStorage.setItem('wanas_posts_v3', JSON.stringify(posts));
    } catch {
      // If video/audio exceeds 5MB localStorage, IndexedDB stores it completely
    }
    idbSet('wanas_posts_idb', posts);
  }, [posts]);

  useEffect(() => {
    try {
      localStorage.setItem('wanas_stories_v3', JSON.stringify(stories));
    } catch {
      // ignore
    }
    idbSet('wanas_stories_idb', stories);
  }, [stories]);

  // Search, Hashtag Filter, and Notifications Bell
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeHashtag, setActiveHashtag] = useState<string | null>(null);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [showNotificationsMenu, setShowNotificationsMenu] =
    useState<boolean>(false);

  const pushNotification = (
    item: Omit<NotificationItem, 'id' | 'createdAtMs' | 'isRead'>
  ) => {
    const newNotif: NotificationItem = {
      ...item,
      id: `notif_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      createdAtMs: Date.now(),
      isRead: false,
    };
    setNotifications((prev) => [newNotif, ...prev.slice(0, 29)]);
  };

  // Double-tap / double-click on Home ("الرئيسية") to refresh
  const lastHomeTapRef = useRef<number>(0);
  const [isRefreshingAll, setIsRefreshingAll] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 3200);
  };

  // Story Viewer & Creator
  const [activeStory, setActiveStory] = useState<StoryItem | null>(null);
  const [showCreateStoryModal, setShowCreateStoryModal] =
    useState<boolean>(false);

  // Full Comments Sheet Modal
  const [commentsPostId, setCommentsPostId] = useState<string | null>(null);

  // Share to Multiple Friends Modal
  const [shareModalPost, setShareModalPost] = useState<Post | null>(null);

  // Quick Photo Studio Modal from Home Sidebar ('avatar' | 'cover' | null)
  const [homePhotoStudioTarget, setHomePhotoStudioTarget] = useState<
    'avatar' | 'cover' | null
  >(null);

  // 3-Dots Post Menu
  const [openMenuPostId, setOpenMenuPostId] = useState<string | null>(null);

  // Multi-Media Post Composer State
  const [newPostContent, setNewPostContent] = useState<string>('');
  const [newPostAudience, setNewPostAudience] =
    useState<PostAudience>('public');
  const [newPostImageUrl, setNewPostImageUrl] = useState<string | null>(null);
  const [newPostVideoUrl, setNewPostVideoUrl] = useState<string | null>(null);
  const [newPostVideoDuration, setNewPostVideoDuration] =
    useState<string>('0:30');
  const [newPostAudioUrl, setNewPostAudioUrl] = useState<string | null>(null);
  const [newPostAudioDuration, setNewPostAudioDuration] =
    useState<string>('0:15');
  const [newPostAudioTitle, setNewPostAudioTitle] = useState<string>('');
  const [newPostLinkUrl, setNewPostLinkUrl] = useState<string>('');
  const [showLinkInput, setShowLinkInput] = useState<boolean>(false);

  // Poll Builder in Post Composer
  const [showPollBuilder, setShowPollBuilder] = useState<boolean>(false);
  const [pollQuestion, setPollQuestion] = useState<string>('');
  const [pollOptions, setPollOptions] = useState<string[]>(['', '']);

  // AI Assistant in Post Composer & Feed
  const [isAiAssisting, setIsAiAssisting] = useState<boolean>(false);
  const [aiSummaryByPostId, setAiSummaryByPostId] = useState<
    Record<string, string>
  >({});

  // Live voice recording for Post Composer
  const [isRecordingPostVoice, setIsRecordingPostVoice] =
    useState<boolean>(false);
  const [postRecordSeconds, setPostRecordSeconds] = useState<number>(0);
  const postRecorderRef = useRef<MediaRecorder | null>(null);
  const postChunksRef = useRef<Blob[]>([]);
  const postTimerRef = useRef<number | null>(null);

  // News Filter inside Merged Home Feed
  const [showNewsSectionInFeed, setShowNewsSectionInFeed] =
    useState<boolean>(true);

  const isAr = lang === 'ar';

  const currentUser: User =
    (authUser && users.find((u) => u.id === authUser.id)) ||
    authUser || {
      id: 'u_guest',
      name: 'مستخدم ونس',
      nameEn: 'WANAS Member',
      handle: '@wanas_member',
      avatarKey: 'abdallah',
      coverKey: 'royal_majlis',
      role: 'عضو في مجتمع ونس',
      roleEn: 'WANAS Community Member',
      bio: 'أهلاً بكم في حسابي الرسمي على منصة ونس للتواصل الاجتماعي.',
      bioEn: 'Welcome to my official profile on WANAS.',
      followersCount: 0,
      followingCount: 0,
      isFollowing: false,
      isOnline: true,
      lastActiveAtMs: Date.now(),
      settings: DEFAULT_USER_SETTINGS,
    };

  // Real voice: the room I'm currently sitting in (the server allows one at a time)
  const myRoom =
    rooms.find((r) => r.participants.some((p) => p.userId === currentUser.id)) || null;
  const voice = useRoomVoice(myRoom, currentUser.id);
  useEffect(() => {
    if (myRoom) wantedRoomRef.current = myRoom.id;
  }, [myRoom?.id]);

  const [showDrawer, setShowDrawer] = useState<boolean>(false);
  const [showCreateSheet, setShowCreateSheet] = useState<boolean>(false);
  const [openRoomCreateSignal, setOpenRoomCreateSignal] = useState<number>(0);

  // Unread direct messages badge
  const [dmSeenAt, setDmSeenAt] = useState<number>(() => {
    try {
      const saved = Number(localStorage.getItem('wanas_dm_seen_v1'));
      return saved > 0 ? saved : Date.now();
    } catch {
      return Date.now();
    }
  });
  useEffect(() => {
    if (activeTab !== 'messages') return;
    const now = Date.now();
    setDmSeenAt(now);
    try {
      localStorage.setItem('wanas_dm_seen_v1', String(now));
    } catch {
      // ignore
    }
  }, [activeTab, directMessages.length]);
  const unreadDmCount = directMessages.filter(
    (m) =>
      m.receiverId === currentUser.id &&
      m.senderId !== currentUser.id &&
      (m.createdAtMs || 0) > dmSeenAt
  ).length;
  const hasLiveRooms = rooms.some((r) => r.participants.length > 0);

  // Sync Dark Mode with document root
  useEffect(() => {
    const root = document.documentElement;
    if (darkMode) {
      root.classList.add('dark');
      root.style.colorScheme = 'dark';
    } else {
      root.classList.remove('dark');
      root.style.colorScheme = 'light';
    }
    try {
      localStorage.setItem('wanas_theme', darkMode ? 'dark' : 'light');
    } catch {
      // ignore
    }
  }, [darkMode]);

  useEffect(() => {
    try {
      localStorage.setItem('wanas_lang', lang);
    } catch {
      // ignore
    }
  }, [lang]);

  // ---- Live backend: REST snapshot + one shared WebSocket (feed events, DMs, voice rooms) ----
  const langRef = useRef<Language>(lang);
  langRef.current = lang;
  const toastRef = useRef<(m: string) => void>(() => {});
  toastRef.current = showToast;
  const wantedRoomRef = useRef<string | null>(null);
  const logoutRef = useRef<() => void>(() => {});
  const applyStateRef = useRef<(d: any) => void>(() => {});
  const [wsConnected, setWsConnected] = useState<boolean>(false);
  const [showOfflineBanner, setShowOfflineBanner] = useState<boolean>(false);

  const mergeUserRecord = (old: User | undefined, incoming: User): User => {
    const { password: _pw, ...clean } = incoming as User;
    return old
      ? { ...old, ...clean, email: clean.email ?? old.email, phone: clean.phone ?? old.phone }
      : clean;
  };

  useEffect(() => {
    const byNewest = (a: { createdAtMs?: number }, b: { createdAtMs?: number }) =>
      (b.createdAtMs || 0) - (a.createdAtMs || 0);

    const applyState = (data: any) => {
      if (!data) return;
      if (Array.isArray(data.users) && data.users.length > 0) {
        setUsers((prev) => {
          const map = new Map<string, User>(prev.map((u) => [u.id, u]));
          data.users.forEach((u: User) => map.set(u.id, mergeUserRecord(map.get(u.id), u)));
          return Array.from(map.values());
        });
      }
      if (Array.isArray(data.posts) && data.posts.length > 0) {
        setPosts((prev) => {
          const map = new Map<string, Post>();
          [...prev, ...data.posts].forEach((p: Post) => map.set(p.id, p));
          return Array.from(map.values()).sort(byNewest);
        });
      }
      if (Array.isArray(data.stories) && data.stories.length > 0) {
        setStories((prev) => {
          const map = new Map<string, StoryItem>();
          [...prev, ...data.stories].forEach((s: StoryItem) => map.set(s.id, s));
          return Array.from(map.values()).sort(byNewest);
        });
      }
      if (Array.isArray(data.rooms)) setRooms(data.rooms);
      if (Array.isArray(data.news) && data.news.length > 0) setNews(data.news);
      if (Array.isArray(data.directMessages) && data.directMessages.length > 0) {
        setDirectMessages((prev) => {
          const map = new Map<string, DirectMessage>();
          [...prev, ...data.directMessages].forEach((m: DirectMessage) => map.set(m.id, m));
          return Array.from(map.values()).sort(
            (a, b) => (a.createdAtMs || 0) - (b.createdAtMs || 0)
          );
        });
      }
    };
    applyStateRef.current = applyState;

    fetch(getApiUrl('/api/state'))
      .then((res) => (res.ok ? res.json() : null))
      .then(applyState)
      .catch(() => {});

    const offs = [
      realtime.on('init', applyState),
      realtime.on('state:refreshed', applyState),
      realtime.on('news:created', (p: NewsItem) =>
        setNews((prev) => (prev.some((n) => n.id === p.id) ? prev : [p, ...prev]))
      ),
      realtime.on('post:created', (p: Post) =>
        setPosts((prev) => (prev.some((x) => x.id === p.id) ? prev : [p, ...prev]))
      ),
      realtime.on('post:updated', (p: Post) =>
        setPosts((prev) => prev.map((x) => (x.id === p.id ? p : x)))
      ),
      realtime.on('post:deleted', (p: { id: string }) =>
        setPosts((prev) => prev.filter((x) => x.id !== p.id))
      ),
      realtime.on('story:created', (p: StoryItem) =>
        setStories((prev) => (prev.some((x) => x.id === p.id) ? prev : [p, ...prev]))
      ),
      realtime.on('user:updated', (p: User) =>
        setUsers((prev) =>
          prev.some((u) => u.id === p.id)
            ? prev.map((u) => (u.id === p.id ? mergeUserRecord(u, p) : u))
            : [mergeUserRecord(undefined, p), ...prev]
        )
      ),
      realtime.on('room:created', (p: MajlisRoom) =>
        setRooms((prev) => (prev.some((r) => r.id === p.id) ? prev : [p, ...prev]))
      ),
      realtime.on('room:deleted', (p: { id: string }) =>
        setRooms((prev) => prev.filter((r) => r.id !== p.id))
      ),
      realtime.on('room:participants', (p: { roomId: string; participants: MajlisRoom['participants'] }) =>
        setRooms((prev) =>
          prev.map((r) => (r.id === p.roomId ? { ...r, participants: p.participants } : r))
        )
      ),
      realtime.on('room:message', (p: { roomId: string; message: MajlisRoom['messages'][number] }) =>
        setRooms((prev) =>
          prev.map((r) =>
            r.id === p.roomId && !r.messages.some((m) => m.id === p.message.id)
              ? { ...r, messages: [...r.messages, p.message] }
              : r
          )
        )
      ),
      realtime.on('room:kicked', (p: { reason?: string }) => {
        wantedRoomRef.current = null;
        const ar = langRef.current === 'ar';
        toastRef.current(
          p?.reason === 'other_device'
            ? ar ? 'تم الانضمام للمجلس من جهاز آخر' : 'You joined this room from another device'
            : ar ? 'تم إخراجك من المجلس بواسطة المضيف' : 'The host removed you from the room'
        );
      }),
      realtime.on('room:error', (p: { code?: string; max?: number }) => {
        const ar = langRef.current === 'ar';
        if (p?.code === 'speaker_limit') {
          toastRef.current(
            ar
              ? `وصل المجلس للحد الأقصى من المتحدثين (${p.max})`
              : `Speaker limit reached (${p.max})`
          );
        } else if (p?.code === 'not_found') {
          toastRef.current(ar ? 'هذا المجلس لم يعد موجوداً' : 'This room no longer exists');
        }
      }),
      realtime.on('dm:message', (m: DirectMessage) =>
        setDirectMessages((prev) => (prev.some((x) => x.id === m.id) ? prev : [...prev, m]))
      ),
      realtime.on('hello:ok', () => {
        // After a reconnect the server forgot my seat: sit back down in the room I was in.
        if (wantedRoomRef.current) realtime.send('room:join', { roomId: wantedRoomRef.current });
      }),
      realtime.on('hello:error', () => logoutRef.current()),
      realtime.onStatus(setWsConnected),
    ];
    realtime.start();
    return () => offs.forEach((off) => off());
  }, []);

  // Offline banner (only after the connection stayed down for a few seconds)
  useEffect(() => {
    if (wsConnected) {
      setShowOfflineBanner(false);
      return;
    }
    const t = window.setTimeout(() => setShowOfflineBanner(true), 5000);
    return () => window.clearTimeout(t);
  }, [wsConnected]);

  // After login / app start with a saved session: identify the socket and pull my private data
  const authedUserId = authUser?.id || null;
  useEffect(() => {
    if (!authedUserId) return;
    realtime.hello();
    fetch(getApiUrl('/api/auth/me'))
      .then((res) => {
        if (res.status === 401) {
          logoutRef.current();
          return null;
        }
        return res.ok ? res.json() : null;
      })
      .then((j) => {
        if (j?.user) applyStateRef.current({ users: [j.user] });
      })
      .catch(() => {});
    fetch(getApiUrl('/api/state'))
      .then((res) => (res.ok ? res.json() : null))
      .then((d) => d && applyStateRef.current(d))
      .catch(() => {});
  }, [authedUserId]);

  const getUser = (id: string): User =>
    users.find((u) => u.id === id) || currentUser;

  // Check if a user is a friend of another user
  const isFriendOf = (viewerId: string, authorId: string): boolean => {
    if (viewerId === authorId) return true;
    const author = users.find((u) => u.id === authorId);
    const viewer = users.find((u) => u.id === viewerId);
    if (author?.friendIds?.includes(viewerId)) return true;
    if (viewer?.friendIds?.includes(authorId)) return true;
    if (author?.isFollowing || viewer?.isFollowing) return true;
    return false;
  };

  // Check if currentUser is allowed to see a post based on PostAudience
  const canViewPost = (post: Post): boolean => {
    if (post.authorId === currentUser.id) return true;
    const aud = post.audience || 'public';
    if (aud === 'public') return true;
    if (aud === 'only_me') return false;
    const friend = isFriendOf(currentUser.id, post.authorId);
    if (aud === 'friends') return friend;
    if (aud === 'non_friends') return !friend;
    return true;
  };

  // Check if currentUser is allowed to see a Story based on WhatsApp-style StoryPrivacyMode
  const canViewStory = (st: StoryItem): boolean => {
    if (st.authorId === currentUser.id) return true;
    const mode = st.privacyMode || 'public';
    const friend = isFriendOf(currentUser.id, st.authorId);
    if (mode === 'public') return true;
    if (mode === 'friends_only') return friend;
    if (mode === 'public_except_friends') return !friend;
    if (mode === 'friends_of_friends') return true;
    if (mode === 'custom_include') {
      return (st.allowedUserIds || []).includes(currentUser.id);
    }
    if (mode === 'custom_exclude') {
      return !(st.excludedUserIds || []).includes(currentUser.id);
    }
    return true;
  };

  // Global Refresh across Feed + Breaking News
  const handleRefreshAllPages = async () => {
    if (isRefreshingAll) return;
    setIsRefreshingAll(true);
    try {
      const res = await fetch(getApiUrl('/api/refresh-all'), {
        method: 'POST',
      });
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data.news)) setNews(data.news);
        if (Array.isArray(data.rooms)) setRooms(data.rooms);
        if (Array.isArray(data.posts)) {
          setPosts((prev) => {
            const map = new Map<string, Post>();
            [...prev, ...data.posts].forEach((p: Post) => map.set(p.id, p));
            return Array.from(map.values()).sort(
              (a, b) => (b.createdAtMs || 0) - (a.createdAtMs || 0)
            );
          });
        }
      }
    } catch {
      setNews((prev) =>
        prev.map((n, i) =>
          i === 0
            ? {
                ...n,
                publishedAtAr: 'الآن (تم التحديث)',
                publishedAtEn: 'Just now (Refreshed)',
                viewsCount: n.viewsCount + 12,
              }
            : n
        )
      );
    } finally {
      setTimeout(() => {
        setIsRefreshingAll(false);
        setNowTick(Date.now());
        showToast(
          isAr
            ? 'تم تحديث الصفحة الرئيسية والمنشورات وآخر الأخبار بنجاح ✓'
            : 'Home feed, posts, and latest news refreshed ✓'
        );
      }, 300);
    }
  };

  const handleHomeTabClick = () => {
    const now = Date.now();
    if (activeTab === 'feed' && now - lastHomeTapRef.current < 450) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      handleRefreshAllPages();
    } else {
      setActiveTab('feed');
    }
    lastHomeTapRef.current = now;
  };

  // Post Composer live voice recording handlers
  const startPostVoiceRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      postRecorderRef.current = recorder;
      postChunksRef.current = [];

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) postChunksRef.current.push(e.data);
      };

      recorder.onstop = () => {
        const blob = new Blob(postChunksRef.current, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.onloadend = () => {
          if (typeof reader.result === 'string') {
            setNewPostAudioUrl(reader.result);
            setNewPostAudioTitle(
              isAr ? 'تسجيل صوتي بالمايك 🎙️' : 'Voice Recording 🎙️'
            );
          }
        };
        reader.readAsDataURL(blob);
        stream.getTracks().forEach((t) => t.stop());
      };

      recorder.start();
      setIsRecordingPostVoice(true);
      setPostRecordSeconds(0);
      postTimerRef.current = window.setInterval(() => {
        setPostRecordSeconds((s) => s + 1);
      }, 1000);
    } catch {
      setIsRecordingPostVoice(true);
      setPostRecordSeconds(0);
      postTimerRef.current = window.setInterval(() => {
        setPostRecordSeconds((s) => s + 1);
      }, 1000);
    }
  };

  const stopPostVoiceRecording = () => {
    if (postTimerRef.current) {
      clearInterval(postTimerRef.current);
      postTimerRef.current = null;
    }
    const mins = Math.floor(postRecordSeconds / 60);
    const secs = postRecordSeconds % 60;
    setNewPostAudioDuration(
      `${mins}:${String(Math.max(1, secs)).padStart(2, '0')}`
    );
    if (
      postRecorderRef.current &&
      postRecorderRef.current.state !== 'inactive'
    ) {
      postRecorderRef.current.stop();
    } else {
      setNewPostAudioUrl('synth:voice');
      setNewPostAudioTitle(isAr ? 'تسجيل صوتي بالمايك 🎙️' : 'Voice Recording 🎙️');
    }
    setIsRecordingPostVoice(false);
  };

  // Real File Upload Handler for Image, Video, and Audio from Phone
  const handlePostFileUpload = async (
    e: React.ChangeEvent<HTMLInputElement>,
    kind: 'image' | 'video' | 'audio'
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (kind === 'image') {
      try {
        const compressed = await readFileAsCompressedDataUrl(file, 'post');
        setNewPostImageUrl(compressed);
        showToast(
          isAr
            ? `تم إرفاق الصورة من الهاتف (${file.name}) بنجاح ✓`
            : `Photo attached (${file.name}) ✓`
        );
      } catch {
        // ignore
      }
      e.target.value = '';
      return;
    }

    if (kind === 'video') {
      try {
        const res = await readMediaFileWithDuration(file, 'video');
        setNewPostVideoUrl(res.dataUrl);
        setNewPostVideoDuration(res.duration);
        showToast(
          isAr
            ? `تم إرفاق الفيديو (${res.fileName}) · المدة ${res.duration} ✓`
            : `Video attached (${res.fileName}) ✓`
        );
      } catch {
        // ignore
      }
      e.target.value = '';
      return;
    }

    if (kind === 'audio') {
      try {
        const res = await readMediaFileWithDuration(file, 'audio');
        setNewPostAudioUrl(res.dataUrl);
        setNewPostAudioDuration(res.duration);
        setNewPostAudioTitle(res.fileName);
        showToast(
          isAr
            ? `تم إرفاق المقطع الصوتي (${res.fileName}) · المدة ${res.duration} ✓`
            : `Audio clip attached (${res.fileName}) ✓`
        );
      } catch {
        // ignore
      }
      e.target.value = '';
    }
  };

  // Gemini AI Post Composer Assistant
  const handleAiPostAssist = async () => {
    if (isAiAssisting) return;
    setIsAiAssisting(true);
    try {
      const res = await fetch(getApiUrl('/api/ai/assist'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode: newPostContent.trim() ? 'enhance' : 'inspire',
          text: newPostContent.trim(),
          lang,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data?.result) {
          setNewPostContent(data.result);
          showToast(
            isAr
              ? 'تم صياغة وتحسين المنشور بالذكاء الاصطناعي ✨'
              : 'Post enhanced with AI ✨'
          );
        }
      }
    } catch {
      setNewPostContent((prev) =>
        prev.trim()
          ? `${prev.trim()}\n\n#ونس #مجتمع_ونس #تواصل`
          : isAr
          ? 'مساء الخير على مجتمع ونس الجميل! شاركونا آراءكم وأهم لحظاتكم اليوم 🌟 #ونس #المجلس'
          : 'Hello WANAS community! Share your favorite moments today 🌟 #WANAS'
      );
    } finally {
      setIsAiAssisting(false);
    }
  };

  // Gemini AI Summarize / Explain a Post
  const handleAiSummarizePost = async (post: Post) => {
    setOpenMenuPostId(null);
    try {
      const res = await fetch(getApiUrl('/api/ai/assist'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode: 'summarize',
          text: post.content,
          lang,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data?.result) {
          setAiSummaryByPostId((prev) => ({
            ...prev,
            [post.id]: data.result,
          }));
        }
      }
    } catch {
      setAiSummaryByPostId((prev) => ({
        ...prev,
        [post.id]: isAr
          ? `ملخص ذكي: يتحدث هذا المنشور عن "${post.content.slice(0, 70)}..."`
          : `AI Summary: "${post.content.slice(0, 70)}..."`,
      }));
    }
  };

  const handleCreatePost = (e: React.FormEvent) => {
    e.preventDefault();
    const validPollOptions = pollOptions
      .map((o) => o.trim())
      .filter((o) => o.length > 0);
    const hasPoll =
      showPollBuilder &&
      pollQuestion.trim().length > 0 &&
      validPollOptions.length >= 2;

    if (
      !newPostContent.trim() &&
      !newPostImageUrl &&
      !newPostVideoUrl &&
      !newPostAudioUrl &&
      !newPostLinkUrl.trim() &&
      !hasPoll
    ) {
      return;
    }

    const nowMs = Date.now();
    const newPost: Post = {
      id: `post_${nowMs}`,
      authorId: currentUser.id,
      content:
        newPostContent.trim() ||
        (hasPoll
          ? pollQuestion.trim()
          : newPostAudioUrl
          ? isAr
            ? `مقطع صوتي: ${newPostAudioTitle || 'تسجيل صوتي'} 🎙️`
            : `Audio clip: ${newPostAudioTitle || 'Voice note'} 🎙️`
          : newPostVideoUrl
          ? isAr
            ? 'مقطع فيديو جديد 🎬'
            : 'New video clip 🎬'
          : isAr
          ? 'منشور جديد ✨'
          : 'New post ✨'),
      category: newPostVideoUrl ? 'video' : 'general',
      audience: newPostAudience,
      imageUrl: newPostImageUrl || undefined,
      videoUrl: newPostVideoUrl || undefined,
      videoDuration: newPostVideoUrl ? newPostVideoDuration : undefined,
      audioUrl: newPostAudioUrl || undefined,
      audioDuration: newPostAudioUrl ? newPostAudioDuration : undefined,
      audioTitle: newPostAudioUrl ? newPostAudioTitle : undefined,
      linkUrl: newPostLinkUrl.trim() || undefined,
      linkTitle: newPostLinkUrl.trim() || undefined,
      poll: hasPoll
        ? {
            question: pollQuestion.trim(),
            options: validPollOptions.map((label, idx) => ({
              id: `opt_${idx}_${nowMs}`,
              label,
              votes: [],
            })),
          }
        : undefined,
      createdAt: isAr ? 'الآن' : 'Just now',
      createdAtMs: nowMs,
      likes: [],
      reactions: {},
      bookmarks: [],
      comments: [],
      repostsCount: 0,
      sharesCount: 0,
    };

    setPosts((prev) => [newPost, ...prev]);
    setNewPostContent('');
    setNewPostImageUrl(null);
    setNewPostVideoUrl(null);
    setNewPostAudioUrl(null);
    setNewPostAudioTitle('');
    setNewPostLinkUrl('');
    setShowLinkInput(false);
    setShowPollBuilder(false);
    setPollQuestion('');
    setPollOptions(['', '']);

    showToast(
      isAr
        ? 'تم نشر منشورك بنجاح وهو متاح الآن للجمهور المحدد ✓'
        : 'Your post has been published ✓'
    );

    fetch(getApiUrl('/api/posts'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newPost),
    }).catch(() => {});
  };

  // 6-Reaction Handler on Posts ("لايك، أحببت، أضحكني، أدعمه، أغضبني، لا أوافق")
  const handleReactToPost = (postId: string, reaction: ReactionType) => {
    setPosts((prev) =>
      prev.map((p) => {
        if (p.id !== postId) return p;
        const currentReactions: Partial<Record<ReactionType, string[]>> = {
          ...(p.reactions || {}),
        };
        const alreadyHasThis = (currentReactions[reaction] || []).includes(
          currentUser.id
        );

        // Remove user from all reaction types first (1 active reaction per user)
        for (const rKey of [
          'like',
          'love',
          'haha',
          'support',
          'angry',
          'disagree',
        ] as ReactionType[]) {
          currentReactions[rKey] = (currentReactions[rKey] || []).filter(
            (id) => id !== currentUser.id
          );
        }

        if (!alreadyHasThis) {
          currentReactions[reaction] = [
            ...(currentReactions[reaction] || []),
            currentUser.id,
          ];
        }

        const nextLikes =
          reaction === 'like' && !alreadyHasThis
            ? Array.from(new Set([...p.likes, currentUser.id]))
            : p.likes.filter((id) => id !== currentUser.id);

        const updatedPost: Post = {
          ...p,
          reactions: currentReactions,
          likes: nextLikes,
        };

        fetch(getApiUrl(`/api/posts/${postId}/react`), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userId: currentUser.id, reaction }),
        }).catch(() => {});

        return updatedPost;
      })
    );
  };

  // 6-Reaction Handler on Comments inside CommentsSheetModal
  const handleReactToComment = (
    postId: string,
    commentId: string,
    reaction: ReactionType
  ) => {
    setPosts((prev) =>
      prev.map((p) => {
        if (p.id !== postId) return p;
        const nextComments = p.comments.map((c) => {
          if (c.id !== commentId) return c;
          const currentReactions: Partial<Record<ReactionType, string[]>> = {
            ...(c.reactions || {}),
          };
          const alreadyHasThis = (currentReactions[reaction] || []).includes(
            currentUser.id
          );
          for (const rKey of [
            'like',
            'love',
            'haha',
            'support',
            'angry',
            'disagree',
          ] as ReactionType[]) {
            currentReactions[rKey] = (currentReactions[rKey] || []).filter(
              (id) => id !== currentUser.id
            );
          }
          if (!alreadyHasThis) {
            currentReactions[reaction] = [
              ...(currentReactions[reaction] || []),
              currentUser.id,
            ];
          }
          return {
            ...c,
            reactions: currentReactions,
          };
        });
        return { ...p, comments: nextComments };
      })
    );
  };

  // Vote on Poll Option
  const handleVotePoll = (postId: string, optionId: string) => {
    setPosts((prev) =>
      prev.map((p) => {
        if (p.id !== postId || !p.poll) return p;
        const nextOptions = p.poll.options.map((opt) => {
          const cleanVotes = opt.votes.filter((uid) => uid !== currentUser.id);
          if (opt.id === optionId) {
            return { ...opt, votes: [...cleanVotes, currentUser.id] };
          }
          return { ...opt, votes: cleanVotes };
        });
        const updated = {
          ...p,
          poll: { ...p.poll, options: nextOptions },
        };
        fetch(getApiUrl('/api/posts'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(updated),
        }).catch(() => {});
        return updated;
      })
    );
  };

  // Repost Handler ("إعادة نشر المنشور أو الفيديو 🔁")
  const handleRepost = (originalPost: Post) => {
    const nowMs = Date.now();
    const repostItem: Post = {
      ...originalPost,
      id: `repost_${nowMs}`,
      repostOfPostId: originalPost.id,
      repostedByAuthorId: currentUser.id,
      repostedByName: currentUser.name,
      createdAt: isAr ? 'الآن' : 'Just now',
      createdAtMs: nowMs,
      likes: [],
      reactions: {},
      comments: [],
      bookmarks: [],
      isPinned: false,
    };

    setPosts((prev) => [
      repostItem,
      ...prev.map((p) =>
        p.id === originalPost.id
          ? {
              ...p,
              repostsCount: (p.repostsCount || 0) + 1,
              repostedByUserIds: [
                ...(p.repostedByUserIds || []),
                currentUser.id,
              ],
            }
          : p
      ),
    ]);

    pushNotification({
      type: 'repost',
      actorId: currentUser.id,
      actorName: currentUser.name,
      targetPostId: originalPost.id,
      textAr: `قمت بإعادة نشر منشور "${originalPost.content.slice(0, 35)}..."`,
      textEn: `You reposted "${originalPost.content.slice(0, 35)}..."`,
    });

    showToast(
      isAr
        ? 'تمت إعادة نشر المنشور في الصفحة الرئيسية بنجاح 🔁'
        : 'Post reposted to feed 🔁'
    );

    fetch(getApiUrl('/api/posts'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(repostItem),
    }).catch(() => {});
  };

  // Send Post to Multiple Selected Friends ("إرسال المنشور لكذا حد")
  const handleSendPostToUsers = (
    post: Post,
    recipientIds: string[],
    customNote: string
  ) => {
    const now = new Date();
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(
      now.getMinutes()
    ).padStart(2, '0')}`;
    const nowMs = Date.now();

    const newMessages: DirectMessage[] = recipientIds.map((rid, idx) => ({
      id: `dm_share_${nowMs}_${idx}`,
      senderId: currentUser.id,
      receiverId: rid,
      text: customNote
        ? `${customNote}\n🔗 مشاركة منشور: "${post.content.slice(0, 80)}"`
        : `📤 شارك معك منشوراً: "${post.content.slice(0, 80)}"`,
      sharedPostId: post.id,
      createdAt: timeStr,
      createdAtMs: nowMs,
    }));

    setDirectMessages((prev) => [...prev, ...newMessages]);
    setPosts((prev) =>
      prev.map((p) =>
        p.id === post.id
          ? { ...p, sharesCount: (p.sharesCount || 0) + recipientIds.length }
          : p
      )
    );

    showToast(
      isAr
        ? `تم إرسال المنشور إلى (${recipientIds.length}) من الأصدقاء في الرسائل بنجاح 📤`
        : `Post sent to ${recipientIds.length} friends 📤`
    );
  };

  const handleToggleBookmark = (postId: string) => {
    setPosts((prev) =>
      prev.map((p) => {
        if (p.id !== postId) return p;
        const hasSaved = p.bookmarks.includes(currentUser.id);
        showToast(
          hasSaved
            ? isAr
              ? 'تمت إزالة المنشور من المحفوظات'
              : 'Removed from saved posts'
            : isAr
            ? 'تم حفظ المنشور في قائمة المحفوظات'
            : 'Post saved to bookmarks'
        );
        return {
          ...p,
          bookmarks: hasSaved
            ? p.bookmarks.filter((id) => id !== currentUser.id)
            : [...p.bookmarks, currentUser.id],
        };
      })
    );
    setOpenMenuPostId(null);
  };

  const handleTogglePinPost = (postId: string) => {
    setPosts((prev) =>
      prev.map((p) => {
        if (p.id !== postId) return p;
        const nextPinned = !p.isPinned;
        showToast(
          nextPinned
            ? isAr
              ? 'تم تثبيت المنشور في أعلى ملفك الشخصي 📌'
              : 'Post pinned to your profile 📌'
            : isAr
            ? 'تم إلغاء تثبيت المنشور'
            : 'Post unpinned'
        );
        return { ...p, isPinned: nextPinned };
      })
    );
    setOpenMenuPostId(null);
  };

  const handleCopyPostLink = (postId: string) => {
    const link = `${window.location.origin}/?post=${postId}`;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(link).catch(() => {});
    }
    setOpenMenuPostId(null);
    showToast(isAr ? 'تم نسخ رابط المنشور بنجاح 🔗' : 'Post link copied 🔗');
  };

  const handleCopyPostText = (text: string) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text).catch(() => {});
    }
    setOpenMenuPostId(null);
    showToast(
      isAr ? 'تم نسخ نص المحتوى إلى الحافظة 📋' : 'Post content copied 📋'
    );
  };

  const handleReportPost = (postId: string) => {
    setPosts((prev) =>
      prev.map((p) => (p.id === postId ? { ...p, isReported: true } : p))
    );
    setOpenMenuPostId(null);
    showToast(
      isAr
        ? 'تم استلام بلاغك حول هذا المنشور وسيتم مراجعته'
        : 'Report submitted for review'
    );
  };

  const handleDeletePost = (postId: string) => {
    setPosts((prev) => prev.filter((p) => p.id !== postId));
    setOpenMenuPostId(null);
    showToast(isAr ? 'تم حذف المنشور' : 'Post deleted');
    fetch(getApiUrl(`/api/posts/${postId}`), { method: 'DELETE' }).catch(
      () => {}
    );
  };

  const handleAddComment = (
    postId: string,
    payload: { content: string; audioUrl?: string; audioDuration?: string }
  ) => {
    const nowMs = Date.now();
    const comment = {
      id: `c_${nowMs}`,
      authorId: currentUser.id,
      content: payload.content,
      audioUrl: payload.audioUrl,
      audioDuration: payload.audioDuration,
      createdAt: isAr ? 'الآن' : 'Just now',
      createdAtMs: nowMs,
      reactions: {},
    };

    setPosts((prev) =>
      prev.map((p) =>
        p.id === postId ? { ...p, comments: [...p.comments, comment] } : p
      )
    );

    fetch(getApiUrl(`/api/posts/${postId}/comments`), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(comment),
    }).catch(() => {});
  };

  const handleCreateStory = (newStory: StoryItem) => {
    setStories((prev) => [newStory, ...prev]);
    showToast(
      isAr
        ? 'تم نشر قصتك (الستوري) مع إعدادات الخصوصية المحددة ✨'
        : 'Story published with privacy settings ✨'
    );
    fetch(getApiUrl('/api/stories'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newStory),
    }).catch(() => {});
  };

  const handlePublishVideoPost = (payload: {
    content: string;
    videoUrl: string;
    videoDuration?: string;
    audience?: PostAudience;
  }) => {
    const nowMs = Date.now();
    const newVideoPost: Post = {
      id: `vid_${nowMs}`,
      authorId: currentUser.id,
      content: payload.content,
      category: 'video',
      audience: payload.audience || 'public',
      videoUrl: payload.videoUrl,
      videoDuration: payload.videoDuration,
      mediaKey: 'cairo_sunset',
      createdAt: isAr ? 'الآن' : 'Just now',
      createdAtMs: nowMs,
      likes: [],
      reactions: {},
      bookmarks: [],
      comments: [],
      repostsCount: 0,
      sharesCount: 0,
    };
    setPosts((prev) => [newVideoPost, ...prev]);
    showToast(
      isAr
        ? 'تم نشر مقطع الفيديو بنجاح وهو متاح الآن للمشاهدة 🎬'
        : 'Video published successfully 🎬'
    );
    fetch(getApiUrl('/api/posts'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newVideoPost),
    }).catch(() => {});
  };

  const handleToggleJoinRoom = (roomId: string) => {
    const room = rooms.find((r) => r.id === roomId);
    const joined = room?.participants.some((p) => p.userId === currentUser.id);
    if (joined) {
      wantedRoomRef.current = null;
      realtime.send('room:leave', null);
      return;
    }
    wantedRoomRef.current = roomId;
    if (!realtime.send('room:join', { roomId })) {
      wantedRoomRef.current = null;
      showToast(
        isAr
          ? 'لا يوجد اتصال بالسيرفر حالياً، حاول بعد لحظات'
          : 'Not connected to the server right now, try again shortly'
      );
    }
  };

  const handleToggleMic = (roomId: string) => {
    const me = rooms
      .find((r) => r.id === roomId)
      ?.participants.find((p) => p.userId === currentUser.id);
    if (!me) return;
    realtime.send('room:mute', { muted: !me.isMuted });
  };

  const handleToggleHand = (raised: boolean) => realtime.send('room:hand', { raised });
  const handleModerate = (
    userId: string,
    action: 'promote' | 'demote' | 'mute' | 'kick'
  ) => realtime.send('room:moderate', { userId, action });
  const handleCloseRoom = (roomId: string) => {
    wantedRoomRef.current = null;
    realtime.send('room:close', { roomId });
  };

  const handleSendRoomMessage = (_roomId: string, text: string) => {
    realtime.send('room:message', {
      message: { id: `rm_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`, text },
    });
  };

  const handleCreateRoom = (title: string, topic: string) => {
    if (!realtime.send('room:create', { title, topic })) {
      showToast(
        isAr
          ? 'لا يوجد اتصال بالسيرفر حالياً، حاول بعد لحظات'
          : 'Not connected to the server right now, try again shortly'
      );
      return;
    }
    showToast(
      isAr ? 'تم إطلاق المجلس الصوتي المباشر' : 'Live audio room started'
    );
  };

  const handleSendDirectMessage = (
    receiverId: string,
    text: string,
    audioUrl?: string
  ) => {
    const now = new Date();
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(
      now.getMinutes()
    ).padStart(2, '0')}`;
    const msg: DirectMessage = {
      id: `dm_${Date.now()}`,
      senderId: currentUser.id,
      receiverId,
      text,
      audioUrl,
      createdAt: timeStr,
      createdAtMs: Date.now(),
    };
    setDirectMessages((prev) => [...prev, msg]);
    realtime.send('dm:message', msg);
  };

  const handleAddContactUser = (name: string, handleOrPhone: string): User => {
    const cleanHandle = handleOrPhone.startsWith('@')
      ? handleOrPhone
      : `@${handleOrPhone.replace(/\s+/g, '_').toLowerCase()}`;
    const existing = users.find(
      (u) =>
        u.handle.toLowerCase() === cleanHandle.toLowerCase() ||
        u.name.toLowerCase() === name.toLowerCase()
    );
    if (existing) return existing;

    const created: User = {
      id: `u_${Date.now()}`,
      name,
      nameEn: name,
      handle: cleanHandle,
      avatarKey: 'omar',
      coverKey: 'royal_majlis',
      role: 'صديق في ونس',
      roleEn: 'WANAS Friend',
      bio: 'حساب على منصة ونس للتواصل الاجتماعي.',
      bioEn: 'Account on WANAS social platform.',
      followersCount: 1,
      followingCount: 1,
      friendIds: [currentUser.id],
      isFollowing: true,
      isOnline: true,
      lastActiveAtMs: Date.now(),
    };
    setUsers((prev) => [...prev, created]);
    return created;
  };

  const handleAuthenticate = (loggedInUser: User) => {
    const userWithSettings: User = {
      ...loggedInUser,
      isOnline: true,
      lastActiveAtMs: Date.now(),
      settings: { ...DEFAULT_USER_SETTINGS, ...(loggedInUser.settings || {}) },
    };
    setAuthUser(userWithSettings);
    try {
      localStorage.setItem(
        'wanas_auth_user_v3',
        JSON.stringify(userWithSettings)
      );
    } catch {
      // ignore
    }
    setUsers((prev) => {
      const exists = prev.some((u) => u.id === userWithSettings.id);
      if (exists) {
        return prev.map((u) =>
          u.id === userWithSettings.id ? userWithSettings : u
        );
      }
      return [userWithSettings, ...prev];
    });
  };

  const handleUpdateUser = (updates: Partial<User>) => {
    const updatedUser: User = {
      ...currentUser,
      ...updates,
      lastActiveAtMs: Date.now(),
      nameEn: updates.name || currentUser.nameEn,
      bioEn: updates.bio || currentUser.bioEn,
      roleEn: updates.role || currentUser.roleEn,
    };
    setAuthUser(updatedUser);
    try {
      localStorage.setItem('wanas_auth_user_v3', JSON.stringify(updatedUser));
    } catch {
      // ignore
    }
    setUsers((prev) =>
      prev.map((u) => (u.id === currentUser.id ? updatedUser : u))
    );
    fetch(getApiUrl('/api/auth/register'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updatedUser),
    }).catch(() => {});
    showToast(isAr ? 'تم حفظ تحديثات حسابك بنجاح ✓' : 'Account updated ✓');
  };

  // Add / Remove Friend Handler
  const handleToggleFriend = (targetUserId: string) => {
    const target = users.find((u) => u.id === targetUserId);
    if (!target) return;
    const currentFriends = currentUser.friendIds || [];
    const isAlreadyFriend = currentFriends.includes(targetUserId);

    const nextMyFriends = isAlreadyFriend
      ? currentFriends.filter((id) => id !== targetUserId)
      : [...currentFriends, targetUserId];

    const updatedMe: User = {
      ...currentUser,
      friendIds: nextMyFriends,
    };

    syncMyProfile(updatedMe);
    setAuthUser(updatedMe);
    try {
      localStorage.setItem('wanas_auth_user_v3', JSON.stringify(updatedMe));
    } catch {
      // ignore
    }

    setUsers((prev) =>
      prev.map((u) => {
        if (u.id === currentUser.id) return updatedMe;
        if (u.id === targetUserId) {
          const tFriends = u.friendIds || [];
          return {
            ...u,
            friendIds: isAlreadyFriend
              ? tFriends.filter((id) => id !== currentUser.id)
              : Array.from(new Set([...tFriends, currentUser.id])),
          };
        }
        return u;
      })
    );

    showToast(
      isAlreadyFriend
        ? isAr
          ? `تم إلغاء الصداقة مع ${target.name}`
          : `Removed ${target.name} from friends`
        : isAr
        ? `تمت إضافة ${target.name} إلى قائمة الأصدقاء بنجاح 🤝`
        : `Added ${target.name} as a friend 🤝`
    );
  };

  // Follow / Unfollow User Handler
  const handleToggleFollow = (targetUserId: string) => {
    const target = users.find((u) => u.id === targetUserId);
    if (!target) return;
    const currentFollowing = currentUser.followingIds || [];
    const isAlreadyFollowing =
      currentFollowing.includes(targetUserId) || Boolean(target.isFollowing);

    const nextFollowingIds = isAlreadyFollowing
      ? currentFollowing.filter((id) => id !== targetUserId)
      : Array.from(new Set([...currentFollowing, targetUserId]));

    const updatedMe: User = {
      ...currentUser,
      followingIds: nextFollowingIds,
      followingCount: Math.max(
        0,
        (currentUser.followingCount || 0) + (isAlreadyFollowing ? -1 : 1)
      ),
    };

    syncMyProfile(updatedMe);
    setAuthUser(updatedMe);
    try {
      localStorage.setItem('wanas_auth_user_v3', JSON.stringify(updatedMe));
    } catch {
      // ignore
    }

    setUsers((prev) =>
      prev.map((u) => {
        if (u.id === currentUser.id) return updatedMe;
        if (u.id === targetUserId) {
          return {
            ...u,
            isFollowing: !isAlreadyFollowing,
            followersCount: Math.max(
              0,
              (u.followersCount || 0) + (isAlreadyFollowing ? -1 : 1)
            ),
          };
        }
        return u;
      })
    );

    showToast(
      isAlreadyFollowing
        ? isAr
          ? `تم إلغاء متابعة ${target.name}`
          : `Unfollowed ${target.name}`
        : isAr
        ? `تتابع الآن ${target.name} ✓`
        : `Now following ${target.name} ✓`
    );
  };

  // Start Direct Message with a User (respecting their DM privacy setting)
  const handleStartMessageWithUser = (targetUser: User) => {
    const mode = targetUser.settings?.whoCanMessage || 'everyone';
    if (mode === 'nobody') {
      showToast(
        isAr
          ? `🔒 لا يمكن إرسال رسالة إلى ${targetUser.name} لأنه قام بإيقاف استقبال الرسائل الخاصة في الإعدادات.`
          : `🔒 ${targetUser.name} has disabled incoming direct messages.`
      );
      return;
    }
    const isFriendOrFollower =
      (currentUser.friendIds || []).includes(targetUser.id) ||
      (currentUser.followingIds || []).includes(targetUser.id) ||
      Boolean(targetUser.isFollowing);
    if (mode === 'followers' && !isFriendOrFollower) {
      showToast(
        isAr
          ? `👥 ${targetUser.name} يستقبل الرسائل من المتابعين والأصدقاء فقط. قم بمتابعته أو إضافته كصديق أولاً!`
          : `👥 ${targetUser.name} only accepts messages from followers/friends.`
      );
      return;
    }
    setSelectedDmUserId(targetUser.id);
    setActiveTab('messages');
  };

  // Follow / Unfollow Community Page
  const handleToggleFollowPage = (pageId: string) => {
    setCommunityPages((prev) =>
      prev.map((pg) => {
        if (pg.id !== pageId) return pg;
        const nextFollow = !pg.isFollowing;
        showToast(
          nextFollow
            ? isAr
              ? `تمت متابعة صفحة "${pg.titleAr}" بنجاح ✓`
              : `Followed page "${pg.titleEn}" ✓`
            : isAr
            ? `تم إلغاء متابعة صفحة "${pg.titleAr}"`
            : `Unfollowed "${pg.titleEn}"`
        );
        return {
          ...pg,
          isFollowing: nextFollow,
          followersCount: Math.max(
            0,
            pg.followersCount + (nextFollow ? 1 : -1)
          ),
        };
      })
    );
  };

  // Create Community Page
  const handleCreatePage = (
    title: string,
    category: string,
    description: string
  ) => {
    const slug = title
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9\u0600-\u06FF]+/g, '_')
      .replace(/^_+|_+$/g, '');
    const created: CommunityPage = {
      id: `page_${Date.now()}`,
      titleAr: title,
      titleEn: title,
      handle: `@${slug || 'page'}`,
      categoryAr: category,
      categoryEn: category,
      descriptionAr: description,
      descriptionEn: description,
      interests: [],
      followersIds: [currentUser.id],
      followersCount: 1,
      isFollowing: true,
    };
    setCommunityPages((prev) => [created, ...prev]);
    showToast(
      isAr
        ? `تم إنشاء الصفحة العامة "${created.titleAr}" بنجاح ✨`
        : `Page "${created.titleEn}" created ✨`
    );
  };

  const handleLogout = () => {
    if (myRoom) realtime.send('room:leave', null);
    wantedRoomRef.current = null;
    clearToken();
    realtime.reset(); // reconnects anonymously so the next login starts clean
    setShowDrawer(false);
    setAuthUser(null);
    try {
      localStorage.removeItem('wanas_auth_user_v3');
    } catch {
      // ignore
    }
  };
  logoutRef.current = handleLogout;

  const syncMyProfile = (me: User) => {
    fetch(getApiUrl('/api/auth/register'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(me),
    }).catch(() => {});
  };

  if (!authUser) {
    return (
      <>
        {showStartupSplash && (
          <StartupSplashModal lang={lang} onDismiss={() => setShowStartupSplash(false)} />
        )}
        <AuthView
          lang={lang}
          darkMode={darkMode}
          users={users}
          onToggleDarkMode={(d) => setDarkMode(d)}
          onToggleLang={() => setLang((l) => (l === 'ar' ? 'en' : 'ar'))}
          onLoginSuccess={handleAuthenticate}
          onRegisterSuccess={handleAuthenticate}
        />
      </>
    );
  }

  const activeCommentsPost =
    posts.find((p) => p.id === commentsPostId) || null;

  const myPresence = formatUserPresence(
    currentUser.isOnline,
    currentUser.settings?.showOnlineStatus,
    currentUser.lastActiveAtMs,
    lang,
    nowTick
  );

  // Filter stories and posts according to Privacy & Search/Hashtags
  const visibleStories = stories.filter(canViewStory);
  const visiblePosts = posts.filter((post) => {
    if (!canViewPost(post)) return false;
    if (activeHashtag && !post.content.includes(activeHashtag)) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      const author = getUser(post.authorId);
      return (
        post.content.toLowerCase().includes(q) ||
        author.name.toLowerCase().includes(q) ||
        author.handle.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const unreadNotifsCount = notifications.filter((n) => !n.isRead).length;

  const getAudienceBadgeInfo = (aud?: PostAudience) => {
    switch (aud) {
      case 'friends':
        return {
          icon: Users,
          label: isAr ? 'للأصدقاء فقط' : 'Friends Only',
        };
      case 'non_friends':
        return {
          icon: Shield,
          label: isAr ? 'لغير الأصدقاء' : 'Non-Friends',
        };
      case 'only_me':
        return {
          icon: Lock,
          label: isAr ? 'أنا فقط' : 'Only Me',
        };
      default:
        return {
          icon: Globe,
          label: isAr ? 'للعامة' : 'Public',
        };
    }
  };

  return (
    <div
      dir={isAr ? 'rtl' : 'ltr'}
      className={`min-h-screen transition-colors duration-300 ${
        darkMode
          ? 'dark bg-[#0F1514] text-slate-100'
          : 'bg-[#FAF7F2] text-[#1F1A12]'
      }`}
    >
      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="fixed bottom-20 sm:bottom-6 start-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-2xl bg-[#1F1A12] dark:bg-[#0E6B63] text-white text-xs font-bold shadow-xl flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-[#F2A93B]" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Official Startup Splash Banner (credit above logo + WANAS in English below logo) */}
      {showStartupSplash && (
        <StartupSplashModal lang={lang} onDismiss={() => setShowStartupSplash(false)} />
      )}

      {/* Top Navigation Header — logo, then search / notifications / avatar / menu (☰) */}
      <header className="sticky top-0 z-30 bg-white/95 dark:bg-[#151D1C]/95 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800/80 transition-colors duration-300">
        <div className="max-w-6xl mx-auto px-3 sm:px-4 h-14 sm:h-16 flex items-center justify-between gap-2">
          {/* Brand Logo */}
          <div
            onClick={handleHomeTabClick}
            className="flex items-center gap-2.5 cursor-pointer select-none shrink-0"
            title={
              isAr
                ? 'اضغط مرتين لتحديث الصفحة الرئيسية وآخر الأخبار'
                : 'Double-tap to refresh feed & news'
            }
          >
            <div className="flex flex-col items-center">
              <WanasBrandIcon className="w-9 h-9 rounded-xl shadow-xs shrink-0" />
              <span
                dir="ltr"
                className="text-[9px] font-black tracking-widest text-[#0E6B63] dark:text-[#5FD0C4] leading-none mt-0.5"
              >
                WANAS
              </span>
            </div>
            <div className="hidden sm:block">
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-base tracking-tight text-[#1F1A12] dark:text-white">
                  {isAr ? 'ونس · WANAS' : 'WANAS'}
                </span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 flex items-center gap-1">
                  <span
                    className={`w-1.5 h-1.5 rounded-full ${
                      myPresence.isVisibleOnline
                        ? 'bg-emerald-500 animate-pulse'
                        : 'bg-slate-400'
                    }`}
                  />
                  <span>{myPresence.label}</span>
                </span>
              </div>
              <p
                dir="ltr"
                className="text-[9px] font-bold text-slate-400 dark:text-slate-500 truncate max-w-[200px]"
              >
                By ABD.ALLAH ZOHAIR OMARA
              </p>
            </div>
          </div>

          {/* Active Universal Search Bar in Top Header (searches People, Posts, Groups/Majlis, and Pages) */}
          <div className="hidden lg:block flex-1 max-w-sm mx-1">
            <button
              type="button"
              onClick={() => setShowUniversalSearchModal(true)}
              className="w-full min-h-[40px] px-3 py-1.5 rounded-2xl bg-slate-100 dark:bg-slate-900/90 hover:bg-slate-200/70 dark:hover:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 flex items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400 transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-2 truncate">
                <Search className="w-4 h-4 text-[#0E6B63] dark:text-[#5FD0C4] shrink-0" />
                <span className="truncate font-semibold">
                  {searchQuery
                    ? searchQuery
                    : isAr
                    ? 'ابحث عن أشخاص، منشورات، مجالس، صفحات...'
                    : 'Search people, posts, groups, pages...'}
                </span>
              </div>
              <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-lg bg-[#0E6B63]/10 text-[#0E6B63] dark:text-[#5FD0C4] shrink-0 hidden sm:inline">
                {isAr ? 'بحث شامل' : 'Search'}
              </span>
            </button>
          </div>

          {/* Center Desktop Navigation Tabs */}
          <nav className="hidden lg:flex items-center gap-1">
            <button
              type="button"
              onClick={handleHomeTabClick}
              className={`min-h-[40px] px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                activeTab === 'feed'
                  ? 'bg-[#0E6B63] text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Home className="w-4 h-4" />
              <span>{isAr ? 'الرئيسية' : 'Home'}</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('videos')}
              className={`min-h-[40px] px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                activeTab === 'videos'
                  ? 'bg-[#0E6B63] text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Video className="w-4 h-4" />
              <span>{isAr ? 'مقاطع الفيديو' : 'Videos'}</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('rooms')}
              className={`min-h-[40px] px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                activeTab === 'rooms'
                  ? 'bg-[#0E6B63] text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Radio className="w-4 h-4" />
              <span>{isAr ? 'المجالس الصوتية' : 'Audio Majlis'}</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('messages')}
              className={`min-h-[40px] px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                activeTab === 'messages'
                  ? 'bg-[#0E6B63] text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <MessageSquare className="w-4 h-4" />
              <span>{isAr ? 'الرسائل' : 'Messages'}</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('settings')}
              className={`min-h-[40px] px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                activeTab === 'settings'
                  ? 'bg-[#0E6B63] text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Menu className="w-4 h-4" />
              <span>{isAr ? 'الإعدادات' : 'Settings'}</span>
            </button>
          </nav>

          {/* Actions: search icon (mobile) · bell · avatar only · menu */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            <button
              type="button"
              onClick={() => setShowUniversalSearchModal(true)}
              className="lg:hidden min-h-[40px] min-w-[40px] rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center cursor-pointer"
              title={isAr ? 'بحث' : 'Search'}
              aria-label={isAr ? 'بحث' : 'Search'}
            >
              <Search className="w-[18px] h-[18px] text-[#0E6B63] dark:text-[#5FD0C4]" />
            </button>

            {/* Notifications Bell */}
            <div className="relative">
              <button
                type="button"
                onClick={() => {
                  setShowNotificationsMenu((prev) => !prev);
                  setNotifications((prev) =>
                    prev.map((n) => ({ ...n, isRead: true }))
                  );
                }}
                className="min-h-[40px] min-w-[40px] rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-700 dark:text-slate-200 hover:bg-[#0E6B63]/10 cursor-pointer relative"
                title={isAr ? 'الإشعارات' : 'Notifications'}
                aria-label={isAr ? 'الإشعارات' : 'Notifications'}
              >
                <Bell className="w-[18px] h-[18px] text-[#0E6B63] dark:text-[#5FD0C4]" />
                {unreadNotifsCount > 0 && (
                  <span className="absolute -top-1 -end-1 min-w-4 h-4 px-1 rounded-full bg-rose-600 text-white text-[10px] font-bold flex items-center justify-center">
                    {unreadNotifsCount}
                  </span>
                )}
              </button>

              {showNotificationsMenu && (
                <div className="fixed sm:absolute end-3 sm:end-0 top-14 sm:top-12 z-40 w-[min(20rem,calc(100vw-1.5rem))] sm:w-72 rounded-2xl bg-white dark:bg-[#1A2423] border border-slate-200 dark:border-slate-700 shadow-2xl p-3 space-y-2">
                  <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
                    <span className="text-xs font-extrabold">
                      {isAr ? 'مركز الإشعارات 🔔' : 'Notifications 🔔'}
                    </span>
                    <button
                      type="button"
                      onClick={() => setShowNotificationsMenu(false)}
                      className="text-slate-400 hover:text-slate-600 cursor-pointer"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  {notifications.length === 0 ? (
                    <p className="text-xs text-slate-500 py-4 text-center">
                      {isAr
                        ? 'لا توجد إشعارات جديدة حالياً.'
                        : 'No new notifications.'}
                    </p>
                  ) : (
                    <div className="max-h-60 overflow-y-auto space-y-1.5">
                      {notifications.map((n) => (
                        <div
                          key={n.id}
                          className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-900 text-xs space-y-0.5"
                        >
                          <div className="font-bold text-slate-800 dark:text-slate-200">
                            {isAr ? n.textAr : n.textEn}
                          </div>
                          <div className="text-[10px] text-slate-400">
                            {formatDynamicTime(
                              n.createdAtMs,
                              undefined,
                              lang,
                              nowTick
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Avatar-only profile button */}
            <button
              type="button"
              onClick={() => setActiveTab('profile')}
              className={`relative rounded-full p-0.5 cursor-pointer transition-all ${
                activeTab === 'profile'
                  ? 'ring-2 ring-[#0E6B63] dark:ring-[#5FD0C4]'
                  : 'ring-1 ring-slate-200 dark:ring-slate-700 hover:ring-[#0E6B63]'
              }`}
              title={isAr ? 'الملف الشخصي' : 'My profile'}
              aria-label={isAr ? 'الملف الشخصي' : 'My profile'}
            >
              <UserAvatar
                avatarKey={currentUser.avatarKey}
                customAvatarUrl={currentUser.customAvatarUrl}
                name={currentUser.name}
                size="sm"
              />
              {myPresence.isVisibleOnline && (
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-slate-900 absolute -bottom-0.5 -end-0.5" />
              )}
            </button>

            {/* Desktop quick theme toggle (on phones it lives in the menu) */}
            <button
              type="button"
              onClick={() => setDarkMode((d) => !d)}
              aria-label="Toggle Dark or Light Mode"
              className={`hidden lg:flex min-h-[40px] px-2.5 py-1.5 rounded-xl text-xs font-bold items-center gap-1.5 border transition-colors cursor-pointer ${
                darkMode
                  ? 'bg-amber-500/15 border-amber-500/40 text-[#F2A93B]'
                  : 'bg-slate-900 border-slate-800 text-white'
              }`}
            >
              {darkMode ? (
                <Sun className="w-4 h-4 text-[#F2A93B]" />
              ) : (
                <Moon className="w-4 h-4 text-[#F2A93B]" />
              )}
            </button>

            <button
              type="button"
              onClick={() => setShowDrawer(true)}
              className="min-h-[40px] min-w-[40px] rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center cursor-pointer hover:bg-[#0E6B63]/10"
              title={isAr ? 'القائمة' : 'Menu'}
              aria-label={isAr ? 'القائمة' : 'Menu'}
            >
              <Menu className="w-5 h-5 text-slate-700 dark:text-slate-200" />
            </button>
          </div>
        </div>
      </header>

      {showOfflineBanner && getWsUrl() && (
        <div className="sticky top-14 sm:top-16 z-20 flex items-center justify-center gap-2 py-1.5 text-[11px] font-bold bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-200">
          <WifiOff className="w-3.5 h-3.5" />
          <span>{isAr ? 'غير متصل بالسيرفر — جاري إعادة المحاولة…' : 'Offline — reconnecting…'}</span>
        </div>
      )}

      {showDrawer && (
        <AppDrawer
          lang={lang}
          darkMode={darkMode}
          currentUser={currentUser}
          onClose={() => setShowDrawer(false)}
          onOpenProfile={() => {
            setShowDrawer(false);
            setActiveTab('profile');
          }}
          onOpenSettings={() => {
            setShowDrawer(false);
            setActiveTab('settings');
          }}
          onOpenSaved={() => {
            setShowDrawer(false);
            setActiveTab('profile');
          }}
          onToggleDark={() => setDarkMode((d) => !d)}
          onToggleLang={() => setLang((l) => (l === 'ar' ? 'en' : 'ar'))}
          onLogout={handleLogout}
        />
      )}

      {showCreateSheet && (
        <CreateSheet
          lang={lang}
          onClose={() => setShowCreateSheet(false)}
          onPost={() => {
            setShowCreateSheet(false);
            setActiveTab('feed');
            window.scrollTo({ top: 0, behavior: 'smooth' });
            window.setTimeout(() => {
              document.getElementById('wanas-post-composer')?.focus();
            }, 350);
          }}
          onStory={() => {
            setShowCreateSheet(false);
            setShowCreateStoryModal(true);
          }}
          onVideo={() => {
            setShowCreateSheet(false);
            setActiveTab('videos');
          }}
          onRoom={() => {
            setShowCreateSheet(false);
            setActiveTab('rooms');
            setOpenRoomCreateSignal((n) => n + 1);
          }}
        />
      )}

      {/* Main Content Container */}
      <main className="max-w-6xl mx-auto px-4 py-5 pb-24 lg:pb-12">
        {activeTab === 'feed' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Left Sidebar: Personal Profile Summary Card */}
            <aside className="lg:col-span-3 space-y-4">
              <div className="bg-white dark:bg-[#151D1C] border border-slate-200/80 dark:border-slate-800 rounded-3xl overflow-hidden shadow-xs">
                <CoverBannerVisual
                  coverKey={currentUser.coverKey}
                  customCoverUrl={currentUser.customCoverUrl}
                  heightClass="h-28"
                >
                  <button
                    type="button"
                    onClick={() => setHomePhotoStudioTarget('cover')}
                    className="absolute top-2.5 end-2.5 px-2.5 py-1 rounded-xl bg-black/65 hover:bg-black/80 text-white text-[10px] font-bold flex items-center gap-1 backdrop-blur-md border border-white/15 cursor-pointer"
                  >
                    <Camera className="w-3 h-3 text-[#F2A93B]" />
                    <span>{isAr ? 'تغيير الغلاف' : 'Cover'}</span>
                  </button>
                </CoverBannerVisual>
                <div className="px-4 pb-4">
                  <div className="flex items-end justify-between -mt-8 mb-2.5 relative z-10">
                    <div
                      onClick={() => setHomePhotoStudioTarget('avatar')}
                      className="relative rounded-full p-1 bg-white dark:bg-[#151D1C] shadow-sm cursor-pointer group"
                    >
                      <UserAvatar
                        avatarKey={currentUser.avatarKey}
                        customAvatarUrl={currentUser.customAvatarUrl}
                        name={currentUser.name}
                        size="lg"
                      />
                      <span className="absolute bottom-0 end-0 w-6 h-6 rounded-full bg-[#0E6B63] text-white flex items-center justify-center shadow-md border-2 border-white dark:border-[#151D1C]">
                        <Camera className="w-3 h-3" />
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setActiveTab('profile')}
                      className="text-xs font-bold px-3 py-1.5 rounded-xl bg-[#0E6B63]/10 text-[#0E6B63] dark:text-[#5FD0C4] hover:bg-[#0E6B63]/20 transition-colors cursor-pointer flex items-center gap-1"
                    >
                      <UserIcon className="w-3.5 h-3.5" />
                      <span>{isAr ? 'ملفي الشخصي' : 'My Profile'}</span>
                    </button>
                  </div>
                  <h2 className="font-extrabold text-base text-[#1F1A12] dark:text-white flex items-center gap-1.5">
                    <span>{currentUser.name}</span>
                    {currentUser.isVerified && (
                      <CheckCircle2 className="w-4 h-4 text-[#0E6B63] dark:text-[#5FD0C4]" />
                    )}
                    {currentUser.settings?.isPrivateAccount && (
                      <Lock className="w-3.5 h-3.5 text-[#F2A93B]" />
                    )}
                  </h2>
                  <div className="flex items-center gap-2 mt-0.5">
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      {currentUser.handle}
                    </p>
                    <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400">
                      · {myPresence.label}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-300 mt-2 leading-relaxed">
                    {currentUser.bio}
                  </p>
                  <div className="grid grid-cols-2 gap-1.5 mt-3 pt-3 border-t border-slate-100 dark:border-slate-800/80">
                    <button
                      type="button"
                      onClick={() => setHomePhotoStudioTarget('avatar')}
                      className="px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-[#0E6B63]/10 text-[11px] font-bold text-slate-700 dark:text-slate-200 flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <Camera className="w-3.5 h-3.5 text-[#0E6B63] dark:text-[#5FD0C4]" />
                      <span>{isAr ? 'تغيير صورتي' : 'Photo'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setHomePhotoStudioTarget('cover')}
                      className="px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-[#0E6B63]/10 text-[11px] font-bold text-slate-700 dark:text-slate-200 flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <ImageIcon className="w-3.5 h-3.5 text-[#F2A93B]" />
                      <span>{isAr ? 'تغيير الغلاف' : 'Cover'}</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Search & Hashtag Filter Card */}
              <div className="bg-white dark:bg-[#151D1C] border border-slate-200/80 dark:border-slate-800 rounded-3xl p-4 space-y-3 shadow-xs">
                <div className="relative">
                  <Search className="w-4 h-4 text-slate-400 absolute top-1/2 -translate-y-1/2 start-3" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder={
                      isAr
                        ? 'ابحث في المنشورات أو الأعضاء...'
                        : 'Search posts or members...'
                    }
                    className="w-full ps-9 pe-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs focus:outline-none focus:border-[#0E6B63]"
                  />
                </div>
                <div className="flex flex-wrap gap-1.5">
                  <button
                    type="button"
                    onClick={() => setActiveHashtag(null)}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold cursor-pointer ${
                      !activeHashtag
                        ? 'bg-[#0E6B63] text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    {isAr ? 'الكل' : 'All'}
                  </button>
                  {TRENDING_HASHTAGS.map((tag) => (
                    <button
                      key={tag}
                      type="button"
                      onClick={() =>
                        setActiveHashtag((prev) => (prev === tag ? null : tag))
                      }
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-bold cursor-pointer ${
                        activeHashtag === tag
                          ? 'bg-[#0E6B63] text-white'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      {tag}
                    </button>
                  ))}
                </div>
              </div>
            </aside>

            {/* Center Column: Stories + Merged Breaking News + Multi-Media Post Composer + Feed */}
            <section className="lg:col-span-6 space-y-5">
              {/* 1. Stories Strip with WhatsApp-style Privacy */}
              <div className="bg-white dark:bg-[#151D1C] border border-slate-200/80 dark:border-slate-800 rounded-3xl p-4 shadow-xs">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-extrabold text-slate-700 dark:text-slate-300">
                    {isAr
                      ? 'القصص اليومية (الستوري - صور، فيديو، صوت، كتابة، روابط)'
                      : 'Daily Stories'}
                  </span>
                  <button
                    type="button"
                    onClick={() => setShowCreateStoryModal(true)}
                    className="text-xs font-bold text-[#0E6B63] dark:text-[#5FD0C4] hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{isAr ? 'إضافة ستوري وتحديد من يراه' : 'Add Story'}</span>
                  </button>
                </div>

                <div className="flex items-center gap-3 overflow-x-auto pb-1">
                  <button
                    type="button"
                    onClick={() => setShowCreateStoryModal(true)}
                    className="flex flex-col items-center gap-1.5 shrink-0 group cursor-pointer"
                  >
                    <div className="w-16 h-16 rounded-full p-0.5 border-2 border-dashed border-[#0E6B63] dark:border-[#5FD0C4] flex items-center justify-center bg-[#0E6B63]/5 group-hover:scale-105 transition-transform">
                      <div className="w-12 h-12 rounded-full bg-[#0E6B63] text-white flex items-center justify-center shadow-xs">
                        <Plus className="w-6 h-6" />
                      </div>
                    </div>
                    <span className="text-xs font-bold text-[#0E6B63] dark:text-[#5FD0C4]">
                      {isAr ? 'أضف ستوري' : 'Add Story'}
                    </span>
                  </button>

                  {visibleStories.map((st) => {
                    const author = getUser(st.authorId);
                    return (
                      <button
                        key={st.id}
                        type="button"
                        onClick={() => setActiveStory(st)}
                        className="flex flex-col items-center gap-1.5 shrink-0 group cursor-pointer"
                      >
                        <div className="p-0.5 rounded-full bg-gradient-to-tr from-[#0E6B63] to-[#F2A93B] group-hover:scale-105 transition-transform">
                          <div className="p-0.5 rounded-full bg-white dark:bg-[#151D1C]">
                            <UserAvatar
                              avatarKey={author.avatarKey}
                              customAvatarUrl={author.customAvatarUrl}
                              name={author.name}
                              size="md"
                            />
                          </div>
                        </div>
                        <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 max-w-[74px] truncate">
                          {st.title}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 1.5 People You May Know (أشخاص قد تعرفهم حسب الاهتمامات والموقع والبلد) */}
              <PeopleDiscoverySection
                lang={lang}
                users={users}
                currentUser={currentUser}
                onToggleFriend={handleToggleFriend}
                onToggleFollow={handleToggleFollow}
                onMessageUser={handleStartMessageWithUser}
                onUpdateCurrentUser={handleUpdateUser}
                onAddContactUser={handleAddContactUser}
              />

              {/* 2. Merged Home + Latest News Section */}
              <div className="bg-white dark:bg-[#151D1C] border border-slate-200/80 dark:border-slate-800 rounded-3xl p-4 shadow-xs space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#F2A93B]/20 text-amber-900 dark:text-[#F2A93B] text-xs font-extrabold">
                      <Flame className="w-3.5 h-3.5" />
                      <span>
                        {isAr ? 'آخر الأخبار في الرئيسية' : 'Latest News in Home'}
                      </span>
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={handleRefreshAllPages}
                      disabled={isRefreshingAll}
                      className="p-1.5 rounded-lg text-[#0E6B63] dark:text-[#5FD0C4] hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                      title={isAr ? 'تحديث الآن' : 'Refresh now'}
                    >
                      <RefreshCw
                        className={`w-4 h-4 ${
                          isRefreshingAll ? 'animate-spin' : ''
                        }`}
                      />
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowNewsSectionInFeed((s) => !s)}
                      className="text-xs font-bold text-slate-500 hover:text-slate-800 dark:hover:text-white cursor-pointer"
                    >
                      {showNewsSectionInFeed
                        ? isAr
                          ? 'طي الأخبار'
                          : 'Collapse'
                        : isAr
                        ? 'عرض الأخبار'
                        : 'Expand'}
                    </button>
                  </div>
                </div>

                {showNewsSectionInFeed && (
                  <div className="grid grid-cols-1 gap-2.5">
                    {news.slice(0, 2).map((item) => (
                      <div
                        key={item.id}
                        className="p-3 rounded-2xl bg-[#FAF7F2] dark:bg-slate-900/70 border border-slate-200/70 dark:border-slate-800 flex flex-col justify-between gap-1.5"
                      >
                        <div className="flex items-center justify-between text-[10px] text-slate-500 dark:text-slate-400">
                          <span className="font-bold text-[#0E6B63] dark:text-[#5FD0C4] flex items-center gap-1">
                            <Newspaper className="w-3 h-3" />
                            {isAr ? item.sourceAr : item.sourceEn}
                          </span>
                          <span>
                            {isAr ? item.publishedAtAr : item.publishedAtEn}
                          </span>
                        </div>
                        <h4 className="text-xs font-extrabold text-[#1F1A12] dark:text-white leading-relaxed selectable-text">
                          {isAr ? item.titleAr : item.titleEn}
                        </h4>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* 3. Full Multi-Media Post Composer with Direct Native File Inputs, Audience Privacy, Poll Builder & AI */}
              <div className="bg-white dark:bg-[#151D1C] border border-slate-200/80 dark:border-slate-800 rounded-3xl p-4 sm:p-5 shadow-xs">
                <form onSubmit={handleCreatePost} className="space-y-3.5">
                  <div className="flex items-center justify-between gap-2 pb-2 border-b border-slate-100 dark:border-slate-800/80">
                    <div className="flex items-center gap-2">
                      <UserAvatar
                        avatarKey={currentUser.avatarKey}
                        customAvatarUrl={currentUser.customAvatarUrl}
                        name={currentUser.name}
                        size="sm"
                      />
                      <span className="text-xs font-extrabold text-slate-800 dark:text-slate-200">
                        {currentUser.name}
                      </span>
                    </div>

                    {/* Audience Privacy Selector ("للعامة، للأصدقاء فقط، لغير الأصدقاء، أنا فقط") */}
                    <div className="flex items-center gap-1.5">
                      <span className="text-[11px] font-bold text-slate-500">
                        {isAr ? 'الجمهور:' : 'Audience:'}
                      </span>
                      <select
                        value={newPostAudience}
                        onChange={(e) =>
                          setNewPostAudience(e.target.value as PostAudience)
                        }
                        className="px-2.5 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-[#0E6B63] dark:text-[#5FD0C4] focus:outline-none"
                      >
                        <option value="public">
                          {isAr ? '🌐 للعامة (الجميع)' : '🌐 Public'}
                        </option>
                        <option value="friends">
                          {isAr ? '👥 للأصدقاء فقط' : '👥 Friends Only'}
                        </option>
                        <option value="non_friends">
                          {isAr
                            ? '🌍 لغير الأصدقاء فقط'
                            : '🌍 Non-Friends Only'}
                        </option>
                        <option value="only_me">
                          {isAr ? '🔒 أنا فقط (خاص)' : '🔒 Only Me'}
                        </option>
                      </select>
                    </div>
                  </div>

                  <textarea
                    id="wanas-post-composer"
                    rows={3}
                    value={newPostContent}
                    onChange={(e) => setNewPostContent(e.target.value)}
                    placeholder={
                      isAr
                        ? `بمَ تفكر اليوم يا ${currentUser.name.split(' ')[0]}؟ انشر كتابة، أو اختر فيديو أو صورة أو ملفاً صوتياً من هاتفك، أو سجل صوتك بالمايك...`
                        : `What's on your mind, ${currentUser.name.split(' ')[0]}? Share text, voice, audio file, photo, video, poll, or link...`
                    }
                    className="w-full bg-transparent text-sm text-[#1F1A12] dark:text-white placeholder:text-slate-400 focus:outline-none resize-none leading-relaxed"
                  />

                  {isRecordingPostVoice && (
                    <div className="p-3 rounded-2xl bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900/50 flex items-center justify-between">
                      <div className="flex items-center gap-2 text-xs font-bold text-red-600 dark:text-red-400">
                        <span className="w-2.5 h-2.5 rounded-full bg-red-600 animate-ping" />
                        <span>
                          {isAr
                            ? `جاري تسجيل صوتك بالمايك... (${postRecordSeconds} ثانية)`
                            : `Recording voice post... (${postRecordSeconds}s)`}
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={stopPostVoiceRecording}
                        className="px-3 py-1.5 rounded-xl bg-red-600 text-white text-xs font-bold flex items-center gap-1 cursor-pointer"
                      >
                        <Square className="w-3.5 h-3.5" />
                        <span>{isAr ? 'إيقاف واعتماد' : 'Stop & Save'}</span>
                      </button>
                    </div>
                  )}

                  {newPostAudioUrl && !isRecordingPostVoice && (
                    <div className="flex items-center gap-2">
                      <div className="flex-1">
                        <AudioWavePlayer
                          audioUrl={newPostAudioUrl}
                          durationLabel={newPostAudioDuration}
                          title={
                            newPostAudioTitle ||
                            (isAr
                              ? 'مقطع صوتي مرفق بالمنشور'
                              : 'Attached Audio Clip')
                          }
                        />
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setNewPostAudioUrl(null);
                          setNewPostAudioTitle('');
                        }}
                        className="p-2 rounded-xl text-red-600 hover:bg-red-50 dark:hover:bg-red-950/30 cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  )}

                  {newPostImageUrl && (
                    <div className="relative rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 max-h-72 bg-slate-950">
                      <img
                        src={newPostImageUrl}
                        alt="Post attachment"
                        className="w-full max-h-72 object-contain"
                      />
                      <button
                        type="button"
                        onClick={() => setNewPostImageUrl(null)}
                        className="absolute top-2 end-2 p-1.5 rounded-full bg-black/70 text-white hover:bg-black cursor-pointer"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  )}

                  {newPostVideoUrl && (
                    <div className="relative rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-black">
                      <video
                        src={newPostVideoUrl}
                        controls
                        playsInline
                        className="w-full max-h-72 object-contain"
                      />
                      <button
                        type="button"
                        onClick={() => setNewPostVideoUrl(null)}
                        className="absolute top-2 end-2 p-1.5 rounded-full bg-black/70 text-white hover:bg-black cursor-pointer"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  )}

                  {showLinkInput && (
                    <div className="flex items-center gap-2 bg-[#FAF7F2] dark:bg-slate-900 p-2.5 rounded-2xl border border-slate-200 dark:border-slate-800">
                      <Globe className="w-4 h-4 text-[#0E6B63] dark:text-[#5FD0C4] shrink-0" />
                      <input
                        type="url"
                        value={newPostLinkUrl}
                        onChange={(e) => setNewPostLinkUrl(e.target.value)}
                        placeholder={
                          isAr
                            ? 'أدخل الرابط الخارجي (مثال: https://example.com)...'
                            : 'Paste external URL (https://...)...'
                        }
                        dir="ltr"
                        className="flex-1 bg-transparent text-xs text-[#1F1A12] dark:text-white focus:outline-none"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          setNewPostLinkUrl('');
                          setShowLinkInput(false);
                        }}
                        className="text-slate-400 hover:text-red-500 cursor-pointer"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  )}

                  {/* Interactive Poll Builder */}
                  {showPollBuilder && (
                    <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-2.5">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-extrabold text-[#0E6B63] dark:text-[#5FD0C4]">
                          {isAr
                            ? 'إنشاء استطلاع رأي وتصويت 📊'
                            : 'Create Poll 📊'}
                        </span>
                        <button
                          type="button"
                          onClick={() => setShowPollBuilder(false)}
                          className="text-slate-400 hover:text-rose-500 cursor-pointer"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                      <input
                        type="text"
                        value={pollQuestion}
                        onChange={(e) => setPollQuestion(e.target.value)}
                        placeholder={
                          isAr ? 'اكتب سؤال التصويت...' : 'Ask a question...'
                        }
                        className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                      />
                      {pollOptions.map((opt, idx) => (
                        <input
                          key={idx}
                          type="text"
                          value={opt}
                          onChange={(e) => {
                            const copy = [...pollOptions];
                            copy[idx] = e.target.value;
                            setPollOptions(copy);
                          }}
                          placeholder={
                            isAr ? `الخيار ${idx + 1}` : `Option ${idx + 1}`
                          }
                          className="w-full px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                        />
                      ))}
                      {pollOptions.length < 4 && (
                        <button
                          type="button"
                          onClick={() => setPollOptions([...pollOptions, ''])}
                          className="text-xs font-bold text-[#0E6B63] dark:text-[#5FD0C4] cursor-pointer"
                        >
                          {isAr ? '+ إضافة خيار آخر' : '+ Add option'}
                        </button>
                      )}
                    </div>
                  )}

                  {/* Attachment Toolbar — Direct Native <input type="file"> inside <label> so tapping immediately opens Phone Files! */}
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                    <div className="flex flex-wrap items-center gap-1.5">
                      {/* 1. Live Voice Mic */}
                      <button
                        type="button"
                        onClick={
                          isRecordingPostVoice
                            ? stopPostVoiceRecording
                            : startPostVoiceRecording
                        }
                        className={`px-2.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer ${
                          isRecordingPostVoice
                            ? 'bg-red-600 text-white'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-[#0E6B63]/10 hover:text-[#0E6B63]'
                        }`}
                      >
                        <Mic className="w-3.5 h-3.5 text-[#0E6B63] dark:text-[#5FD0C4]" />
                        <span>{isAr ? 'مايك صوتي' : 'Voice'}</span>
                      </button>

                      {/* 2. Direct Phone Audio File Attachment */}
                      <label className="relative overflow-hidden px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-[#0E6B63]/10 hover:text-[#0E6B63] text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer">
                        <FileAudio className="w-3.5 h-3.5 text-[#F2A93B]" />
                        <span>{isAr ? 'إرفاق مقطع صوتي' : 'Audio File'}</span>
                        <input
                          type="file"
                          accept="audio/*"
                          onChange={(e) => handlePostFileUpload(e, 'audio')}
                          className="absolute inset-0 opacity-0 cursor-pointer"
                        />
                      </label>

                      {/* 3. Direct Phone Photo Picker */}
                      <label className="relative overflow-hidden px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-[#0E6B63]/10 hover:text-[#0E6B63] text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer">
                        <ImageIcon className="w-3.5 h-3.5 text-emerald-600" />
                        <span>{isAr ? 'صورة' : 'Photo'}</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => handlePostFileUpload(e, 'image')}
                          className="absolute inset-0 opacity-0 cursor-pointer"
                        />
                      </label>

                      {/* 4. Direct Phone Video Picker */}
                      <label className="relative overflow-hidden px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-[#0E6B63]/10 hover:text-[#0E6B63] text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer">
                        <Film className="w-3.5 h-3.5 text-rose-500" />
                        <span>{isAr ? 'إضافة فيديو' : 'Video'}</span>
                        <input
                          type="file"
                          accept="video/*"
                          onChange={(e) => handlePostFileUpload(e, 'video')}
                          className="absolute inset-0 opacity-0 cursor-pointer"
                        />
                      </label>

                      {/* 5. Poll */}
                      <button
                        type="button"
                        onClick={() => setShowPollBuilder((s) => !s)}
                        className="px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-[#0E6B63]/10 text-xs font-bold flex items-center gap-1 cursor-pointer"
                      >
                        <BarChart2 className="w-3.5 h-3.5 text-purple-500" />
                        <span>{isAr ? 'تصويت' : 'Poll'}</span>
                      </button>

                      {/* 6. Link */}
                      <button
                        type="button"
                        onClick={() => setShowLinkInput((s) => !s)}
                        className="px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-[#0E6B63]/10 text-xs font-bold flex items-center gap-1 cursor-pointer"
                      >
                        <Link2 className="w-3.5 h-3.5 text-sky-500" />
                        <span>{isAr ? 'رابط' : 'Link'}</span>
                      </button>

                      {/* 7. Gemini AI Assistant */}
                      <button
                        type="button"
                        onClick={handleAiPostAssist}
                        disabled={isAiAssisting}
                        className="px-2.5 py-1.5 rounded-xl bg-[#0E6B63]/10 dark:bg-[#5FD0C4]/15 text-[#0E6B63] dark:text-[#5FD0C4] text-xs font-extrabold flex items-center gap-1 cursor-pointer"
                        title={
                          isAr
                            ? 'صياغة أو تحسين المنشور بالذكاء الاصطناعي'
                            : 'AI Post Assistant'
                        }
                      >
                        <Sparkles className="w-3.5 h-3.5 text-[#F2A93B]" />
                        <span>
                          {isAiAssisting
                            ? isAr
                              ? 'جاري...'
                              : 'AI...'
                            : isAr
                            ? 'ذكاء اصطناعي ✨'
                            : 'AI ✨'}
                        </span>
                      </button>
                    </div>

                    <button
                      type="submit"
                      className="min-h-[40px] px-5 py-2 rounded-xl bg-[#0E6B63] hover:bg-[#0B5650] text-white text-xs font-extrabold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>{isAr ? 'نشر المنشور' : 'Publish'}</span>
                    </button>
                  </div>
                </form>
              </div>

              {/* 4. Posts Stream with Dynamic Timestamps, Online Presence, 6-Reactions, Repost, Multi-Share & Save Media */}
              <div className="space-y-4">
                {visiblePosts.length === 0 ? (
                  <div className="bg-white dark:bg-[#151D1C] border border-slate-200/80 dark:border-slate-800 rounded-3xl p-10 text-center space-y-3 shadow-xs">
                    <div className="w-14 h-14 rounded-2xl bg-[#0E6B63]/10 text-[#0E6B63] dark:text-[#5FD0C4] flex items-center justify-center mx-auto">
                      <Send className="w-6 h-6" />
                    </div>
                    <h3 className="text-base font-extrabold text-[#1F1A12] dark:text-white">
                      {isAr
                        ? 'المنصة جاهزة لمنشوراتك ومقاطعك الآن!'
                        : 'The platform is ready for your posts!'}
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto leading-relaxed">
                      {isAr
                        ? 'انشر أول منشور لك الآن (كتابة، تسجيل صوتي بالمايك، ملف صوتي من الهاتف، صورة، فيديو، تصويت، أو رابط) وسيظهر فوراً للجميع.'
                        : 'Publish your first post above (text, voice recording, audio file, photo, video, poll, or link).'}
                    </p>
                  </div>
                ) : (
                  visiblePosts.map((post) => {
                    const author = getUser(post.authorId);
                    const isSaved = post.bookmarks.includes(currentUser.id);
                    const isMenuOpen = openMenuPostId === post.id;
                    const authorPresence = formatUserPresence(
                      author.isOnline,
                      author.settings?.showOnlineStatus,
                      author.lastActiveAtMs,
                      lang,
                      nowTick
                    );
                    const audBadge = getAudienceBadgeInfo(post.audience);
                    const AudIcon = audBadge.icon;

                    return (
                      <article
                        key={post.id}
                        className="bg-white dark:bg-[#151D1C] border border-slate-200/80 dark:border-slate-800 rounded-3xl p-5 space-y-4 shadow-xs relative"
                      >
                        {post.repostedByName && (
                          <div className="flex items-center gap-1.5 text-xs font-extrabold text-emerald-700 dark:text-emerald-400 pb-2 border-b border-slate-100 dark:border-slate-800/70">
                            <Repeat2 className="w-4 h-4" />
                            <span>
                              {isAr
                                ? `أعاد ${post.repostedByName} نشر هذا المنشور`
                                : `Reposted by ${post.repostedByName}`}
                            </span>
                          </div>
                        )}

                        {post.isPinned && (
                          <div className="flex items-center gap-1.5 text-[11px] font-bold text-[#0E6B63] dark:text-[#5FD0C4] pb-1 border-b border-slate-100 dark:border-slate-800/70">
                            <Pin className="w-3.5 h-3.5" />
                            <span>
                              {isAr
                                ? 'منشور مثبت في الملف الشخصي'
                                : 'Pinned Post'}
                            </span>
                          </div>
                        )}

                        <div className="flex items-start justify-between gap-3">
                          <div className="flex items-center gap-3">
                            <div className="relative">
                              <UserAvatar
                                avatarKey={author.avatarKey}
                                customAvatarUrl={author.customAvatarUrl}
                                name={author.name}
                                size="md"
                              />
                              {authorPresence.isVisibleOnline && (
                                <span className="w-3 h-3 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-[#151D1C] absolute bottom-0 end-0" />
                              )}
                            </div>
                            <div>
                              <div className="flex flex-wrap items-center gap-1.5">
                                <h3 className="font-bold text-sm text-[#1F1A12] dark:text-white">
                                  {author.name}
                                </h3>
                                {author.isVerified && (
                                  <CheckCircle2 className="w-3.5 h-3.5 text-[#0E6B63] dark:text-[#5FD0C4]" />
                                )}
                                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-bold">
                                  {authorPresence.label}
                                </span>
                              </div>
                              <div className="text-xs text-slate-500 dark:text-slate-400 flex flex-wrap items-center gap-1.5 mt-0.5">
                                <span dir="ltr">{author.handle}</span>
                                <span>·</span>
                                <span className="font-semibold text-slate-600 dark:text-slate-300">
                                  {formatDynamicTime(
                                    post.createdAtMs,
                                    post.createdAt,
                                    lang,
                                    nowTick
                                  )}
                                </span>
                                <span>·</span>
                                <span className="inline-flex items-center gap-1 text-[11px] text-[#0E6B63] dark:text-[#5FD0C4] font-bold">
                                  <AudIcon className="w-3 h-3" />
                                  <span>{audBadge.label}</span>
                                </span>
                              </div>
                            </div>
                          </div>

                          <div className="relative">
                            <button
                              type="button"
                              onClick={() =>
                                setOpenMenuPostId(isMenuOpen ? null : post.id)
                              }
                              aria-label="خيارات المنشور"
                              className="p-2 rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                            >
                              <MoreVertical className="w-5 h-5" />
                            </button>

                            {isMenuOpen && (
                              <div className="absolute end-0 top-10 z-30 w-60 rounded-2xl bg-white dark:bg-[#1A2423] border border-slate-200 dark:border-slate-700 shadow-xl py-1.5 text-xs font-bold">
                                <button
                                  type="button"
                                  onClick={() => handleCopyPostText(post.content)}
                                  className="w-full px-4 py-2.5 text-start flex items-center gap-2.5 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                                >
                                  <Copy className="w-4 h-4 text-[#0E6B63] dark:text-[#5FD0C4]" />
                                  <span>
                                    {isAr
                                      ? 'نسخ نص المنشور 📋'
                                      : 'Copy Post Content 📋'}
                                  </span>
                                </button>

                                <button
                                  type="button"
                                  onClick={() => handleCopyPostLink(post.id)}
                                  className="w-full px-4 py-2.5 text-start flex items-center gap-2.5 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                                >
                                  <Link2 className="w-4 h-4 text-[#0E6B63] dark:text-[#5FD0C4]" />
                                  <span>
                                    {isAr
                                      ? 'نسخ رابط المنشور 🔗'
                                      : 'Copy Post Link 🔗'}
                                  </span>
                                </button>

                                {(post.imageUrl ||
                                  (post.videoUrl &&
                                    post.videoUrl !== 'builtin:video') ||
                                  (post.audioUrl &&
                                    post.audioUrl !== 'synth:voice')) && (
                                  <button
                                    type="button"
                                    onClick={() => {
                                      if (post.videoUrl) {
                                        downloadMediaToDevice(
                                          post.videoUrl,
                                          'wanas-video'
                                        );
                                      } else if (post.imageUrl) {
                                        downloadMediaToDevice(
                                          post.imageUrl,
                                          'wanas-photo'
                                        );
                                      } else if (post.audioUrl) {
                                        downloadMediaToDevice(
                                          post.audioUrl,
                                          'wanas-audio'
                                        );
                                      }
                                      setOpenMenuPostId(null);
                                      showToast(
                                        isAr
                                          ? 'جاري حفظ الملف في هاتفك ⬇️'
                                          : 'Saving media to phone ⬇️'
                                      );
                                    }}
                                    className="w-full px-4 py-2.5 text-start flex items-center gap-2.5 text-emerald-600 dark:text-emerald-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                                  >
                                    <Download className="w-4 h-4" />
                                    <span>
                                      {isAr
                                        ? 'حفظ الصورة / الفيديو في الهاتف ⬇️'
                                        : 'Save Media to Phone ⬇️'}
                                    </span>
                                  </button>
                                )}

                                <button
                                  type="button"
                                  onClick={() => handleToggleBookmark(post.id)}
                                  className="w-full px-4 py-2.5 text-start flex items-center gap-2.5 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                                >
                                  <Bookmark className="w-4 h-4 text-[#F2A93B]" />
                                  <span>
                                    {isSaved
                                      ? isAr
                                        ? 'إلغاء حفظ المنشور'
                                        : 'Unsave Post'
                                      : isAr
                                      ? 'حفظ المنشور في المحفوظات'
                                      : 'Save Post'}
                                  </span>
                                </button>

                                <button
                                  type="button"
                                  onClick={() => {
                                    setOpenMenuPostId(null);
                                    setShareModalPost(post);
                                  }}
                                  className="w-full px-4 py-2.5 text-start flex items-center gap-2.5 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                                >
                                  <Share2 className="w-4 h-4 text-sky-500" />
                                  <span>
                                    {isAr
                                      ? 'مشاركة وإرسال لعدة أصدقاء 📤'
                                      : 'Share to Multiple Friends 📤'}
                                  </span>
                                </button>

                                <button
                                  type="button"
                                  onClick={() => handleAiSummarizePost(post)}
                                  className="w-full px-4 py-2.5 text-start flex items-center gap-2.5 text-[#0E6B63] dark:text-[#5FD0C4] hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                                >
                                  <Sparkles className="w-4 h-4 text-[#F2A93B]" />
                                  <span>
                                    {isAr
                                      ? 'تلخيص ذكي بالذكاء الاصطناعي ✨'
                                      : 'AI Smart Summary ✨'}
                                  </span>
                                </button>

                                {post.authorId === currentUser.id && (
                                  <button
                                    type="button"
                                    onClick={() => handleTogglePinPost(post.id)}
                                    className="w-full px-4 py-2.5 text-start flex items-center gap-2.5 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                                  >
                                    <Pin className="w-4 h-4 text-[#0E6B63] dark:text-[#5FD0C4]" />
                                    <span>
                                      {post.isPinned
                                        ? isAr
                                          ? 'إلغاء التثبيت من الملف الشخصي'
                                          : 'Unpin from Profile'
                                        : isAr
                                        ? 'تثبيت في الملف الشخصي'
                                        : 'Pin to Profile'}
                                    </span>
                                  </button>
                                )}

                                <button
                                  type="button"
                                  onClick={() => handleReportPost(post.id)}
                                  className="w-full px-4 py-2.5 text-start flex items-center gap-2.5 text-amber-600 dark:text-amber-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                                >
                                  <Flag className="w-4 h-4" />
                                  <span>
                                    {isAr ? 'إبلاغ عن المنشور' : 'Report Post'}
                                  </span>
                                </button>

                                {post.authorId === currentUser.id && (
                                  <button
                                    type="button"
                                    onClick={() => handleDeletePost(post.id)}
                                    className="w-full px-4 py-2.5 text-start flex items-center gap-2.5 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30 cursor-pointer"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                    <span>
                                      {isAr ? 'حذف المنشور' : 'Delete Post'}
                                    </span>
                                  </button>
                                )}
                              </div>
                            )}
                          </div>
                        </div>

                        <p className="text-sm sm:text-base text-[#1F1A12] dark:text-slate-100 whitespace-pre-line leading-relaxed selectable-text">
                          {post.content}
                        </p>

                        {aiSummaryByPostId[post.id] && (
                          <div className="p-3 rounded-2xl bg-[#0E6B63]/10 border border-[#0E6B63]/30 text-xs text-[#0E6B63] dark:text-[#5FD0C4] font-semibold flex items-start gap-2">
                            <Sparkles className="w-4 h-4 text-[#F2A93B] shrink-0 mt-0.5" />
                            <span>{aiSummaryByPostId[post.id]}</span>
                          </div>
                        )}

                        {/* Interactive Poll Display */}
                        {post.poll && (
                          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/70 border border-slate-200 dark:border-slate-800 space-y-2.5">
                            <div className="text-xs sm:text-sm font-extrabold text-slate-900 dark:text-white">
                              📊 {post.poll.question}
                            </div>
                            {(() => {
                              const totalVotes = post.poll.options.reduce(
                                (acc, o) => acc + o.votes.length,
                                0
                              );
                              return (
                                <div className="space-y-2">
                                  {post.poll.options.map((opt) => {
                                    const voted = opt.votes.includes(
                                      currentUser.id
                                    );
                                    const pct =
                                      totalVotes > 0
                                        ? Math.round(
                                            (opt.votes.length / totalVotes) *
                                              100
                                          )
                                        : 0;
                                    return (
                                      <button
                                        key={opt.id}
                                        type="button"
                                        onClick={() =>
                                          handleVotePoll(post.id, opt.id)
                                        }
                                        className={`w-full p-2.5 rounded-xl border text-start relative overflow-hidden cursor-pointer ${
                                          voted
                                            ? 'border-[#0E6B63] bg-[#0E6B63]/10'
                                            : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800'
                                        }`}
                                      >
                                        <div
                                          style={{ width: `${pct}%` }}
                                          className="absolute inset-y-0 start-0 bg-[#0E6B63]/15 transition-all"
                                        />
                                        <div className="relative flex items-center justify-between text-xs font-bold">
                                          <span>
                                            {opt.label} {voted ? '✓' : ''}
                                          </span>
                                          <span className="font-mono">
                                            {pct}% ({opt.votes.length})
                                          </span>
                                        </div>
                                      </button>
                                    );
                                  })}
                                </div>
                              );
                            })()}
                          </div>
                        )}

                        {post.audioUrl && (
                          <AudioWavePlayer
                            audioUrl={post.audioUrl}
                            durationLabel={post.audioDuration || '0:18'}
                            title={
                              post.audioTitle ||
                              (isAr ? 'مقطع صوتي في المنشور' : 'Audio Post')
                            }
                          />
                        )}

                        {post.imageUrl && (
                          <div className="relative rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-black">
                            <img
                              src={post.imageUrl}
                              alt="Post media"
                              className="w-full max-h-[460px] object-contain"
                            />
                            <button
                              type="button"
                              onClick={() => {
                                downloadMediaToDevice(
                                  post.imageUrl!,
                                  'wanas-photo'
                                );
                                showToast(
                                  isAr
                                    ? 'تم حفظ الصورة في الهاتف ⬇️'
                                    : 'Photo saved to phone ⬇️'
                                );
                              }}
                              className="absolute top-3 end-3 px-3 py-1.5 rounded-xl bg-black/70 hover:bg-black text-white text-xs font-bold flex items-center gap-1.5 backdrop-blur-md cursor-pointer"
                            >
                              <Download className="w-3.5 h-3.5 text-[#F2A93B]" />
                              <span>{isAr ? 'حفظ الصورة' : 'Save Photo'}</span>
                            </button>
                          </div>
                        )}

                        {post.videoUrl && post.videoUrl !== 'builtin:video' && (
                          <div className="relative rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-black">
                            <video
                              src={post.videoUrl}
                              controls
                              playsInline
                              className="w-full max-h-[460px] object-contain"
                            />
                            <button
                              type="button"
                              onClick={() => {
                                downloadMediaToDevice(
                                  post.videoUrl!,
                                  'wanas-video'
                                );
                                showToast(
                                  isAr
                                    ? 'تم حفظ الفيديو في الهاتف ⬇️'
                                    : 'Video saved to phone ⬇️'
                                );
                              }}
                              className="absolute top-3 end-3 px-3 py-1.5 rounded-xl bg-black/70 hover:bg-black text-white text-xs font-bold flex items-center gap-1.5 backdrop-blur-md cursor-pointer"
                            >
                              <Download className="w-3.5 h-3.5 text-[#F2A93B]" />
                              <span>{isAr ? 'حفظ الفيديو' : 'Save Video'}</span>
                            </button>
                          </div>
                        )}

                        {post.linkUrl && (
                          <a
                            href={post.linkUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center justify-between gap-3 p-3.5 rounded-2xl bg-[#FAF7F2] dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-[#0E6B63] transition-colors"
                          >
                            <div className="flex items-center gap-2.5 min-w-0">
                              <Globe className="w-5 h-5 text-[#0E6B63] dark:text-[#5FD0C4] shrink-0" />
                              <span
                                dir="ltr"
                                className="text-xs font-bold text-[#0E6B63] dark:text-[#5FD0C4] truncate"
                              >
                                {post.linkUrl}
                              </span>
                            </div>
                            <ExternalLink className="w-4 h-4 text-slate-400 shrink-0" />
                          </a>
                        )}

                        {post.mediaKey &&
                          !post.imageUrl &&
                          (!post.videoUrl ||
                            post.videoUrl === 'builtin:video') && (
                            <PostMediaVisual mediaKey={post.mediaKey} />
                          )}

                        {/* Post Action Bar: 6-Reactions + Comments + Repost ("إعادة نشر") + Multi-Friend Share ("مشاركة") */}
                        <div className="flex flex-wrap items-center justify-between gap-2 pt-3 border-t border-slate-100 dark:border-slate-800/80">
                          <div className="flex flex-wrap items-center gap-1.5">
                            <ReactionPickerBar
                              lang={lang}
                              currentUserId={currentUser.id}
                              reactions={post.reactions}
                              likesFallback={post.likes}
                              onSelectReaction={(rType) =>
                                handleReactToPost(post.id, rType)
                              }
                            />

                            <button
                              type="button"
                              onClick={() => setCommentsPostId(post.id)}
                              className="min-h-[38px] px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 bg-slate-100/80 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 hover:bg-slate-200/70 transition-colors cursor-pointer"
                            >
                              <MessageCircle className="w-4 h-4 text-[#0E6B63] dark:text-[#5FD0C4]" />
                              <span>{isAr ? 'التعليقات' : 'Comments'}</span>
                              <span className="font-mono tabular-nums px-1.5 py-0.5 rounded-md bg-white dark:bg-slate-900 text-[11px]">
                                {post.comments.length}
                              </span>
                            </button>

                            {/* 3rd Button: Repost ("إعادة نشر المنشور أو الفيديو") */}
                            <button
                              type="button"
                              onClick={() => handleRepost(post)}
                              className="min-h-[38px] px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 transition-colors cursor-pointer"
                              title={
                                isAr ? 'إعادة نشر المنشور' : 'Repost to Feed'
                              }
                            >
                              <Repeat2 className="w-4 h-4" />
                              <span>{isAr ? 'إعادة نشر' : 'Repost'}</span>
                              {(post.repostsCount || 0) > 0 && (
                                <span className="font-mono tabular-nums">
                                  {post.repostsCount}
                                </span>
                              )}
                            </button>

                            {/* 4th Button next to Repost: Share to Multiple Friends ("المشاركة - تبعتها لكذا حد") */}
                            <button
                              type="button"
                              onClick={() => setShareModalPost(post)}
                              className="min-h-[38px] px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 bg-slate-100/80 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 hover:bg-slate-200/70 transition-colors cursor-pointer"
                            >
                              <Share2 className="w-4 h-4 text-sky-500" />
                              <span>{isAr ? 'مشاركة' : 'Share'}</span>
                              {(post.sharesCount || 0) > 0 && (
                                <span className="font-mono tabular-nums">
                                  {post.sharesCount}
                                </span>
                              )}
                            </button>
                          </div>

                          <button
                            type="button"
                            onClick={() => handleToggleBookmark(post.id)}
                            aria-label="Save post"
                            className={`min-h-[38px] min-w-[38px] px-2.5 py-1.5 rounded-xl text-xs font-bold flex items-center justify-center transition-colors cursor-pointer ${
                              isSaved
                                ? 'bg-[#F2A93B]/20 text-amber-800 dark:text-[#F2A93B]'
                                : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800'
                            }`}
                          >
                            <Bookmark
                              className={`w-4 h-4 ${
                                isSaved ? 'fill-current' : ''
                              }`}
                            />
                          </button>
                        </div>
                      </article>
                    );
                  })
                )}
              </div>
            </section>

            {/* Right Sidebar: Quick Video Clips & Live Audio Rooms */}
            <aside className="lg:col-span-3 space-y-5">
              <div className="bg-white dark:bg-[#151D1C] border border-slate-200/80 dark:border-slate-800 rounded-3xl p-4 space-y-3 shadow-xs">
                <div className="flex items-center justify-between">
                  <h3 className="font-extrabold text-sm text-[#1F1A12] dark:text-white flex items-center gap-1.5">
                    <Video className="w-4 h-4 text-[#0E6B63] dark:text-[#5FD0C4]" />
                    <span>{isAr ? 'مقاطع الفيديو' : 'Video Clips'}</span>
                  </h3>
                  <button
                    type="button"
                    onClick={() => setActiveTab('videos')}
                    className="text-xs font-bold text-[#0E6B63] dark:text-[#5FD0C4] hover:underline cursor-pointer"
                  >
                    {isAr ? 'فتح القسم' : 'Open'}
                  </button>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                  {isAr
                    ? 'ارفع مقاطع الفيديو من هاتفك مباشرة، وشاهد واحفظ الفيديوهات وأعد نشرها.'
                    : 'Upload video clips directly from your phone, watch, save, and repost.'}
                </p>
              </div>

              <div className="bg-white dark:bg-[#151D1C] border border-slate-200/80 dark:border-slate-800 rounded-3xl p-4 space-y-3 shadow-xs">
                <div className="flex items-center justify-between">
                  <h3 className="font-extrabold text-sm text-[#1F1A12] dark:text-white flex items-center gap-1.5">
                    <Radio className="w-4 h-4 text-[#F2A93B]" />
                    <span>{isAr ? 'المجالس الصوتية' : 'Live Majlis'}</span>
                  </h3>
                  <button
                    type="button"
                    onClick={() => setActiveTab('rooms')}
                    className="text-xs font-bold text-[#0E6B63] dark:text-[#5FD0C4] hover:underline cursor-pointer"
                  >
                    {isAr ? 'عرض الكل' : 'View All'}
                  </button>
                </div>
                {rooms.length === 0 ? (
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    {isAr
                      ? 'افتح قسم المجالس الصوتية لبدء أول مجلس صوتي مباشر.'
                      : 'Open Audio Majlis to start a live audio room.'}
                  </p>
                ) : (
                  <div className="space-y-2.5">
                    {rooms.map((rm) => (
                      <div
                        key={rm.id}
                        onClick={() => setActiveTab('rooms')}
                        className="p-3 rounded-2xl bg-[#FAF7F2] dark:bg-slate-900/60 border border-slate-200/70 dark:border-slate-800 hover:border-[#0E6B63] transition-colors cursor-pointer"
                      >
                        <div className="text-xs font-bold text-[#1F1A12] dark:text-white line-clamp-1">
                          {isAr ? rm.title : rm.titleEn}
                        </div>
                        <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 mt-1.5">
                          <span>
                            {rm.participants.length}{' '}
                            {isAr ? 'في المجلس' : 'in room'}
                          </span>
                          <span className="text-[#0E6B63] dark:text-[#5FD0C4] font-bold">
                            {isAr ? 'انضمام ←' : 'Join →'}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </aside>
          </div>
        )}

        {/* Tab 2: Dedicated Videos Section */}
        {activeTab === 'videos' && (
          <VideosView
            lang={lang}
            posts={posts.filter(canViewPost)}
            currentUser={currentUser}
            getUser={getUser}
            onPublishVideoPost={handlePublishVideoPost}
            onReactToPost={handleReactToPost}
            onToggleBookmark={handleToggleBookmark}
            onOpenCommentsPage={(post) => setCommentsPostId(post.id)}
            onTogglePinPost={handleTogglePinPost}
            onReportPost={handleReportPost}
            onDeletePost={handleDeletePost}
            onCopyPostLink={handleCopyPostLink}
            onCopyPostText={handleCopyPostText}
            onSharePost={(post) => setShareModalPost(post)}
            onRepost={handleRepost}
          />
        )}

        {/* Tab 3: Live Audio Majlis Rooms */}
        {activeTab === 'rooms' && (
          <MajlisRoomsView
            lang={lang}
            rooms={rooms}
            users={users}
            currentUser={currentUser}
            onToggleJoinRoom={handleToggleJoinRoom}
            onToggleMic={handleToggleMic}
            onSendRoomMessage={handleSendRoomMessage}
            onCreateRoom={handleCreateRoom}
            onToggleHand={handleToggleHand}
            onModerate={handleModerate}
            onCloseRoom={handleCloseRoom}
            onResumeAudio={voice.resumeAudio}
            speaking={voice.speaking}
            micError={voice.micError}
            audioBlocked={voice.audioBlocked}
            isConnected={wsConnected}
            openCreateSignal={openRoomCreateSignal}
          />
        )}

        {/* Tab 4: Direct Messages */}
        {activeTab === 'messages' && (
          <DirectMessagesView
            lang={lang}
            users={users}
            currentUser={currentUser}
            messages={directMessages}
            initialSelectedUserId={selectedDmUserId}
            onSendDirectMessage={handleSendDirectMessage}
            onAddContactUser={handleAddContactUser}
            onUpdateCurrentUser={handleUpdateUser}
          />
        )}

        {/* Tab 5: Full Account & Privacy Settings */}
        {activeTab === 'settings' && (
          <SettingsView
            lang={lang}
            darkMode={darkMode}
            currentUser={currentUser}
            onToggleDarkMode={(d) => setDarkMode(d)}
            onToggleLang={() => setLang((l) => (l === 'ar' ? 'en' : 'ar'))}
            onUpdateUser={handleUpdateUser}
            onLogout={handleLogout}
            onShowToast={showToast}
          />
        )}

        {/* Top Personal Profile Page */}
        {activeTab === 'profile' && (
          <ProfileView
            lang={lang}
            currentUser={currentUser}
            posts={posts}
            onUpdateUser={handleUpdateUser}
            onToggleLike={(postId) => handleReactToPost(postId, 'like')}
            onToggleBookmark={handleToggleBookmark}
            onTogglePinPost={handleTogglePinPost}
            onDeletePost={handleDeletePost}
            onCopyPostLink={handleCopyPostLink}
            onSharePost={(post) => setShareModalPost(post)}
            onOpenCommentsPage={(post) => setCommentsPostId(post.id)}
          />
        )}
      </main>

      {/* In-room bar: stay connected to your voice room while browsing other tabs */}
      {myRoom && activeTab !== 'rooms' && (
        <div className="fixed inset-x-3 bottom-[4.6rem] lg:bottom-4 lg:start-auto lg:end-4 lg:w-80 z-30 rounded-2xl bg-[#0E6B63] text-white shadow-xl px-3 py-2 flex items-center gap-2">
          <button
            type="button"
            onClick={() => setActiveTab('rooms')}
            className="flex-1 min-w-0 flex items-center gap-2 text-start cursor-pointer"
          >
            <Radio className="w-4 h-4 text-[#F2A93B] shrink-0 animate-pulse" />
            <span className="truncate text-xs font-extrabold">
              {isAr ? myRoom.title : myRoom.titleEn}
            </span>
          </button>
          {voice.canSpeak && (
            <button
              type="button"
              onClick={() => handleToggleMic(myRoom.id)}
              className="p-2 rounded-xl bg-white/15 hover:bg-white/25 cursor-pointer"
              aria-label="mic"
            >
              {voice.isMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4 text-[#F2A93B]" />}
            </button>
          )}
          <button
            type="button"
            onClick={() => handleToggleJoinRoom(myRoom.id)}
            className="p-2 rounded-xl bg-red-500/90 hover:bg-red-500 cursor-pointer"
            aria-label="leave"
          >
            <PhoneOff className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Bottom navigation: Home · Videos · ➕ Create · Majlis · Messages */}
      <nav className="lg:hidden fixed bottom-0 inset-x-0 z-30 bg-white/95 dark:bg-[#151D1C]/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 px-1.5 py-1.5 grid grid-cols-5 gap-1 items-end">
        <button
          type="button"
          onClick={handleHomeTabClick}
          className={`min-h-[48px] rounded-xl flex flex-col items-center justify-center gap-0.5 text-[10px] font-extrabold cursor-pointer transition-colors ${
            activeTab === 'feed'
              ? 'text-[#0E6B63] dark:text-[#5FD0C4] bg-[#0E6B63]/10 dark:bg-[#5FD0C4]/10'
              : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <Home className="w-[18px] h-[18px]" />
          <span className="truncate max-w-full px-1">{isAr ? 'الرئيسية' : 'Home'}</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('videos')}
          className={`min-h-[48px] rounded-xl flex flex-col items-center justify-center gap-0.5 text-[10px] font-extrabold cursor-pointer transition-colors ${
            activeTab === 'videos'
              ? 'text-[#0E6B63] dark:text-[#5FD0C4] bg-[#0E6B63]/10 dark:bg-[#5FD0C4]/10'
              : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <span className="relative">
            <Video className="w-[18px] h-[18px]" />
          </span>
          <span className="truncate max-w-full px-1">
            {isAr ? 'فيديو' : 'Video'}
          </span>
        </button>

        <button
          type="button"
          onClick={() => setShowCreateSheet(true)}
          aria-label={isAr ? 'إنشاء' : 'Create'}
          className="justify-self-center -mt-5 w-14 h-14 rounded-full bg-gradient-to-br from-[#0E6B63] to-[#0a524c] text-white shadow-lg shadow-[#0E6B63]/40 ring-4 ring-white dark:ring-[#151D1C] flex items-center justify-center cursor-pointer active:scale-95 transition-transform"
        >
          <Plus className="w-7 h-7" strokeWidth={2.6} />
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('rooms')}
          className={`min-h-[48px] rounded-xl flex flex-col items-center justify-center gap-0.5 text-[10px] font-extrabold cursor-pointer transition-colors ${
            activeTab === 'rooms'
              ? 'text-[#0E6B63] dark:text-[#5FD0C4] bg-[#0E6B63]/10 dark:bg-[#5FD0C4]/10'
              : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <span className="relative">
            <Radio className="w-[18px] h-[18px]" />
            {hasLiveRooms && (
              <span className="absolute -top-0.5 -end-1 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-[#151D1C]" />
            )}
          </span>
          <span className="truncate max-w-full px-1">
            {isAr ? 'المجالس' : 'Majlis'}
          </span>
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('messages')}
          className={`min-h-[48px] rounded-xl flex flex-col items-center justify-center gap-0.5 text-[10px] font-extrabold cursor-pointer transition-colors ${
            activeTab === 'messages'
              ? 'text-[#0E6B63] dark:text-[#5FD0C4] bg-[#0E6B63]/10 dark:bg-[#5FD0C4]/10'
              : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <span className="relative">
            <MessageSquare className="w-[18px] h-[18px]" />
            {unreadDmCount > 0 && (
              <span className="absolute -top-1.5 -end-2.5 min-w-4 h-4 px-1 rounded-full bg-rose-600 text-white text-[9px] font-bold flex items-center justify-center">
                {unreadDmCount > 9 ? '9+' : unreadDmCount}
              </span>
            )}
          </span>
          <span className="truncate max-w-full px-1">
            {isAr ? 'الرسائل' : 'Chat'}
          </span>
        </button>
      </nav>

      {/* Story Viewer Modal (supports Text, Voice, Audio File, Image, Video, Link + Save Media) */}
      {activeStory && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-[#151D1C] border border-slate-200 dark:border-slate-800 rounded-3xl max-w-md w-full overflow-hidden shadow-2xl">
            <div className="p-4 flex items-center justify-between border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2.5">
                <UserAvatar
                  avatarKey={getUser(activeStory.authorId).avatarKey}
                  customAvatarUrl={
                    getUser(activeStory.authorId).customAvatarUrl
                  }
                  name={getUser(activeStory.authorId).name}
                  size="sm"
                />
                <div>
                  <div className="font-bold text-sm text-[#1F1A12] dark:text-white">
                    {getUser(activeStory.authorId).name}
                  </div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400">
                    {formatDynamicTime(
                      activeStory.createdAtMs,
                      activeStory.createdAt,
                      lang,
                      nowTick
                    )}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-1.5">
                {(activeStory.imageUrl || activeStory.videoUrl) && (
                  <button
                    type="button"
                    onClick={() => {
                      downloadMediaToDevice(
                        (activeStory.videoUrl || activeStory.imageUrl)!,
                        'wanas-story'
                      );
                      showToast(
                        isAr
                          ? 'تم حفظ محتوى الستوري في الهاتف ⬇️'
                          : 'Story media saved ⬇️'
                      );
                    }}
                    className="px-2.5 py-1.5 rounded-xl bg-[#0E6B63] text-white text-xs font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>{isAr ? 'حفظ' : 'Save'}</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setActiveStory(null)}
                  className="min-h-[36px] min-w-[36px] rounded-xl flex items-center justify-center text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="p-5 space-y-4">
              {activeStory.storyType === 'text' && (
                <div
                  className="rounded-2xl p-6 min-h-[240px] flex items-center justify-center text-center text-white font-bold text-lg leading-relaxed shadow-inner selectable-text"
                  style={{
                    backgroundColor: activeStory.bgColor || '#0E6B63',
                  }}
                >
                  {activeStory.caption}
                </div>
              )}

              {activeStory.storyType === 'image' && activeStory.imageUrl && (
                <div className="rounded-2xl overflow-hidden bg-black">
                  <img
                    src={activeStory.imageUrl}
                    alt={activeStory.title}
                    className="w-full max-h-80 object-contain"
                  />
                </div>
              )}

              {activeStory.storyType === 'video' && activeStory.videoUrl && (
                <div className="rounded-2xl overflow-hidden bg-black">
                  <video
                    src={activeStory.videoUrl}
                    controls
                    autoPlay
                    playsInline
                    className="w-full max-h-80 object-contain"
                  />
                </div>
              )}

              {(activeStory.storyType === 'voice' ||
                activeStory.storyType === 'audio_file') &&
                activeStory.audioUrl && (
                  <div className="p-5 rounded-2xl bg-[#FAF7F2] dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
                    <AudioWavePlayer
                      audioUrl={activeStory.audioUrl}
                      durationLabel={activeStory.audioDuration || '0:20'}
                      title={activeStory.title}
                    />
                  </div>
                )}

              {activeStory.linkUrl && (
                <a
                  href={activeStory.linkUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3.5 rounded-2xl bg-[#0E6B63]/10 border border-[#0E6B63] text-[#0E6B63] dark:text-[#5FD0C4] font-bold text-xs flex items-center justify-between"
                >
                  <span dir="ltr" className="truncate">
                    {activeStory.linkUrl}
                  </span>
                  <ExternalLink className="w-4 h-4 shrink-0" />
                </a>
              )}

              <div>
                <h4 className="font-extrabold text-base text-[#1F1A12] dark:text-white selectable-text">
                  {activeStory.title}
                </h4>
                {activeStory.storyType !== 'text' && (
                  <p className="text-sm text-slate-600 dark:text-slate-300 mt-1 leading-relaxed selectable-text">
                    {activeStory.caption}
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Create Story Studio Modal with WhatsApp Privacy */}
      {showCreateStoryModal && (
        <CreateStoryModal
          lang={lang}
          currentUser={currentUser}
          users={users}
          onClose={() => setShowCreateStoryModal(false)}
          onCreateStory={handleCreateStory}
        />
      )}

      {/* Full Comments Page Modal with 6-Reactions & AI Smart Reply */}
      {activeCommentsPost && (
        <CommentsSheetModal
          lang={lang}
          post={activeCommentsPost}
          currentUser={currentUser}
          getUser={getUser}
          onClose={() => setCommentsPostId(null)}
          onAddComment={handleAddComment}
          onReactToComment={handleReactToComment}
          onShowToast={showToast}
        />
      )}

      {/* Share to Multiple Friends & Repost Modal */}
      {shareModalPost && (
        <ShareToFriendsModal
          lang={lang}
          post={shareModalPost}
          users={users}
          currentUser={currentUser}
          onClose={() => setShareModalPost(null)}
          onSendPostToUsers={handleSendPostToUsers}
          onRepost={handleRepost}
          onCopyLink={handleCopyPostLink}
          onAddQuickFriend={handleAddContactUser}
        />
      )}

      {/* Quick Photo Studio Modal from Home Sidebar */}
      {homePhotoStudioTarget && (
        <PhotoStudioModal
          lang={lang}
          mode={homePhotoStudioTarget}
          currentImageUrl={
            homePhotoStudioTarget === 'avatar'
              ? currentUser.customAvatarUrl
              : currentUser.customCoverUrl
          }
          currentCoverKey={currentUser.coverKey}
          onClose={() => setHomePhotoStudioTarget(null)}
          onSavePhoto={(dataUrl, coverKey) => {
            if (homePhotoStudioTarget === 'avatar') {
              handleUpdateUser({ customAvatarUrl: dataUrl });
            } else {
              handleUpdateUser({
                customCoverUrl: dataUrl,
                coverKey: coverKey || currentUser.coverKey,
              });
            }
          }}
        />
      )}

      {/* Active Universal Search Modal (People, Posts, Majlis Groups, Community Pages) */}
      {showUniversalSearchModal && (
        <UniversalSearchModal
          lang={lang}
          initialQuery={searchQuery}
          users={users}
          posts={posts.filter(canViewPost)}
          rooms={rooms}
          pages={communityPages}
          currentUser={currentUser}
          onClose={() => setShowUniversalSearchModal(false)}
          onToggleFriend={handleToggleFriend}
          onToggleFollow={handleToggleFollow}
          getUser={getUser}
          onQueryChange={setSearchQuery}
          onMessageUser={(u: User) => {
            setShowUniversalSearchModal(false);
            handleStartMessageWithUser(u);
          }}
          onSelectPost={(post) => {
            setShowUniversalSearchModal(false);
            setActiveTab('feed');
            setCommentsPostId(post.id);
          }}
          onJoinGroupRoom={(roomId: string) => {
            setShowUniversalSearchModal(false);
            handleToggleJoinRoom(roomId);
            setActiveTab('rooms');
          }}
          onToggleFollowPage={handleToggleFollowPage}
          onCreatePage={handleCreatePage}
        />
      )}
    </div>
  );
}

export default App;
