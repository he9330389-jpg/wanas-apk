// Backend origin. Set VITE_API_ORIGIN at build time (e.g. https://wanas.onrender.com)
// when building the Android APK so the app talks to your hosted server.
// Leave empty for the website (same origin).
const API_ORIGIN: string = (
  (import.meta.env?.VITE_API_ORIGIN as string | undefined) || ''
).replace(/\/+$/, '');

function isNativeShell(): boolean {
  if (typeof window === 'undefined') return false;
  const p = window.location.protocol;
  return p === 'file:' || p === 'capacitor:' || p === 'ionic:';
}

/** Resolves API URLs for both the website and the Capacitor Android app. */
export function getApiUrl(path: string): string {
  if (API_ORIGIN) return `${API_ORIGIN}${path}`;
  return path;
}

export function getWsUrl(): string {
  if (typeof window === 'undefined') return '';
  if (API_ORIGIN) return API_ORIGIN.replace(/^http/, 'ws');
  if (isNativeShell()) return '';
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  return `${protocol}//${window.location.host}`;
}

/**
 * Compresses and resizes an image File or DataURL using an HTML5 Canvas
 * so high-resolution photos fit cleanly in storage and load at 60fps.
 */
export async function compressImageSource(
  src: string,
  maxWidth: number,
  maxHeight: number,
  quality = 0.88,
  zoom = 1,
  offsetY = 0
): Promise<string> {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = maxWidth;
        canvas.height = maxHeight;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(src);
          return;
        }

        ctx.fillStyle = '#0F1514';
        ctx.fillRect(0, 0, maxWidth, maxHeight);

        const scale =
          Math.max(maxWidth / img.width, maxHeight / img.height) * zoom;
        const drawW = img.width * scale;
        const drawH = img.height * scale;
        const drawX = (maxWidth - drawW) / 2;
        const drawY = (maxHeight - drawH) / 2 + offsetY;

        ctx.drawImage(img, drawX, drawY, drawW, drawH);
        const compressed = canvas.toDataURL('image/jpeg', quality);
        resolve(compressed);
      } catch {
        resolve(src);
      }
    };
    img.onerror = () => resolve(src);
    img.src = src;
  });
}

export async function readFileAsCompressedDataUrl(
  file: File,
  kind: 'avatar' | 'cover' | 'post'
): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = async () => {
      if (typeof reader.result !== 'string') {
        reject(new Error('Failed to read file'));
        return;
      }
      if (kind === 'avatar') {
        const out = await compressImageSource(reader.result, 512, 512, 0.88);
        resolve(out);
      } else if (kind === 'cover') {
        const out = await compressImageSource(reader.result, 1280, 540, 0.88);
        resolve(out);
      } else {
        // High-clarity post photo while keeping Aspect Ratio natural
        const img = new Image();
        img.onload = () => {
          const maxDim = 1280;
          let w = img.width || 1080;
          let h = img.height || 1080;
          if (w > maxDim || h > maxDim) {
            if (w > h) {
              h = Math.round((h * maxDim) / w);
              w = maxDim;
            } else {
              w = Math.round((w * maxDim) / h);
              h = maxDim;
            }
          }
          compressImageSource(reader.result as string, w, h, 0.88).then(resolve);
        };
        img.onerror = () => resolve(reader.result as string);
        img.src = reader.result;
      }
    };
    reader.onerror = () => reject(new Error('File read error'));
    reader.readAsDataURL(file);
  });
}

function formatSeconds(sec: number): string {
  if (!Number.isFinite(sec) || sec <= 0) return '0:15';
  const total = Math.max(1, Math.round(sec));
  const m = Math.floor(total / 60);
  const s = total % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}

/**
 * Reads an audio or video file from the user's phone into a playable URL
 * and measures its real duration.
 */
export async function readMediaFileWithDuration(
  file: File,
  kind: 'video' | 'audio'
): Promise<{ dataUrl: string; duration: string; fileName: string }> {
  return new Promise((resolve, reject) => {
    const objectUrl = URL.createObjectURL(file);
    let measuredDuration = kind === 'video' ? '0:30' : '0:20';

    const probe = document.createElement(kind);
    probe.preload = 'metadata';
    probe.src = objectUrl;

    const finalizeRead = () => {
      const reader = new FileReader();
      reader.onload = () => {
        URL.revokeObjectURL(objectUrl);
        if (typeof reader.result === 'string') {
          resolve({
            dataUrl: reader.result,
            duration: measuredDuration,
            fileName: file.name,
          });
        } else {
          reject(new Error('Invalid file data'));
        }
      };
      reader.onerror = () => {
        // Fallback to objectUrl if file is huge
        resolve({
          dataUrl: objectUrl,
          duration: measuredDuration,
          fileName: file.name,
        });
      };
      reader.readAsDataURL(file);
    };

    const timer = window.setTimeout(() => {
      finalizeRead();
    }, 1200);

    probe.onloadedmetadata = () => {
      window.clearTimeout(timer);
      if (probe.duration && Number.isFinite(probe.duration)) {
        measuredDuration = formatSeconds(probe.duration);
      }
      finalizeRead();
    };

    probe.onerror = () => {
      window.clearTimeout(timer);
      finalizeRead();
    };
  });
}

/**
 * Saves/downloads a published photo, video, or audio clip directly to the user's device.
 */
export function downloadMediaToDevice(
  mediaUrl: string,
  defaultName = 'wanas-media'
): void {
  try {
    const a = document.createElement('a');
    a.href = mediaUrl;
    let ext = 'jpg';
    if (mediaUrl.startsWith('data:video/') || defaultName.includes('video')) {
      ext = 'mp4';
    } else if (
      mediaUrl.startsWith('data:audio/') ||
      defaultName.includes('audio')
    ) {
      ext = 'mp3';
    } else if (mediaUrl.startsWith('data:image/png')) {
      ext = 'png';
    }
    a.download = `${defaultName}-${Date.now()}.${ext}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  } catch {
    // ignore
  }
}
