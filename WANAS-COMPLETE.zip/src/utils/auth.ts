import { getApiUrl } from './mediaUtils.ts';

const TOKEN_KEY = 'wanas_token_v1';

export function getToken(): string | null {
  try {
    return localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

export function setToken(token: string) {
  try {
    localStorage.setItem(TOKEN_KEY, token);
  } catch {
    // ignore
  }
}

export function clearToken() {
  try {
    localStorage.removeItem(TOKEN_KEY);
  } catch {
    // ignore
  }
}

/**
 * Adds the session token to every request that goes to the WANAS API,
 * so existing fetch() calls across the app are authenticated without changes.
 */
export function installAuthFetch() {
  if (typeof window === 'undefined') return;
  const w = window as Window & { __wanasFetchPatched?: boolean };
  if (w.__wanasFetchPatched) return;
  w.__wanasFetchPatched = true;
  const original = window.fetch.bind(window);
  const apiBase = getApiUrl('/api/');
  window.fetch = (input: RequestInfo | URL, init?: RequestInit) => {
    const url =
      typeof input === 'string' ? input : input instanceof URL ? input.href : input.url;
    const token = getToken();
    if (token && url.startsWith(apiBase)) {
      const headers = new Headers(
        init?.headers || (typeof input === 'object' && 'headers' in input ? input.headers : undefined)
      );
      if (!headers.has('Authorization')) headers.set('Authorization', `Bearer ${token}`);
      return original(input, { ...init, headers });
    }
    return original(input, init);
  };
}
