import type { Language } from '../types.ts';

const MONTHS_AR = [
  'يناير',
  'فبراير',
  'مارس',
  'أبريل',
  'مايو',
  'يونيو',
  'يوليو',
  'أغسطس',
  'سبتمبر',
  'أكتوبر',
  'نوفمبر',
  'ديسمبر',
];

const MONTHS_EN = [
  'Jan',
  'Feb',
  'Mar',
  'Apr',
  'May',
  'Jun',
  'Jul',
  'Aug',
  'Sep',
  'Oct',
  'Nov',
  'Dec',
];

/**
 * Formats a timestamp (in ms) into natural dynamic Arabic/English relative time:
 * - "الآن"
 * - "منذ دقيقة" / "منذ دقيقتين" / "منذ 3 دقائق" ...
 * - "منذ ساعة" / "منذ ساعتين" / "منذ 5 ساعات"
 * - "منذ يوم" / "منذ يومين" / "منذ 4 أيام"
 * - Or full date: "19 نوفمبر 2023" / "26/10/2026"
 */
export function formatDynamicTime(
  createdAtMs?: number,
  fallbackText?: string,
  lang: Language = 'ar',
  nowMs: number = Date.now()
): string {
  const isAr = lang === 'ar';
  if (!createdAtMs || Number.isNaN(createdAtMs)) {
    return fallbackText || (isAr ? 'الآن' : 'Just now');
  }

  const diffSec = Math.max(0, Math.floor((nowMs - createdAtMs) / 1000));

  if (diffSec < 45) {
    return isAr ? 'الآن' : 'Just now';
  }

  const diffMin = Math.floor(diffSec / 60);
  if (diffMin === 1) {
    return isAr ? 'منذ دقيقة' : '1 min ago';
  }
  if (diffMin === 2) {
    return isAr ? 'منذ دقيقتين' : '2 mins ago';
  }
  if (diffMin >= 3 && diffMin <= 10) {
    return isAr ? `منذ ${diffMin} دقائق` : `${diffMin} mins ago`;
  }
  if (diffMin < 60) {
    return isAr ? `منذ ${diffMin} دقيقة` : `${diffMin} mins ago`;
  }

  const diffHours = Math.floor(diffMin / 60);
  if (diffHours === 1) {
    return isAr ? 'منذ ساعة' : '1 hr ago';
  }
  if (diffHours === 2) {
    return isAr ? 'منذ ساعتين' : '2 hrs ago';
  }
  if (diffHours >= 3 && diffHours <= 10) {
    return isAr ? `منذ ${diffHours} ساعات` : `${diffHours} hrs ago`;
  }
  if (diffHours < 24) {
    return isAr ? `منذ ${diffHours} ساعة` : `${diffHours} hrs ago`;
  }

  const diffDays = Math.floor(diffHours / 24);
  if (diffDays === 1) {
    return isAr ? 'منذ يوم' : 'Yesterday';
  }
  if (diffDays === 2) {
    return isAr ? 'منذ يومين' : '2 days ago';
  }
  if (diffDays >= 3 && diffDays <= 6) {
    return isAr ? `منذ ${diffDays} أيام` : `${diffDays} days ago`;
  }

  const d = new Date(createdAtMs);
  const day = d.getDate();
  const monthIdx = d.getMonth();
  const year = d.getFullYear();

  if (isAr) {
    return `${day}/${monthIdx + 1} · ${day} ${MONTHS_AR[monthIdx]} ${year}`;
  }
  return `${day} ${MONTHS_EN[monthIdx]} ${year}`;
}

/**
 * Formats user's online / active status ("نشط الآن" / "نشط منذ 5 دقائق" / "حالة الظهور مخفية")
 */
export function formatUserPresence(
  isOnline: boolean | undefined,
  showOnlineStatus: boolean | undefined,
  lastActiveAtMs: number | undefined,
  lang: Language = 'ar',
  nowMs: number = Date.now()
): { label: string; isVisibleOnline: boolean } {
  const isAr = lang === 'ar';
  if (showOnlineStatus === false) {
    return {
      label: isAr ? 'حالة النشاط مخفية' : 'Activity status hidden',
      isVisibleOnline: false,
    };
  }

  if (isOnline !== false) {
    return {
      label: isAr ? 'نشط الآن' : 'Active now',
      isVisibleOnline: true,
    };
  }

  if (lastActiveAtMs) {
    const rel = formatDynamicTime(lastActiveAtMs, undefined, lang, nowMs);
    return {
      label: isAr ? `نشط ${rel}` : `Active ${rel}`,
      isVisibleOnline: false,
    };
  }

  return {
    label: isAr ? 'نشط منذ قليل' : 'Active recently',
    isVisibleOnline: false,
  };
}
