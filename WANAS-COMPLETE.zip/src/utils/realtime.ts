import { getWsUrl } from './mediaUtils.ts';
import { getToken } from './auth.ts';

type Handler = (payload: any) => void;

/**
 * One shared WebSocket to the WANAS server with automatic reconnect, keep-alive,
 * and re-authentication. Everything real-time (feed events, DMs, voice rooms,
 * WebRTC signalling) goes through here.
 */
class Realtime {
  private ws: WebSocket | null = null;
  private handlers = new Map<string, Set<Handler>>();
  private statusHandlers = new Set<(connected: boolean) => void>();
  private retry = 0;
  private reconnectTimer: number | null = null;
  private pingTimer: number | null = null;
  private started = false;
  connected = false;

  start() {
    if (this.started) return;
    this.started = true;
    this.open();
  }

  private open() {
    const url = getWsUrl();
    if (!url) return;
    let ws: WebSocket;
    try {
      ws = new WebSocket(url);
    } catch {
      this.scheduleReconnect();
      return;
    }
    this.ws = ws;
    ws.onopen = () => {
      this.retry = 0;
      this.setConnected(true);
      this.hello();
      this.dispatch('__open', null);
      this.pingTimer = window.setInterval(() => this.send('ping', null), 25000);
    };
    ws.onmessage = (e) => {
      try {
        const { event, payload } = JSON.parse(e.data);
        this.dispatch(event, payload);
      } catch {
        // ignore malformed frames
      }
    };
    ws.onclose = () => {
      if (this.ws === ws) this.ws = null;
      this.setConnected(false);
      if (this.pingTimer) window.clearInterval(this.pingTimer);
      this.pingTimer = null;
      this.dispatch('__close', null);
      if (this.started) this.scheduleReconnect();
    };
    ws.onerror = () => {
      try {
        ws.close();
      } catch {
        // ignore
      }
    };
  }

  private scheduleReconnect() {
    if (this.reconnectTimer) return;
    const delay = Math.min(15000, 800 * 2 ** this.retry++);
    this.reconnectTimer = window.setTimeout(() => {
      this.reconnectTimer = null;
      this.open();
    }, delay);
  }

  private setConnected(v: boolean) {
    this.connected = v;
    this.statusHandlers.forEach((fn) => fn(v));
  }

  private dispatch(event: string, payload: unknown) {
    this.handlers.get(event)?.forEach((fn) => fn(payload));
  }

  /** Identify this socket with the saved session token (call again after login). */
  hello() {
    const token = getToken();
    if (token) this.send('hello', { token });
  }

  /** Drop the current socket and reconnect anonymously (used on logout). */
  reset() {
    try {
      this.ws?.close();
    } catch {
      // ignore
    }
  }

  send(event: string, payload: unknown): boolean {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ event, payload }));
      return true;
    }
    return false;
  }

  on(event: string, fn: Handler): () => void {
    if (!this.handlers.has(event)) this.handlers.set(event, new Set());
    this.handlers.get(event)!.add(fn);
    return () => this.handlers.get(event)?.delete(fn);
  }

  onStatus(fn: (connected: boolean) => void): () => void {
    this.statusHandlers.add(fn);
    return () => this.statusHandlers.delete(fn);
  }
}

export const realtime = new Realtime();
