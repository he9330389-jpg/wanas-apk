import React, { useEffect, useRef, useState } from 'react';
import {
  Mic,
  MicOff,
  Radio,
  Send,
  Users,
  Plus,
  LogOut,
  Volume2,
  Hand,
  ArrowUpFromLine,
  ArrowDownToLine,
  UserX,
  XCircle,
  VolumeX,
  WifiOff,
} from 'lucide-react';
import type { Language, MajlisRoom, User } from '../types.ts';
import { UserAvatar } from './VisualAssets.tsx';

interface MajlisRoomsViewProps {
  lang: Language;
  rooms: MajlisRoom[];
  users: User[];
  currentUser: User;
  onToggleJoinRoom: (roomId: string) => void;
  onToggleMic: (roomId: string) => void;
  onSendRoomMessage: (roomId: string, text: string) => void;
  onCreateRoom: (title: string, topic: string) => void;
  onToggleHand: (raised: boolean) => void;
  onModerate: (userId: string, action: 'promote' | 'demote' | 'mute' | 'kick') => void;
  onCloseRoom: (roomId: string) => void;
  onResumeAudio: () => void;
  speaking: Record<string, boolean>;
  micError: 'denied' | 'unsupported' | null;
  audioBlocked: boolean;
  isConnected: boolean;
  openCreateSignal?: number;
}

export const MajlisRoomsView: React.FC<MajlisRoomsViewProps> = ({
  lang,
  rooms,
  users,
  currentUser,
  onToggleJoinRoom,
  onToggleMic,
  onSendRoomMessage,
  onCreateRoom,
  onToggleHand,
  onModerate,
  onCloseRoom,
  onResumeAudio,
  speaking,
  micError,
  audioBlocked,
  isConnected,
  openCreateSignal,
}) => {
  const isAr = lang === 'ar';
  const [activeRoomId, setActiveRoomId] = useState<string>(rooms[0]?.id || '');
  const [messageText, setMessageText] = useState<string>('');
  const [showNewRoomModal, setShowNewRoomModal] = useState<boolean>(false);
  const [newRoomTitle, setNewRoomTitle] = useState<string>('');
  const [newRoomTopic, setNewRoomTopic] = useState<string>('');

  const lastSignal = useRef<number>(openCreateSignal || 0);
  useEffect(() => {
    if ((openCreateSignal || 0) > lastSignal.current) {
      lastSignal.current = openCreateSignal || 0;
      setShowNewRoomModal(true);
    }
  }, [openCreateSignal]);

  // Follow the room I'm actually in
  const myRoom = rooms.find((r) => r.participants.some((p) => p.userId === currentUser.id));
  useEffect(() => {
    if (myRoom) setActiveRoomId(myRoom.id);
  }, [myRoom?.id]);

  const chatEndRef = useRef<HTMLDivElement | null>(null);

  const activeRoom = rooms.find((r) => r.id === activeRoomId) || rooms[0];
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ block: 'end' });
  }, [activeRoom?.messages.length]);
  const getUser = (id: string) => users.find((u) => u.id === id) || currentUser;

  const isCurrentUserInRoom = activeRoom?.participants.some(
    (p) => p.userId === currentUser.id
  );
  const currentParticipant = activeRoom?.participants.find(
    (p) => p.userId === currentUser.id
  );

  const iAmHost = currentParticipant?.role === 'host';

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeRoom || !messageText.trim()) return;
    onSendRoomMessage(activeRoom.id, messageText.trim());
    setMessageText('');
  };

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRoomTitle.trim()) return;
    onCreateRoom(
      newRoomTitle.trim(),
      newRoomTopic.trim() ||
        (isAr ? 'نقاش مفتوح لأعضاء مجتمع ونس' : 'Open community discussion')
    );
    setNewRoomTitle('');
    setNewRoomTopic('');
    setShowNewRoomModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Header Strip */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-[#151D1C] border border-slate-200/80 dark:border-slate-800 rounded-3xl p-5 shadow-xs">
        <div className="space-y-1">
          <h2 className="text-xl font-extrabold text-[#1F1A12] dark:text-white flex items-center gap-2">
            <Radio className="w-5 h-5 text-[#F2A93B]" />
            <span>{isAr ? 'مجالس ونس الصوتية المباشرة' : 'Live WANAS Audio Majlis Rooms'}</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
            {isAr
              ? 'افتح مجلسك الصوتي المباشر وادعُ أصدقاءك ومتابعيك للحوار الحي والدردشة الفورية.'
              : 'Launch your live audio room and invite friends and followers for real-time conversation.'}
          </p>
        </div>

        <button
          type="button"
          onClick={() => setShowNewRoomModal(true)}
          className="min-h-[44px] px-4 py-2.5 rounded-xl bg-[#0E6B63] hover:bg-[#0B5650] text-white text-sm font-bold flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 self-start sm:self-center cursor-pointer shadow-xs"
        >
          <Plus className="w-4 h-4" />
          <span>{isAr ? 'إنشاء مجلس صوتي جديد' : 'Start New Majlis'}</span>
        </button>
      </div>

      {/* Room Switcher Grid + Active Stage */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left List of Rooms */}
        <div className="lg:col-span-5 space-y-3">
          {rooms.map((room) => {
            const isSelected = room.id === activeRoom?.id;
            const host = getUser(room.hostId);
            return (
              <div
                key={room.id}
                onClick={() => setActiveRoomId(room.id)}
                className={`p-4 rounded-2xl border transition-colors cursor-pointer ${
                  isSelected
                    ? 'bg-white dark:bg-[#151D1C] border-[#0E6B63] dark:border-[#5FD0C4] shadow-xs'
                    : 'bg-white/80 dark:bg-[#151D1C]/70 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-2">
                  <span>
                    {isAr ? 'المضيف:' : 'Host:'} {isAr ? host.name : host.nameEn}
                  </span>
                  <span className="font-mono tabular-nums text-[#F2A93B] font-bold">
                    {room.participants.length} {isAr ? 'متواجد' : 'joined'}
                  </span>
                </div>
                <h3 className="font-bold text-base text-[#1F1A12] dark:text-white mb-1">
                  {isAr ? room.title : room.titleEn}
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2 mb-3">
                  {isAr ? room.topic : room.topicEn}
                </p>
                <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800/80">
                  <div className="flex -space-x-2 rtl:space-x-reverse overflow-hidden">
                    {room.participants.slice(0, 4).map((p) => {
                      const u = getUser(p.userId);
                      return (
                        <UserAvatar
                          key={p.userId}
                          avatarKey={u.avatarKey}
                          customAvatarUrl={u.customAvatarUrl}
                          name={u.name}
                          size="sm"
                        />
                      );
                    })}
                  </div>
                  <span className="text-xs font-bold text-[#0E6B63] dark:text-[#5FD0C4]">
                    {isAr ? 'فتح المجلس ←' : 'Open Lounge →'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right Active Audio Stage & Live Room Chat */}
        {activeRoom && (
          <div className="lg:col-span-7 bg-white dark:bg-[#151D1C] border border-slate-200/80 dark:border-slate-800 rounded-3xl p-5 sm:p-6 flex flex-col justify-between space-y-6 shadow-xs">
            {/* Stage Header */}
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 pb-4 border-b border-slate-200 dark:border-slate-800">
                <div>
                  <div className="text-xs text-[#F2A93B] font-bold mb-1 flex items-center gap-1.5">
                    <Volume2 className="w-4 h-4" />
                    <span>{isAr ? 'بث صوتي مباشر الآن' : 'Live Audio Stage'}</span>
                  </div>
                  <h3 className="text-lg sm:text-xl font-bold text-[#1F1A12] dark:text-white">
                    {isAr ? activeRoom.title : activeRoom.titleEn}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1">
                    {isAr ? activeRoom.topic : activeRoom.topicEn}
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {isCurrentUserInRoom && currentParticipant?.role !== 'listener' && (
                    <button
                      type="button"
                      onClick={() => onToggleMic(activeRoom.id)}
                      disabled={micError !== null}
                      className={`min-h-[44px] px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50 ${
                        currentParticipant?.isMuted
                          ? 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                          : 'bg-[#F2A93B]/15 text-amber-800 dark:text-[#F2A93B] border border-[#F2A93B]/40'
                      }`}
                    >
                      {currentParticipant?.isMuted ? (
                        <>
                          <MicOff className="w-4 h-4" />
                          <span>{isAr ? 'المايك مكتوم — اضغط للتحدث' : 'Muted — tap to talk'}</span>
                        </>
                      ) : (
                        <>
                          <Mic className="w-4 h-4" />
                          <span>{isAr ? 'المايك مفعل' : 'Mic On'}</span>
                        </>
                      )}
                    </button>
                  )}

                  {isCurrentUserInRoom && currentParticipant?.role === 'listener' && (
                    <button
                      type="button"
                      onClick={() => onToggleHand(!currentParticipant?.handRaised)}
                      className={`min-h-[44px] px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                        currentParticipant?.handRaised
                          ? 'bg-[#F2A93B]/20 text-amber-800 dark:text-[#F2A93B] border border-[#F2A93B]/50'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      <Hand className="w-4 h-4" />
                      <span>
                        {currentParticipant?.handRaised
                          ? isAr ? 'خفض يدك' : 'Lower hand'
                          : isAr ? 'اطلب الكلام' : 'Raise hand'}
                      </span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => onToggleJoinRoom(activeRoom.id)}
                    className={`min-h-[44px] px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                      isCurrentUserInRoom
                        ? 'bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400 border border-red-200 dark:border-red-800'
                        : 'bg-[#0E6B63] hover:bg-[#0B5650] text-white'
                    }`}
                  >
                    {isCurrentUserInRoom ? (
                      <>
                        <LogOut className="w-4 h-4" />
                        <span>{isAr ? 'مغادرة المجلس' : 'Leave Room'}</span>
                      </>
                    ) : (
                      <>
                        <Users className="w-4 h-4" />
                        <span>{isAr ? 'انضمام للمجلس' : 'Join Majlis'}</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Status banners */}
              {!isConnected && (
                <div className="flex items-center gap-2 text-xs font-bold px-3 py-2 rounded-xl bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-300 border border-red-200 dark:border-red-900">
                  <WifiOff className="w-4 h-4" />
                  <span>{isAr ? 'انقطع الاتصال بالسيرفر… جاري إعادة المحاولة' : 'Connection lost… reconnecting'}</span>
                </div>
              )}
              {isCurrentUserInRoom && micError && currentParticipant?.role !== 'listener' && (
                <div className="text-xs font-bold px-3 py-2 rounded-xl bg-amber-50 dark:bg-amber-950/30 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-900">
                  {micError === 'denied'
                    ? isAr
                      ? 'لم يتم السماح باستخدام المايك. فعّل إذن الميكروفون للتطبيق من إعدادات الهاتف ثم أعد الانضمام.'
                      : 'Microphone permission denied. Enable it in phone settings, then rejoin.'
                    : isAr
                    ? 'هذا الجهاز لا يدعم الميكروفون.'
                    : 'This device does not support microphone input.'}
                </div>
              )}
              {isCurrentUserInRoom && audioBlocked && (
                <button
                  type="button"
                  onClick={onResumeAudio}
                  className="w-full flex items-center justify-center gap-2 text-xs font-bold px-3 py-2.5 rounded-xl bg-[#0E6B63] text-white cursor-pointer"
                >
                  <Volume2 className="w-4 h-4" />
                  <span>{isAr ? 'اضغط لتفعيل صوت المجلس' : 'Tap to enable room audio'}</span>
                </button>
              )}

              {activeRoom.participants.length === 0 ? (
                <div className="py-8 text-center text-xs text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-900/50 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800">
                  {isAr
                    ? 'المجلس فاضي حالياً. اضغط على «انضمام للمجلس» لتكون أول المتواجدين!'
                    : 'The room is empty. Tap "Join Majlis" to be the first one in!'}
                </div>
              ) : (
                <>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 py-2">
                    {activeRoom.participants
                      .filter((part) => part.role !== 'listener')
                      .map((part) => {
                        const u = getUser(part.userId);
                        const isTalking = Boolean(speaking[part.userId]) && !part.isMuted;
                        const canModerate = iAmHost && part.userId !== currentUser.id;
                        return (
                          <div
                            key={part.userId}
                            className={`flex flex-col items-center text-center p-3 rounded-2xl bg-[#FAF7F2] dark:bg-slate-900/60 border transition-colors ${
                              isTalking
                                ? 'border-[#5FD0C4] shadow-[0_0_0_2px_rgba(95,208,196,0.35)]'
                                : 'border-slate-200/70 dark:border-slate-800'
                            }`}
                          >
                            <UserAvatar
                              avatarKey={u.avatarKey}
                              customAvatarUrl={u.customAvatarUrl}
                              name={u.name}
                              size="lg"
                              isSpeaking={isTalking}
                            />
                            <div className="mt-2 font-bold text-xs sm:text-sm text-[#1F1A12] dark:text-white truncate max-w-full">
                              {isAr ? u.name : u.nameEn}
                            </div>
                            <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1 mt-0.5">
                              {part.isMuted ? (
                                <MicOff className="w-3 h-3" />
                              ) : (
                                <Mic className="w-3 h-3 text-[#0E6B63] dark:text-[#5FD0C4]" />
                              )}
                              <span>
                                {part.role === 'host' ? (isAr ? 'مضيف' : 'Host') : isAr ? 'متحدث' : 'Speaker'}
                              </span>
                            </div>
                            {canModerate && (
                              <div className="flex items-center gap-1 mt-2">
                                {!part.isMuted && (
                                  <button
                                    type="button"
                                    onClick={() => onModerate(part.userId, 'mute')}
                                    title={isAr ? 'كتم' : 'Mute'}
                                    className="p-1.5 rounded-lg bg-slate-200/70 dark:bg-slate-800 hover:bg-slate-300 cursor-pointer"
                                  >
                                    <VolumeX className="w-3.5 h-3.5" />
                                  </button>
                                )}
                                {part.role === 'speaker' && (
                                  <button
                                    type="button"
                                    onClick={() => onModerate(part.userId, 'demote')}
                                    title={isAr ? 'نقله للمستمعين' : 'Move to listeners'}
                                    className="p-1.5 rounded-lg bg-slate-200/70 dark:bg-slate-800 hover:bg-slate-300 cursor-pointer"
                                  >
                                    <ArrowDownToLine className="w-3.5 h-3.5" />
                                  </button>
                                )}
                                <button
                                  type="button"
                                  onClick={() => onModerate(part.userId, 'kick')}
                                  title={isAr ? 'إخراج من المجلس' : 'Remove'}
                                  className="p-1.5 rounded-lg bg-red-100 dark:bg-red-950/50 text-red-600 hover:bg-red-200 cursor-pointer"
                                >
                                  <UserX className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            )}
                          </div>
                        );
                      })}
                  </div>

                  {activeRoom.participants.some((part) => part.role === 'listener') && (
                    <div className="space-y-2">
                      <div className="text-xs font-bold text-slate-500 dark:text-slate-400">
                        {isAr ? 'المستمعون:' : 'Listeners:'}
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {activeRoom.participants
                          .filter((part) => part.role === 'listener')
                          .map((part) => {
                            const u = getUser(part.userId);
                            const canModerate = iAmHost && part.userId !== currentUser.id;
                            return (
                              <div
                                key={part.userId}
                                className="flex items-center gap-2 ps-1.5 pe-2.5 py-1 rounded-2xl bg-slate-100 dark:bg-slate-900/70 text-xs"
                              >
                                <UserAvatar
                                  avatarKey={u.avatarKey}
                                  customAvatarUrl={u.customAvatarUrl}
                                  name={u.name}
                                  size="sm"
                                />
                                <span className="font-bold truncate max-w-[110px]">{isAr ? u.name : u.nameEn}</span>
                                {part.handRaised && <Hand className="w-3.5 h-3.5 text-[#F2A93B]" />}
                                {canModerate && (
                                  <>
                                    <button
                                      type="button"
                                      onClick={() => onModerate(part.userId, 'promote')}
                                      title={isAr ? 'إعطاء المايك' : 'Give the mic'}
                                      className="p-1 rounded-lg bg-[#0E6B63]/10 text-[#0E6B63] dark:text-[#5FD0C4] cursor-pointer"
                                    >
                                      <ArrowUpFromLine className="w-3.5 h-3.5" />
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => onModerate(part.userId, 'kick')}
                                      title={isAr ? 'إخراج' : 'Remove'}
                                      className="p-1 rounded-lg text-red-500 cursor-pointer"
                                    >
                                      <UserX className="w-3.5 h-3.5" />
                                    </button>
                                  </>
                                )}
                              </div>
                            );
                          })}
                      </div>
                    </div>
                  )}
                </>
              )}

              {activeRoom.hostId === currentUser.id && (
                <button
                  type="button"
                  onClick={() => {
                    if (window.confirm(isAr ? 'إغلاق المجلس نهائياً وحذف رسائله؟' : 'Close this room permanently?')) {
                      onCloseRoom(activeRoom.id);
                    }
                  }}
                  className="flex items-center gap-1.5 text-xs font-bold text-red-600 dark:text-red-400 cursor-pointer"
                >
                  <XCircle className="w-4 h-4" />
                  <span>{isAr ? 'إغلاق المجلس' : 'Close room'}</span>
                </button>
              )}
            </div>

            {/* Live Room Chat Box */}
            <div className="border-t border-slate-200 dark:border-slate-800 pt-4 space-y-3">
              <div className="text-xs font-bold text-slate-500 dark:text-slate-400">
                {isAr ? 'دردشة المجلس المباشرة:' : 'Live Majlis Chat:'}
              </div>
              <div className="space-y-2.5 max-h-52 overflow-y-auto pe-1">
                {activeRoom.messages.length === 0 ? (
                  <p className="text-xs text-slate-400 dark:text-slate-500 py-4 text-center">
                    {isAr ? 'ابدأ الحوار في دردشة المجلس الآن...' : 'Start the room chat now...'}
                  </p>
                ) : (
                  activeRoom.messages.map((m) => {
                    const sender = getUser(m.senderId);
                    return (
                      <div
                        key={m.id}
                        className="flex items-start gap-2.5 text-xs sm:text-sm bg-[#FAF7F2] dark:bg-slate-900/50 p-3 rounded-2xl"
                      >
                        <UserAvatar
                          avatarKey={sender.avatarKey}
                          customAvatarUrl={sender.customAvatarUrl}
                          name={sender.name}
                          size="sm"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                            <span className="font-bold text-[#1F1A12] dark:text-white">
                              {isAr ? sender.name : sender.nameEn}
                            </span>
                            <span aria-hidden="true">·</span>
                            <span className="font-mono tabular-nums">{m.createdAt}</span>
                          </div>
                          <p className="text-slate-700 dark:text-slate-200 mt-0.5 break-words">
                            {m.text}
                          </p>
                        </div>
                      </div>
                    );
                  })
                )}
                <div ref={chatEndRef} />
              </div>

              <form onSubmit={handleSendMessage} className="flex items-center gap-2 pt-1">
                <input
                  type="text"
                  value={messageText}
                  onChange={(e) => setMessageText(e.target.value)}
                  disabled={!isCurrentUserInRoom}
                  placeholder={
                    !isCurrentUserInRoom
                      ? isAr
                        ? 'انضم للمجلس لتتمكن من الكتابة'
                        : 'Join the room to chat'
                      : isAr
                      ? 'اكتب رسالة لأعضاء المجلس...'
                      : 'Write a message to the room...'
                  }
                  className="flex-1 min-h-[44px] px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-900 text-sm text-[#1F1A12] dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#0E6B63]"
                />
                <button
                  type="submit"
                  className="min-h-[44px] min-w-[44px] px-4 py-2 rounded-xl bg-[#0E6B63] hover:bg-[#0B5650] text-white text-sm font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span className="hidden sm:inline">{isAr ? 'إرسال' : 'Send'}</span>
                </button>
              </form>
            </div>
          </div>
        )}
      </div>

      {/* Create New Majlis Modal */}
      {showNewRoomModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-[#151D1C] border border-slate-200 dark:border-slate-800 rounded-3xl max-w-md w-full p-6 space-y-4">
            <h3 className="text-lg font-extrabold text-[#1F1A12] dark:text-white">
              {isAr ? 'إنشاء مجلس ونس صوتي جديد' : 'Create New WANAS Audio Majlis'}
            </h3>
            <form onSubmit={handleCreateSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 mb-1">
                  {isAr ? 'عنوان المجلس' : 'Majlis Title'}
                </label>
                <input
                  type="text"
                  required
                  value={newRoomTitle}
                  onChange={(e) => setNewRoomTitle(e.target.value)}
                  placeholder={
                    isAr ? 'مثال: مجلس السمر والأصدقاء' : 'e.g., Evening Friends Lounge'
                  }
                  className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent text-sm text-[#1F1A12] dark:text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 mb-1">
                  {isAr ? 'موضوع النقاش' : 'Discussion Topic'}
                </label>
                <textarea
                  rows={3}
                  value={newRoomTopic}
                  onChange={(e) => setNewRoomTopic(e.target.value)}
                  placeholder={
                    isAr
                      ? 'صف باختصار ما سنتحدث عنه في هذا المجلس...'
                      : 'Briefly describe what this lounge is about...'
                  }
                  className="w-full p-3.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent text-sm text-[#1F1A12] dark:text-white resize-none"
                />
              </div>
              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowNewRoomModal(false)}
                  className="min-h-[44px] px-4 py-2 rounded-xl text-sm text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="min-h-[44px] px-5 py-2 rounded-xl bg-[#0E6B63] hover:bg-[#0B5650] text-white text-sm font-bold cursor-pointer"
                >
                  {isAr ? 'إطلاق المجلس الآن' : 'Launch Majlis'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
