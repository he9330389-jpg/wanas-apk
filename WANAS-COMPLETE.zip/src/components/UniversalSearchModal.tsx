import React, { useState } from 'react';
import {
  Search,
  X,
  Users,
  FileText,
  Radio,
  Flag,
  UserPlus,
  UserCheck,
  MessageSquare,
  CheckCircle2,
  MapPin,
  Plus,
} from 'lucide-react';
import type {
  Language,
  User,
  Post,
  MajlisRoom,
  CommunityPage,
} from '../types.ts';
import { UserAvatar } from './VisualAssets.tsx';

interface UniversalSearchModalProps {
  lang: Language;
  initialQuery: string;
  currentUser: User;
  users: User[];
  posts: Post[];
  rooms: MajlisRoom[];
  pages: CommunityPage[];
  getUser: (id: string) => User;
  onClose: () => void;
  onQueryChange: (q: string) => void;
  onToggleFriend: (userId: string) => void;
  onToggleFollow: (userId: string) => void;
  onMessageUser: (user: User) => void;
  onSelectPost: (post: Post) => void;
  onJoinGroupRoom: (roomId: string) => void;
  onToggleFollowPage: (pageId: string) => void;
  onCreatePage: (title: string, category: string, description: string) => void;
}

type SearchCategoryTab = 'all' | 'people' | 'posts' | 'groups' | 'pages';

export const UniversalSearchModal: React.FC<UniversalSearchModalProps> = ({
  lang,
  initialQuery,
  currentUser,
  users,
  posts,
  rooms,
  pages,
  getUser,
  onClose,
  onQueryChange,
  onToggleFriend,
  onToggleFollow,
  onMessageUser,
  onSelectPost,
  onJoinGroupRoom,
  onToggleFollowPage,
  onCreatePage,
}) => {
  const isAr = lang === 'ar';
  const [query, setQuery] = useState<string>(initialQuery);
  const [activeCat, setActiveCat] = useState<SearchCategoryTab>('all');
  const [showCreatePageForm, setShowCreatePageForm] = useState(false);
  const [newPageTitle, setNewPageTitle] = useState('');
  const [newPageCategory, setNewPageCategory] = useState('');
  const [newPageDesc, setNewPageDesc] = useState('');

  const q = query.trim().toLowerCase();

  // Filter People
  const matchedPeople = users.filter((u) => {
    if (u.id === currentUser.id) return false;
    if (!q) return true;
    return (
      u.name.toLowerCase().includes(q) ||
      u.nameEn.toLowerCase().includes(q) ||
      u.handle.toLowerCase().includes(q) ||
      (u.country || '').toLowerCase().includes(q) ||
      (u.city || '').toLowerCase().includes(q) ||
      (u.role || '').toLowerCase().includes(q) ||
      (u.bio || '').toLowerCase().includes(q) ||
      (u.interests || []).some((intr) => intr.toLowerCase().includes(q))
    );
  });

  // Filter Posts
  const matchedPosts = posts.filter((p) => {
    if (!q) return true;
    const author = getUser(p.authorId);
    return (
      p.content.toLowerCase().includes(q) ||
      author.name.toLowerCase().includes(q) ||
      author.handle.toLowerCase().includes(q)
    );
  });

  // Filter Groups / Majlis Rooms
  const matchedGroups = rooms.filter((r) => {
    if (!q) return true;
    return (
      r.title.toLowerCase().includes(q) ||
      r.titleEn.toLowerCase().includes(q) ||
      r.topic.toLowerCase().includes(q) ||
      (r.country || '').toLowerCase().includes(q) ||
      (r.interests || []).some((intr) => intr.toLowerCase().includes(q))
    );
  });

  // Filter Pages
  const matchedPages = pages.filter((pg) => {
    if (!q) return true;
    return (
      pg.titleAr.toLowerCase().includes(q) ||
      pg.titleEn.toLowerCase().includes(q) ||
      pg.handle.toLowerCase().includes(q) ||
      pg.categoryAr.toLowerCase().includes(q) ||
      pg.descriptionAr.toLowerCase().includes(q) ||
      (pg.country || '').toLowerCase().includes(q)
    );
  });

  const handleInputChange = (val: string) => {
    setQuery(val);
    onQueryChange(val);
  };

  const handleCreatePageSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPageTitle.trim()) return;
    onCreatePage(
      newPageTitle.trim(),
      newPageCategory.trim() || (isAr ? 'صفحة عامة' : 'General Page'),
      newPageDesc.trim() ||
        (isAr
          ? 'صفحة مجتمعية على منصة ونس.'
          : 'Community page on WANAS platform.')
    );
    setNewPageTitle('');
    setNewPageCategory('');
    setNewPageDesc('');
    setShowCreatePageForm(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-start justify-center p-2 sm:p-6 overflow-y-auto">
      <div className="bg-white dark:bg-[#151D1C] border border-slate-200 dark:border-slate-800 rounded-3xl max-w-3xl w-full my-auto overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Top Search Input Header */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 space-y-3">
          <div className="flex items-center gap-2.5">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-[#0E6B63] dark:text-[#5FD0C4] absolute top-1/2 -translate-y-1/2 start-3.5" />
              <input
                type="text"
                autoFocus
                value={query}
                onChange={(e) => handleInputChange(e.target.value)}
                placeholder={
                  isAr
                    ? 'ابحث عن أي شيء: أشخاص، منشورات، جروبات، صفحات، بلد، أو اهتمام...'
                    : 'Search anything: people, posts, groups, pages, country, or interest...'
                }
                className="w-full ps-10 pe-9 py-2.5 rounded-2xl bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-[#1F1A12] dark:text-white focus:outline-none focus:border-[#0E6B63]"
              />
              {query && (
                <button
                  type="button"
                  onClick={() => handleInputChange('')}
                  className="absolute top-1/2 -translate-y-1/2 end-3 text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800 text-xs font-extrabold text-slate-700 dark:text-slate-200 hover:bg-slate-200 cursor-pointer shrink-0"
            >
              {isAr ? 'إغلاق' : 'Close'}
            </button>
          </div>

          {/* Category Filter Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
            {[
              {
                id: 'all' as SearchCategoryTab,
                label: isAr ? 'الكل' : 'All',
                count:
                  matchedPeople.length +
                  matchedPosts.length +
                  matchedGroups.length +
                  matchedPages.length,
              },
              {
                id: 'people' as SearchCategoryTab,
                label: isAr ? 'أشخاص وحسابات' : 'People',
                icon: Users,
                count: matchedPeople.length,
              },
              {
                id: 'posts' as SearchCategoryTab,
                label: isAr ? 'منشورات' : 'Posts',
                icon: FileText,
                count: matchedPosts.length,
              },
              {
                id: 'groups' as SearchCategoryTab,
                label: isAr ? 'جروبات ومجالس' : 'Groups',
                icon: Radio,
                count: matchedGroups.length,
              },
              {
                id: 'pages' as SearchCategoryTab,
                label: isAr ? 'صفحات' : 'Pages',
                icon: Flag,
                count: matchedPages.length,
              },
            ].map((tab) => {
              const Icon = tab.icon;
              const active = activeCat === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveCat(tab.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-extrabold flex items-center gap-1.5 shrink-0 transition-colors cursor-pointer ${
                    active
                      ? 'bg-[#0E6B63] text-white'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {Icon && <Icon className="w-3.5 h-3.5" />}
                  <span>{tab.label}</span>
                  <span
                    className={`px-1.5 py-0.2 rounded-md text-[10px] font-mono ${
                      active
                        ? 'bg-white/20 text-white'
                        : 'bg-white dark:bg-slate-900 text-slate-500'
                    }`}
                  >
                    {tab.count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Search Results Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-6">
          {/* 1. PEOPLE RESULTS */}
          {(activeCat === 'all' || activeCat === 'people') && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-extrabold text-[#0E6B63] dark:text-[#5FD0C4] uppercase tracking-wider flex items-center gap-1.5">
                  <Users className="w-4 h-4 text-[#F2A93B]" />
                  <span>
                    {isAr
                      ? `الأشخاص والحسابات (${matchedPeople.length})`
                      : `People & Accounts (${matchedPeople.length})`}
                  </span>
                </h4>
              </div>

              {matchedPeople.length === 0 ? (
                <p className="text-xs text-slate-400 py-2">
                  {isAr ? 'لا يوجد أشخاص مطابقون للبحث.' : 'No matching people.'}
                </p>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {matchedPeople.map((u) => {
                    const isFriend = (currentUser.friendIds || []).includes(
                      u.id
                    );
                    const isFollowing = (
                      currentUser.followingIds || []
                    ).includes(u.id);
                    return (
                      <div
                        key={u.id}
                        className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-[#FAF7F2]/60 dark:bg-slate-900/70 flex flex-col justify-between gap-3"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex items-center gap-2.5 min-w-0">
                            <UserAvatar
                              avatarKey={u.avatarKey}
                              customAvatarUrl={u.customAvatarUrl}
                              name={u.name}
                              size="md"
                            />
                            <div className="min-w-0">
                              <div className="font-extrabold text-xs sm:text-sm text-[#1F1A12] dark:text-white flex items-center gap-1 truncate">
                                <span>{u.name}</span>
                                {u.isVerified && (
                                  <CheckCircle2 className="w-3.5 h-3.5 text-[#0E6B63] dark:text-[#5FD0C4] shrink-0" />
                                )}
                              </div>
                              <div
                                dir="ltr"
                                className="text-[11px] text-slate-500 truncate"
                              >
                                {u.handle}
                              </div>
                              {u.country && (
                                <div className="text-[10px] font-bold text-[#0E6B63] dark:text-[#5FD0C4] flex items-center gap-1 mt-0.5">
                                  <MapPin className="w-3 h-3 text-[#F2A93B]" />
                                  <span>
                                    {u.country}
                                    {u.city ? ` · ${u.city}` : ''}
                                  </span>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => onToggleFriend(u.id)}
                            className={`flex-1 py-1.5 px-2.5 rounded-xl text-[11px] font-extrabold flex items-center justify-center gap-1 cursor-pointer ${
                              isFriend
                                ? 'bg-emerald-600 text-white'
                                : 'bg-[#0E6B63] text-white'
                            }`}
                          >
                            {isFriend ? (
                              <>
                                <UserCheck className="w-3.5 h-3.5" />
                                <span>{isAr ? 'صديق ✓' : 'Friends ✓'}</span>
                              </>
                            ) : (
                              <>
                                <UserPlus className="w-3.5 h-3.5" />
                                <span>
                                  {isAr ? 'إضافة صديق' : 'Add Friend'}
                                </span>
                              </>
                            )}
                          </button>

                          <button
                            type="button"
                            onClick={() => onToggleFollow(u.id)}
                            className="py-1.5 px-2.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-[11px] font-extrabold cursor-pointer"
                          >
                            {isFollowing
                              ? isAr
                                ? 'متابَع ✓'
                                : 'Following'
                              : isAr
                              ? 'متابعة'
                              : 'Follow'}
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              onClose();
                              onMessageUser(u);
                            }}
                            className="py-1.5 px-2.5 rounded-xl bg-[#F2A93B]/20 text-amber-950 dark:text-[#F2A93B] text-[11px] font-extrabold flex items-center gap-1 cursor-pointer"
                          >
                            <MessageSquare className="w-3.5 h-3.5" />
                            <span>{isAr ? 'رسالة' : 'Chat'}</span>
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* 2. GROUPS & MAJLIS RESULTS */}
          {(activeCat === 'all' || activeCat === 'groups') && (
            <div className="space-y-3">
              <h4 className="text-xs font-extrabold text-[#0E6B63] dark:text-[#5FD0C4] uppercase tracking-wider flex items-center gap-1.5">
                <Radio className="w-4 h-4 text-[#F2A93B]" />
                <span>
                  {isAr
                    ? `الجروبات والمجالس الصوتية (${matchedGroups.length})`
                    : `Groups & Audio Rooms (${matchedGroups.length})`}
                </span>
              </h4>

              {matchedGroups.length === 0 ? (
                <p className="text-xs text-slate-400 py-2">
                  {isAr ? 'لا توجد جروبات مطابقة.' : 'No matching groups.'}
                </p>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {matchedGroups.map((rm) => (
                    <div
                      key={rm.id}
                      className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-[#FAF7F2]/60 dark:bg-slate-900/70 flex flex-col justify-between gap-2.5"
                    >
                      <div>
                        <div className="font-extrabold text-xs sm:text-sm text-[#1F1A12] dark:text-white">
                          {isAr ? rm.title : rm.titleEn}
                        </div>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
                          {isAr ? rm.topic : rm.topicEn}
                        </p>
                      </div>
                      <div className="flex items-center justify-between pt-2 border-t border-slate-200/60 dark:border-slate-800">
                        <span className="text-[11px] font-bold text-slate-500">
                          {rm.participants.length}{' '}
                          {isAr ? 'عضو مشارك' : 'members'}
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            onJoinGroupRoom(rm.id);
                            onClose();
                          }}
                          className="px-3 py-1.5 rounded-xl bg-[#0E6B63] text-white text-xs font-extrabold cursor-pointer"
                        >
                          {isAr ? 'انضمام وفتح الجروب' : 'Join & Open'}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* 3. PAGES RESULTS */}
          {(activeCat === 'all' || activeCat === 'pages') && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-extrabold text-[#0E6B63] dark:text-[#5FD0C4] uppercase tracking-wider flex items-center gap-1.5">
                  <Flag className="w-4 h-4 text-[#F2A93B]" />
                  <span>
                    {isAr
                      ? `الصفحات الرسمية والمجتمعية (${matchedPages.length})`
                      : `Community & Official Pages (${matchedPages.length})`}
                  </span>
                </h4>
                <button
                  type="button"
                  onClick={() => setShowCreatePageForm((p) => !p)}
                  className="px-2.5 py-1 rounded-xl bg-[#0E6B63]/10 text-[#0E6B63] dark:text-[#5FD0C4] text-[11px] font-extrabold flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{isAr ? 'إنشاء صفحة جديدة' : 'Create Page'}</span>
                </button>
              </div>

              {showCreatePageForm && (
                <form
                  onSubmit={handleCreatePageSubmit}
                  className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-[#0E6B63]/40 space-y-2.5"
                >
                  <div className="text-xs font-extrabold text-[#0E6B63] dark:text-[#5FD0C4]">
                    {isAr ? 'إنشاء صفحة عامة على ونس' : 'Create Public Page'}
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <input
                      type="text"
                      required
                      value={newPageTitle}
                      onChange={(e) => setNewPageTitle(e.target.value)}
                      placeholder={isAr ? 'اسم الصفحة...' : 'Page title...'}
                      className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                    />
                    <input
                      type="text"
                      value={newPageCategory}
                      onChange={(e) => setNewPageCategory(e.target.value)}
                      placeholder={
                        isAr
                          ? 'التصنيف (مثال: تقنية، رياضة، فنون)...'
                          : 'Category...'
                      }
                      className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                    />
                  </div>
                  <input
                    type="text"
                    value={newPageDesc}
                    onChange={(e) => setNewPageDesc(e.target.value)}
                    placeholder={isAr ? 'وصف الصفحة...' : 'Page description...'}
                    className="w-full px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                  />
                  <div className="flex justify-end gap-2">
                    <button
                      type="submit"
                      className="px-4 py-1.5 rounded-xl bg-[#0E6B63] text-white text-xs font-extrabold cursor-pointer"
                    >
                      {isAr ? 'نشر الصفحة' : 'Create Page'}
                    </button>
                  </div>
                </form>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {matchedPages.map((pg) => {
                  const isFollowed = pg.followersIds.includes(currentUser.id);
                  return (
                    <div
                      key={pg.id}
                      className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-[#FAF7F2]/60 dark:bg-slate-900/70 flex flex-col justify-between gap-2.5"
                    >
                      <div>
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-extrabold text-xs sm:text-sm text-[#1F1A12] dark:text-white flex items-center gap-1">
                            <span>{isAr ? pg.titleAr : pg.titleEn}</span>
                            {pg.isVerified && (
                              <CheckCircle2 className="w-3.5 h-3.5 text-[#0E6B63] dark:text-[#5FD0C4] shrink-0" />
                            )}
                          </span>
                          <span className="px-2 py-0.5 rounded-md bg-[#F2A93B]/20 text-amber-900 dark:text-[#F2A93B] text-[10px] font-bold">
                            {isAr ? pg.categoryAr : pg.categoryEn}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
                          {isAr ? pg.descriptionAr : pg.descriptionEn}
                        </p>
                      </div>
                      <div className="flex items-center justify-between pt-2 border-t border-slate-200/60 dark:border-slate-800">
                        <span className="text-[11px] font-bold text-slate-500">
                          {pg.followersCount + (isFollowed ? 1 : 0)}{' '}
                          {isAr ? 'متابع للصفحة' : 'followers'}
                        </span>
                        <button
                          type="button"
                          onClick={() => onToggleFollowPage(pg.id)}
                          className={`px-3.5 py-1.5 rounded-xl text-xs font-extrabold cursor-pointer ${
                            isFollowed
                              ? 'bg-emerald-600 text-white'
                              : 'bg-[#0E6B63] text-white'
                          }`}
                        >
                          {isFollowed
                            ? isAr
                              ? 'متابَع ✓'
                              : 'Following ✓'
                            : isAr
                            ? '+ متابعة الصفحة'
                            : '+ Follow Page'}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* 4. POSTS RESULTS */}
          {(activeCat === 'all' || activeCat === 'posts') && (
            <div className="space-y-3">
              <h4 className="text-xs font-extrabold text-[#0E6B63] dark:text-[#5FD0C4] uppercase tracking-wider flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-[#F2A93B]" />
                <span>
                  {isAr
                    ? `المنشورات والمقاطع (${matchedPosts.length})`
                    : `Posts & Clips (${matchedPosts.length})`}
                </span>
              </h4>

              {matchedPosts.length === 0 ? (
                <p className="text-xs text-slate-400 py-2">
                  {isAr
                    ? 'لا توجد منشورات مطابقة حالياً.'
                    : 'No matching posts found.'}
                </p>
              ) : (
                <div className="space-y-2.5">
                  {matchedPosts.map((post) => {
                    const author = getUser(post.authorId);
                    return (
                      <div
                        key={post.id}
                        onClick={() => {
                          onSelectPost(post);
                          onClose();
                        }}
                        className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-[#FAF7F2]/60 dark:bg-slate-900/70 hover:border-[#0E6B63] transition-colors cursor-pointer space-y-1.5"
                      >
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-bold text-[#1F1A12] dark:text-white">
                            {author.name}{' '}
                            <span className="text-slate-400 font-normal">
                              ({author.handle})
                            </span>
                          </span>
                          <span className="text-[11px] text-[#0E6B63] dark:text-[#5FD0C4] font-bold">
                            {isAr ? 'فتح المنشور ←' : 'View Post →'}
                          </span>
                        </div>
                        <p className="text-xs text-slate-700 dark:text-slate-200 line-clamp-2">
                          {post.content}
                        </p>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
