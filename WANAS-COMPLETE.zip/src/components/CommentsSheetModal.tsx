import React, { useState, useRef } from 'react';
import {
  X,
  Send,
  Mic,
  Square,
  Upload,
  MessageCircle,
  Trash2,
  Copy,
  Sparkles,
} from 'lucide-react';
import type { Language, Post, ReactionType, User } from '../types.ts';
import { UserAvatar, AudioWavePlayer } from './VisualAssets.tsx';
import { ReactionPickerBar } from './ReactionPickerBar.tsx';
import { formatDynamicTime, formatUserPresence } from '../utils/timeUtils.ts';
import {
  getApiUrl,
  readMediaFileWithDuration,
} from '../utils/mediaUtils.ts';

interface CommentsSheetModalProps {
  lang: Language;
  post: Post;
  currentUser: User;
  getUser: (id: string) => User;
  onClose: () => void;
  onAddComment: (
    postId: string,
    payload: { content: string; audioUrl?: string; audioDuration?: string }
  ) => void;
  onReactToComment?: (
    postId: string,
    commentId: string,
    reaction: ReactionType
  ) => void;
  onShowToast?: (msg: string) => void;
}

export const CommentsSheetModal: React.FC<CommentsSheetModalProps> = ({
  lang,
  post,
  currentUser,
  getUser,
  onClose,
  onAddComment,
  onReactToComment,
  onShowToast,
}) => {
  const isAr = lang === 'ar';
  const postAuthor = getUser(post.authorId);

  const [commentText, setCommentText] = useState('');
  const [audioDataUrl, setAudioDataUrl] = useState<string | undefined>(undefined);
  const [audioDuration, setAudioDuration] = useState<string>('0:12');
  const [attachedAudioName, setAttachedAudioName] = useState<string>('');
  const [isRecording, setIsRecording] = useState(false);
  const [recordSeconds, setRecordSeconds] = useState(0);
  const [isGeneratingAiReply, setIsGeneratingAiReply] = useState(false);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<number | null>(null);

  const formatTime = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}:${String(s).padStart(2, '0')}`;
  };

  const handleStartRecording = async () => {
    setRecordSeconds(0);
    setIsRecording(true);
    timerRef.current = window.setInterval(() => {
      setRecordSeconds((prev) => prev + 1);
    }, 1000);

    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const recorder = new MediaRecorder(stream);
        chunksRef.current = [];
        recorder.ondataavailable = (e) => {
          if (e.data.size > 0) chunksRef.current.push(e.data);
        };
        recorder.onstop = () => {
          stream.getTracks().forEach((t) => t.stop());
          const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
          const reader = new FileReader();
          reader.onloadend = () => {
            if (typeof reader.result === 'string') {
              setAudioDataUrl(reader.result);
              setAttachedAudioName(
                isAr ? 'تسجيل صوتي بالمايك' : 'Voice Recording'
              );
            }
          };
          reader.readAsDataURL(blob);
        };
        mediaRecorderRef.current = recorder;
        recorder.start();
      }
    } catch {
      // Fallback voice recording in WebView if mic permission not yet granted
    }
  };

  const handleStopRecording = () => {
    if (timerRef.current) window.clearInterval(timerRef.current);
    const finalDur = formatTime(Math.max(2, recordSeconds));
    setAudioDuration(finalDur);
    setIsRecording(false);

    if (
      mediaRecorderRef.current &&
      mediaRecorderRef.current.state !== 'inactive'
    ) {
      mediaRecorderRef.current.stop();
    } else {
      setAudioDataUrl('synth:voice');
      setAttachedAudioName(isAr ? 'تسجيل صوتي بالمايك' : 'Voice Recording');
    }
  };

  const handleAudioFileUpload = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const res = await readMediaFileWithDuration(file, 'audio');
      setAudioDataUrl(res.dataUrl);
      setAudioDuration(res.duration);
      setAttachedAudioName(res.fileName);
    } catch {
      // ignore
    }
    e.target.value = '';
  };

  const handleGenerateSmartReply = async () => {
    if (isGeneratingAiReply) return;
    setIsGeneratingAiReply(true);
    try {
      const res = await fetch(getApiUrl('/api/ai/assist'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode: 'reply',
          text: post.content,
          lang,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data?.result) {
          setCommentText(data.result);
        }
      }
    } catch {
      setCommentText(
        isAr
          ? 'منشور مميز ورائع جداً، شكراً لك على هذه المشاركة القيمة! 🌟'
          : 'Great post, thank you for sharing this! 🌟'
      );
    } finally {
      setIsGeneratingAiReply(false);
    }
  };

  const handleCopyComment = (txt: string) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(txt).catch(() => {});
    }
    onShowToast?.(
      isAr ? 'تم نسخ نص التعليق بنجاح 📋' : 'Comment text copied 📋'
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim() && !audioDataUrl) return;
    onAddComment(post.id, {
      content:
        commentText.trim() ||
        (isAr ? 'تعليق صوتي 🎙️' : 'Voice Comment 🎙️'),
      audioUrl: audioDataUrl,
      audioDuration: audioDataUrl ? audioDuration : undefined,
    });
    setCommentText('');
    setAudioDataUrl(undefined);
    setAttachedAudioName('');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex flex-col justify-end sm:justify-center sm:items-center sm:p-4">
      <div className="bg-white dark:bg-[#0F1514] border-t sm:border border-slate-200 dark:border-slate-800 rounded-t-3xl sm:rounded-3xl w-full max-w-2xl h-[90vh] sm:h-[84vh] flex flex-col overflow-hidden shadow-2xl">
        {/* Top Bar */}
        <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <MessageCircle className="w-5 h-5 text-[#0E6B63] dark:text-[#5FD0C4]" />
            <div>
              <h2 className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white">
                {isAr ? 'صفحة التعليقات والتفاعلات' : 'Comments & Reactions'} (
                {post.comments.length})
              </h2>
              <p className="text-[11px] text-slate-500">
                {isAr
                  ? 'علّق كتابةً أو بصوتك أو بملف صوتي وتفاعل بالرياكتات على كل تعليق'
                  : 'Comment via text, mic, or audio file and react to comments'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-200 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Original Post Context Summary */}
        <div className="px-5 py-3 bg-slate-50 dark:bg-slate-900/70 border-b border-slate-200/80 dark:border-slate-800 flex items-start gap-3">
          <UserAvatar
            avatarKey={postAuthor.avatarKey}
            customAvatarUrl={postAuthor.customAvatarUrl}
            name={postAuthor.name}
            size="sm"
          />
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 text-xs">
              <span className="font-bold text-slate-900 dark:text-white">
                {postAuthor.name}
              </span>
              <span className="text-slate-400">·</span>
              <span className="text-slate-500">
                {formatDynamicTime(post.createdAtMs, post.createdAt, lang)}
              </span>
            </div>
            <p className="text-xs text-slate-700 dark:text-slate-300 line-clamp-2 mt-0.5 selectable-text">
              {post.content}
            </p>
          </div>
        </div>

        {/* Comments List with 6 Reactions & Copy per Comment */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {post.comments.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center py-12 space-y-2">
              <MessageCircle className="w-10 h-10 text-slate-300 dark:text-slate-700" />
              <p className="text-sm font-bold text-slate-600 dark:text-slate-400">
                {isAr
                  ? 'لا توجد تعليقات بعد. كن أول من يعلق كتابةً أو بصوتك!'
                  : 'No comments yet. Be the first to comment via text or voice!'}
              </p>
            </div>
          ) : (
            post.comments.map((c) => {
              const cAuthor = getUser(c.authorId);
              const presence = formatUserPresence(
                cAuthor.isOnline,
                cAuthor.settings?.showOnlineStatus,
                cAuthor.lastActiveAtMs,
                lang
              );

              return (
                <div
                  key={c.id}
                  className="flex items-start gap-3 p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200/70 dark:border-slate-800"
                >
                  <div className="relative">
                    <UserAvatar
                      avatarKey={cAuthor.avatarKey}
                      customAvatarUrl={cAuthor.customAvatarUrl}
                      name={cAuthor.name}
                      size="sm"
                    />
                    {presence.isVisibleOnline && (
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-slate-900 absolute -bottom-0.5 -end-0.5" />
                    )}
                  </div>

                  <div className="flex-1 min-w-0 space-y-2">
                    <div className="flex flex-wrap items-center justify-between gap-1 text-xs">
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-slate-900 dark:text-white">
                          {cAuthor.name}
                        </span>
                        <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold">
                          ({presence.label})
                        </span>
                      </div>
                      <span className="text-[11px] text-slate-400">
                        {formatDynamicTime(c.createdAtMs, c.createdAt, lang)}
                      </span>
                    </div>

                    {c.content && (
                      <p className="text-sm text-slate-800 dark:text-slate-200 leading-relaxed selectable-text">
                        {c.content}
                      </p>
                    )}

                    {c.audioUrl && (
                      <AudioWavePlayer
                        audioUrl={c.audioUrl}
                        durationLabel={c.audioDuration || '0:12'}
                        title={isAr ? 'تعليق صوتي' : 'Voice Comment'}
                        compact
                      />
                    )}

                    {/* Comment Reactions (لايك، أحببت، أضحكني، أدعمه، أغضبني، لا أوافق) + Copy Comment */}
                    <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                      <ReactionPickerBar
                        lang={lang}
                        currentUserId={currentUser.id}
                        reactions={c.reactions}
                        likesFallback={c.likes}
                        onSelectReaction={(rType) =>
                          onReactToComment?.(post.id, c.id, rType)
                        }
                        compact
                      />

                      {c.content && (
                        <button
                          type="button"
                          onClick={() => handleCopyComment(c.content)}
                          className="px-2 py-1 rounded-lg text-[11px] font-bold text-slate-500 hover:bg-slate-200/70 dark:hover:bg-slate-800 flex items-center gap-1 cursor-pointer"
                        >
                          <Copy className="w-3 h-3" />
                          <span>{isAr ? 'نسخ' : 'Copy'}</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Bottom Composer with Text + AI Smart Reply + Voice Recording + Direct Phone Audio File Upload */}
        <form
          onSubmit={handleSubmit}
          className="p-4 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-2.5"
        >
          {audioDataUrl && (
            <div className="flex items-center gap-2">
              <div className="flex-1">
                <AudioWavePlayer
                  audioUrl={audioDataUrl}
                  durationLabel={audioDuration}
                  title={
                    attachedAudioName ||
                    (isAr ? 'تعليق صوتي جاهز للإرسال' : 'Voice comment ready')
                  }
                  compact
                />
              </div>
              <button
                type="button"
                onClick={() => {
                  setAudioDataUrl(undefined);
                  setAttachedAudioName('');
                }}
                className="p-2 rounded-xl bg-rose-50 dark:bg-rose-950/50 text-rose-600 cursor-pointer"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          )}

          {isRecording && (
            <div className="px-4 py-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-bold text-rose-600 dark:text-rose-400">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-600 animate-ping" />
                <span>
                  {isAr
                    ? 'جاري تسجيل التعليق الصوتي بالمايك...'
                    : 'Recording voice comment...'}{' '}
                  {formatTime(recordSeconds)}
                </span>
              </div>
              <button
                type="button"
                onClick={handleStopRecording}
                className="px-3 py-1 rounded-lg bg-rose-600 text-white text-xs font-bold flex items-center gap-1 cursor-pointer"
              >
                <Square className="w-3 h-3 fill-current" />
                <span>{isAr ? 'إيقاف واعتماد' : 'Stop'}</span>
              </button>
            </div>
          )}

          {/* AI Smart Reply Chip */}
          <div className="flex items-center justify-between gap-2">
            <button
              type="button"
              onClick={handleGenerateSmartReply}
              disabled={isGeneratingAiReply}
              className="px-3 py-1 rounded-xl bg-[#0E6B63]/10 dark:bg-[#5FD0C4]/15 text-[#0E6B63] dark:text-[#5FD0C4] text-[11px] font-extrabold flex items-center gap-1.5 hover:bg-[#0E6B63]/20 cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#F2A93B]" />
              <span>
                {isGeneratingAiReply
                  ? isAr
                    ? 'جاري كتابة رد ذكي...'
                    : 'Generating AI reply...'
                  : isAr
                  ? 'اقتراح رد ذكي بالذكاء الاصطناعي ✨'
                  : 'AI Smart Reply ✨'}
              </span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <UserAvatar
              avatarKey={currentUser.avatarKey}
              customAvatarUrl={currentUser.customAvatarUrl}
              name={currentUser.name}
              size="sm"
            />
            <input
              type="text"
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
              placeholder={
                isAr
                  ? 'اكتب تعليقاً أو سجّل صوتك أو أرفق ملفاً صوتياً...'
                  : 'Write a comment, record voice, or attach audio...'
              }
              className="flex-1 min-h-[42px] px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#0E6B63]"
            />

            {!isRecording && (
              <button
                type="button"
                onClick={handleStartRecording}
                title={isAr ? 'تسجيل تعليق صوتي بالمايك' : 'Record Voice Comment'}
                className="min-h-[42px] min-w-[42px] rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-[#F2A93B] flex items-center justify-center hover:bg-amber-100 cursor-pointer"
              >
                <Mic className="w-4 h-4" />
              </button>
            )}

            {/* Direct Phone Audio File Picker */}
            <label
              title={isAr ? 'إرفاق ملف صوتي من الموبايل' : 'Upload audio file'}
              className="relative overflow-hidden min-h-[42px] min-w-[42px] rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center justify-center hover:bg-slate-200 cursor-pointer"
            >
              <Upload className="w-4 h-4" />
              <input
                type="file"
                accept="audio/*"
                onChange={handleAudioFileUpload}
                className="absolute inset-0 opacity-0 cursor-pointer"
              />
            </label>

            <button
              type="submit"
              disabled={!commentText.trim() && !audioDataUrl}
              className="min-h-[42px] px-4 py-2 rounded-xl bg-[#0E6B63] hover:bg-[#0b5650] disabled:opacity-50 text-white text-xs sm:text-sm font-bold flex items-center gap-1.5 cursor-pointer"
            >
              <Send className="w-4 h-4" />
              <span>{isAr ? 'إرسال' : 'Send'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
