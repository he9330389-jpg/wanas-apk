import React from 'react';
import {
  X,
  Settings,
  Bookmark,
  Moon,
  Sun,
  Languages,
  ShieldBan,
  FileText,
  LogOut,
  PenSquare,
  Camera,
  Radio,
  Film,
} from 'lucide-react';
import type { Language, User } from '../types.ts';
import { UserAvatar } from './VisualAssets.tsx';
import { getApiUrl } from '../utils/mediaUtils.ts';

/** Side menu opened from the ☰ button in the header. */
interface AppDrawerProps {
  lang: Language;
  darkMode: boolean;
  currentUser: User;
  onClose: () => void;
  onOpenProfile: () => void;
  onOpenSettings: () => void;
  onOpenSaved: () => void;
  onToggleDark: () => void;
  onToggleLang: () => void;
  onLogout: () => void;
}

export const AppDrawer: React.FC<AppDrawerProps> = ({
  lang,
  darkMode,
  currentUser,
  onClose,
  onOpenProfile,
  onOpenSettings,
  onOpenSaved,
  onToggleDark,
  onToggleLang,
  onLogout,
}) => {
  const isAr = lang === 'ar';

  const Item: React.FC<{
    icon: React.ReactNode;
    label: string;
    onClick: () => void;
    danger?: boolean;
    hint?: string;
  }> = ({ icon, label, onClick, danger, hint }) => (
    <button
      type="button"
      onClick={onClick}
      className={`w-full min-h-[48px] px-3 rounded-2xl flex items-center gap-3 text-sm font-bold text-start cursor-pointer transition-colors ${
        danger
          ? 'text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30'
          : 'text-[#1F1A12] dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800'
      }`}
    >
      <span className="w-5 h-5 flex items-center justify-center shrink-0">{icon}</span>
      <span className="flex-1">{label}</span>
      {hint && <span className="text-[11px] font-semibold text-slate-400">{hint}</span>}
    </button>
  );

  return (
    <div className="fixed inset-0 z-50 flex" role="dialog" aria-modal="true">
      <button
        type="button"
        aria-label="close"
        onClick={onClose}
        className="absolute inset-0 bg-black/55 backdrop-blur-[2px] cursor-default"
      />
      <aside className="relative w-[84%] max-w-xs h-full bg-white dark:bg-[#151D1C] shadow-2xl flex flex-col animate-[slideIn_.18s_ease-out] overflow-y-auto">
        <div className="p-4 flex items-start justify-between gap-2 border-b border-slate-200 dark:border-slate-800">
          <button
            type="button"
            onClick={onOpenProfile}
            className="flex items-center gap-3 min-w-0 text-start cursor-pointer"
          >
            <UserAvatar
              avatarKey={currentUser.avatarKey}
              customAvatarUrl={currentUser.customAvatarUrl}
              name={currentUser.name}
              size="lg"
            />
            <div className="min-w-0">
              <div className="font-extrabold text-sm truncate">{currentUser.name}</div>
              <div dir="ltr" className="text-xs text-slate-500 dark:text-slate-400 truncate text-start">
                {currentUser.handle}
              </div>
              <div className="text-[11px] font-bold text-[#0E6B63] dark:text-[#5FD0C4] mt-0.5">
                {isAr ? 'عرض الملف الشخصي' : 'View profile'}
              </div>
            </div>
          </button>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <nav className="p-3 space-y-1 flex-1">
          <Item
            icon={<Settings className="w-5 h-5 text-[#0E6B63] dark:text-[#5FD0C4]" />}
            label={isAr ? 'الإعدادات' : 'Settings'}
            onClick={onOpenSettings}
          />
          <Item
            icon={<Bookmark className="w-5 h-5 text-[#F2A93B]" />}
            label={isAr ? 'المحفوظات' : 'Saved'}
            onClick={onOpenSaved}
          />
          <Item
            icon={
              darkMode ? (
                <Sun className="w-5 h-5 text-[#F2A93B]" />
              ) : (
                <Moon className="w-5 h-5 text-slate-600" />
              )
            }
            label={darkMode ? (isAr ? 'الوضع النهاري' : 'Light mode') : isAr ? 'الوضع الليلي' : 'Dark mode'}
            onClick={onToggleDark}
          />
          <Item
            icon={<Languages className="w-5 h-5 text-[#0E6B63] dark:text-[#5FD0C4]" />}
            label={isAr ? 'اللغة' : 'Language'}
            hint={isAr ? 'English' : 'العربية'}
            onClick={onToggleLang}
          />
          <Item
            icon={<ShieldBan className="w-5 h-5 text-slate-600 dark:text-slate-300" />}
            label={isAr ? 'الحظر والخصوصية' : 'Blocked & privacy'}
            onClick={onOpenSettings}
          />
          <Item
            icon={<FileText className="w-5 h-5 text-slate-600 dark:text-slate-300" />}
            label={isAr ? 'سياسة الخصوصية' : 'Privacy policy'}
            onClick={() => window.open(getApiUrl('/privacy'), '_blank')}
          />
        </nav>

        <div className="p-3 border-t border-slate-200 dark:border-slate-800">
          <Item
            icon={<LogOut className="w-5 h-5" />}
            label={isAr ? 'تسجيل الخروج' : 'Log out'}
            danger
            onClick={onLogout}
          />
          <p dir="ltr" className="text-[10px] text-center text-slate-400 mt-2">
            WANAS v3.3.0 · By ABD.ALLAH ZOHAIR OMARA
          </p>
        </div>
      </aside>
    </div>
  );
};

/** "+" button sheet: pick what to create. */
interface CreateSheetProps {
  lang: Language;
  onClose: () => void;
  onPost: () => void;
  onStory: () => void;
  onVideo: () => void;
  onRoom: () => void;
}

export const CreateSheet: React.FC<CreateSheetProps> = ({
  lang,
  onClose,
  onPost,
  onStory,
  onVideo,
  onRoom,
}) => {
  const isAr = lang === 'ar';
  const options = [
    { icon: PenSquare, label: isAr ? 'منشور' : 'Post', sub: isAr ? 'نص وصور وصوت' : 'Text, photos, audio', onClick: onPost },
    { icon: Camera, label: isAr ? 'ستوري' : 'Story', sub: isAr ? 'يختفي بخصوصية تحددها' : 'With your privacy choice', onClick: onStory },
    { icon: Film, label: isAr ? 'فيديو' : 'Video', sub: isAr ? 'انشر مقطعك' : 'Share a clip', onClick: onVideo },
    { icon: Radio, label: isAr ? 'مجلس صوتي' : 'Voice room', sub: isAr ? 'ابدأ حوار مباشر' : 'Start a live talk', onClick: onRoom },
  ];
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center" role="dialog" aria-modal="true">
      <button type="button" aria-label="close" onClick={onClose} className="absolute inset-0 bg-black/55 cursor-default" />
      <div className="relative w-full max-w-md bg-white dark:bg-[#151D1C] rounded-t-3xl p-4 pb-6 shadow-2xl">
        <div className="w-10 h-1 rounded-full bg-slate-300 dark:bg-slate-700 mx-auto mb-4" />
        <h3 className="text-sm font-extrabold mb-3 text-center">{isAr ? 'إنشاء جديد' : 'Create'}</h3>
        <div className="grid grid-cols-2 gap-3">
          {options.map(({ icon: Icon, label, sub, onClick }) => (
            <button
              key={label}
              type="button"
              onClick={onClick}
              className="p-4 rounded-2xl bg-[#FAF7F2] dark:bg-slate-900/70 border border-slate-200/80 dark:border-slate-800 flex flex-col items-start gap-2 text-start cursor-pointer hover:border-[#0E6B63] transition-colors"
            >
              <span className="w-10 h-10 rounded-xl bg-[#0E6B63]/10 flex items-center justify-center">
                <Icon className="w-5 h-5 text-[#0E6B63] dark:text-[#5FD0C4]" />
              </span>
              <span className="font-extrabold text-sm">{label}</span>
              <span className="text-[11px] text-slate-500 dark:text-slate-400">{sub}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
