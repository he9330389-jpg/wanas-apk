import React, { useState } from 'react';
import {
  Video,
  Upload,
  MessageCircle,
  Share2,
  Bookmark,
  MoreVertical,
  Link2,
  Flag,
  Pin,
  Trash2,
  Play,
  Repeat2,
  Download,
  Copy,
  Camera,
  Globe,
  Users,
  Lock,
  Shield,
} from 'lucide-react';
import type {
  Language,
  Post,
  PostAudience,
  ReactionType,
  User,
} from '../types.ts';
import { UserAvatar, PostMediaVisual } from './VisualAssets.tsx';
import { ReactionPickerBar } from './ReactionPickerBar.tsx';
import { formatDynamicTime, formatUserPresence } from '../utils/timeUtils.ts';
import {
  downloadMediaToDevice,
  readMediaFileWithDuration,
} from '../utils/mediaUtils.ts';

interface VideosViewProps {
  lang: Language;
  posts: Post[];
  currentUser: User;
  getUser: (id: string) => User;
  onPublishVideoPost: (payload: {
    content: string;
    videoUrl: string;
    videoDuration?: string;
    audience?: PostAudience;
  }) => void;
  onReactToPost: (postId: string, reaction: ReactionType) => void;
  onToggleBookmark: (postId: string) => void;
  onOpenCommentsPage: (post: Post) => void;
  onTogglePinPost: (postId: string) => void;
  onReportPost: (postId: string) => void;
  onDeletePost: (postId: string) => void;
  onCopyPostLink: (postId: string) => void;
  onCopyPostText?: (text: string) => void;
  onSharePost: (post: Post) => void;
  onRepost: (post: Post) => void;
}

export const VideosView: React.FC<VideosViewProps> = ({
  lang,
  posts,
  currentUser,
  getUser,
  onPublishVideoPost,
  onReactToPost,
  onToggleBookmark,
  onOpenCommentsPage,
  onTogglePinPost,
  onReportPost,
  onDeletePost,
  onCopyPostLink,
  onCopyPostText,
  onSharePost,
  onRepost,
}) => {
  const isAr = lang === 'ar';
  const [videoCaption, setVideoCaption] = useState('');
  const [videoDataUrl, setVideoDataUrl] = useState<string | undefined>(
    undefined
  );
  const [videoDuration, setVideoDuration] = useState<string>('0:30');
  const [selectedFileName, setSelectedFileName] = useState<string>('');
  const [audience, setAudience] = useState<PostAudience>('public');
  const [isLoadingFile, setIsLoadingFile] = useState<boolean>(false);
  const [openMenuId, setOpenMenuId] = useState<string | null>(null);

  const videoPosts = posts.filter(
    (p) => p.category === 'video' || Boolean(p.videoUrl)
  );

  // Immediately opens phone video picker and loads the video for preview & publishing
  const handleVideoFileChange = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsLoadingFile(true);
    try {
      const res = await readMediaFileWithDuration(file, 'video');
      setVideoDataUrl(res.dataUrl);
      setVideoDuration(res.duration);
      setSelectedFileName(res.fileName);
    } catch {
      // ignore
    } finally {
      setIsLoadingFile(false);
    }
    e.target.value = '';
  };

  const handleSubmitVideo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!videoDataUrl && !videoCaption.trim()) return;
    onPublishVideoPost({
      content:
        videoCaption.trim() ||
        (selectedFileName
          ? `${isAr ? 'مقطع فيديو:' : 'Video:'} ${selectedFileName.replace(/\.[^/.]+$/, '')} 🎬`
          : isAr
          ? 'مقطع فيديو جديد على ونس 🎬'
          : 'New video clip on WANAS 🎬'),
      videoUrl: videoDataUrl || 'builtin:video',
      videoDuration,
      audience,
    });
    setVideoCaption('');
    setVideoDataUrl(undefined);
    setSelectedFileName('');
  };

  const getAudienceBadge = (aud?: PostAudience) => {
    switch (aud) {
      case 'friends':
        return {
          icon: Users,
          label: isAr ? 'للأصدقاء فقط' : 'Friends',
        };
      case 'non_friends':
        return {
          icon: Shield,
          label: isAr ? 'لغير الأصدقاء' : 'Non-Friends',
        };
      case 'only_me':
        return {
          icon: Lock,
          label: isAr ? 'أنا فقط' : 'Only Me',
        };
      default:
        return {
          icon: Globe,
          label: isAr ? 'للعامة' : 'Public',
        };
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-5">
      {/* Header & Direct Phone Video Picker Buttons */}
      <div className="bg-white dark:bg-[#151D1C] border border-slate-200 dark:border-slate-800 rounded-3xl p-5 space-y-4 shadow-xs">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-[#0E6B63]/10 dark:bg-[#0E6B63]/25 flex items-center justify-center text-[#0E6B63] dark:text-[#5FD0C4]">
              <Video className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white">
                {isAr ? 'منصة مقاطع الفيديو (4K & HD)' : 'Videos & Clips (4K & HD)'}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {isAr
                  ? 'اختر فيديو من ملفات هاتفك أو صوّر بالكاميرا وانشره مباشرة ليراه الجميع'
                  : 'Choose a video from your phone or record with camera and publish directly'}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Direct Native File Input Label — Tapping opens mobile video gallery immediately! */}
            <label className="relative overflow-hidden min-h-[44px] px-4 py-2.5 rounded-2xl bg-[#0E6B63] hover:bg-[#0b5650] text-white text-xs sm:text-sm font-extrabold flex items-center gap-2 cursor-pointer shadow-sm">
              <Upload className="w-4 h-4 text-[#F2A93B]" />
              <span>
                {isAr
                  ? 'إضافة فيديو من الموبايل'
                  : 'Choose Video from Phone'}
              </span>
              <input
                type="file"
                accept="video/*"
                onChange={handleVideoFileChange}
                className="absolute inset-0 opacity-0 cursor-pointer"
              />
            </label>

            {/* Direct Camera Video Capture */}
            <label className="relative overflow-hidden min-h-[44px] px-3.5 py-2.5 rounded-2xl bg-[#F2A93B]/15 hover:bg-[#F2A93B]/25 border border-[#F2A93B]/50 text-amber-950 dark:text-[#F2A93B] text-xs sm:text-sm font-extrabold flex items-center gap-1.5 cursor-pointer">
              <Camera className="w-4 h-4" />
              <span>{isAr ? 'تصوير فيديو' : 'Record Video'}</span>
              <input
                type="file"
                accept="video/*"
                capture="environment"
                onChange={handleVideoFileChange}
                className="absolute inset-0 opacity-0 cursor-pointer"
              />
            </label>
          </div>
        </div>

        {/* Always-Ready Video Composer Box */}
        <form
          onSubmit={handleSubmitVideo}
          className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/70 border border-slate-200/80 dark:border-slate-800 space-y-3"
        >
          {isLoadingFile && (
            <div className="p-3 rounded-xl bg-[#0E6B63]/10 text-[#0E6B63] dark:text-[#5FD0C4] text-xs font-bold">
              {isAr
                ? 'جاري تجهيز ومعالجة الفيديو من هاتفك بأعلى جودة...'
                : 'Loading video from your phone...'}
            </div>
          )}

          {videoDataUrl && videoDataUrl !== 'builtin:video' && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-emerald-600 dark:text-emerald-400">
                <span>
                  {isAr
                    ? `✓ تم إرفاق الفيديو من هاتفك (${selectedFileName || 'MP4'}) · المدة: ${videoDuration}`
                    : `✓ Video attached (${selectedFileName || 'MP4'}) · ${videoDuration}`}
                </span>
                <button
                  type="button"
                  onClick={() => {
                    setVideoDataUrl(undefined);
                    setSelectedFileName('');
                  }}
                  className="text-rose-500 hover:underline cursor-pointer"
                >
                  {isAr ? 'إزالة الفيديو' : 'Remove'}
                </button>
              </div>
              <video
                src={videoDataUrl}
                controls
                playsInline
                className="w-full max-h-80 rounded-2xl bg-black object-contain border border-slate-800"
              />
            </div>
          )}

          <div className="flex flex-col sm:flex-row gap-2.5">
            <input
              type="text"
              value={videoCaption}
              onChange={(e) => setVideoCaption(e.target.value)}
              placeholder={
                isAr
                  ? 'اكتب عنوان أو وصف الفيديو هنا قبل النشر...'
                  : 'Write video title or description...'
              }
              className="flex-1 px-4 py-2.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:border-[#0E6B63]"
            />

            <select
              value={audience}
              onChange={(e) => setAudience(e.target.value as PostAudience)}
              className="px-3 py-2.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200"
            >
              <option value="public">
                {isAr ? '🌐 للعامة (الجميع)' : '🌐 Public'}
              </option>
              <option value="friends">
                {isAr ? '👥 للأصدقاء فقط' : '👥 Friends Only'}
              </option>
              <option value="non_friends">
                {isAr ? '🌍 لغير الأصدقاء فقط' : '🌍 Non-Friends Only'}
              </option>
              <option value="only_me">
                {isAr ? '🔒 أنا فقط' : '🔒 Only Me'}
              </option>
            </select>

            <button
              type="submit"
              disabled={!videoDataUrl && !videoCaption.trim()}
              className="min-h-[42px] px-5 py-2.5 rounded-xl bg-[#0E6B63] hover:bg-[#0b5650] disabled:opacity-50 text-white text-xs sm:text-sm font-extrabold cursor-pointer shrink-0 shadow-xs"
            >
              {isAr ? 'نشر الفيديو الآن' : 'Publish Video'}
            </button>
          </div>
        </form>
      </div>

      {/* Video Feed */}
      {videoPosts.length === 0 ? (
        <div className="bg-white dark:bg-[#151D1C] border border-slate-200 dark:border-slate-800 rounded-3xl p-10 text-center space-y-3">
          <div className="w-14 h-14 rounded-2xl bg-[#0E6B63]/10 text-[#0E6B63] dark:text-[#5FD0C4] flex items-center justify-center mx-auto">
            <Play className="w-7 h-7" />
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            {isAr
              ? 'لا توجد مقاطع فيديو منشورة حالياً'
              : 'No video clips published yet'}
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto">
            {isAr
              ? 'اضغط على زر «إضافة فيديو من الموبايل» بالأعلى لفتح ملفات هاتفك واختيار أول فيديو لنشره.'
              : 'Tap "Choose Video from Phone" above to pick a video from your device and publish it.'}
          </p>
        </div>
      ) : (
        <div className="space-y-5">
          {videoPosts.map((post) => {
            const author = getUser(post.authorId);
            const isSaved = post.bookmarks.includes(currentUser.id);
            const presence = formatUserPresence(
              author.isOnline,
              author.settings?.showOnlineStatus,
              author.lastActiveAtMs,
              lang
            );
            const audBadge = getAudienceBadge(post.audience);
            const AudIcon = audBadge.icon;

            return (
              <article
                key={post.id}
                className="bg-white dark:bg-[#151D1C] border border-slate-200 dark:border-slate-800 rounded-3xl overflow-hidden shadow-xs"
              >
                {post.repostedByName && (
                  <div className="px-5 pt-3 pb-1 text-xs font-extrabold text-emerald-700 dark:text-emerald-400 flex items-center gap-1.5">
                    <Repeat2 className="w-4 h-4" />
                    <span>
                      {isAr
                        ? `أعاد ${post.repostedByName} نشر هذا الفيديو`
                        : `Reposted by ${post.repostedByName}`}
                    </span>
                  </div>
                )}

                <div className="p-4 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <UserAvatar
                        avatarKey={author.avatarKey}
                        customAvatarUrl={author.customAvatarUrl}
                        name={author.name}
                        size="md"
                      />
                      {presence.isVisibleOnline && (
                        <span className="w-3 h-3 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-[#151D1C] absolute bottom-0 end-0" />
                      )}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-slate-900 dark:text-white">
                          {author.name}
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-bold">
                          {presence.label}
                        </span>
                      </div>
                      <div className="text-xs text-slate-500 flex items-center gap-1.5 mt-0.5">
                        <span dir="ltr">{author.handle}</span>
                        <span>·</span>
                        <span>
                          {formatDynamicTime(
                            post.createdAtMs,
                            post.createdAt,
                            lang
                          )}
                        </span>
                        <span>·</span>
                        <span className="inline-flex items-center gap-0.5 text-[11px] text-[#0E6B63] dark:text-[#5FD0C4] font-semibold">
                          <AudIcon className="w-3 h-3" />
                          <span>{audBadge.label}</span>
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* 3-Dots Menu */}
                  <div className="relative">
                    <button
                      type="button"
                      onClick={() =>
                        setOpenMenuId((prev) =>
                          prev === post.id ? null : post.id
                        )
                      }
                      className="w-9 h-9 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center text-slate-500 cursor-pointer"
                    >
                      <MoreVertical className="w-5 h-5" />
                    </button>

                    {openMenuId === post.id && (
                      <div className="absolute end-0 top-10 z-30 w-56 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 shadow-xl py-1.5 text-xs font-semibold">
                        <button
                          type="button"
                          onClick={() => {
                            onCopyPostText?.(post.content);
                            setOpenMenuId(null);
                          }}
                          className="w-full px-4 py-2.5 text-start hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2.5 cursor-pointer"
                        >
                          <Copy className="w-4 h-4 text-[#0E6B63]" />
                          <span>
                            {isAr ? 'نسخ نص الفيديو' : 'Copy Caption Text'}
                          </span>
                        </button>

                        {post.videoUrl && post.videoUrl !== 'builtin:video' && (
                          <button
                            type="button"
                            onClick={() => {
                              downloadMediaToDevice(
                                post.videoUrl!,
                                'wanas-video'
                              );
                              setOpenMenuId(null);
                            }}
                            className="w-full px-4 py-2.5 text-start hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2.5 cursor-pointer text-emerald-600 dark:text-emerald-400"
                          >
                            <Download className="w-4 h-4" />
                            <span>
                              {isAr
                                ? 'حفظ الفيديو في الهاتف ⬇️'
                                : 'Save Video to Phone ⬇️'}
                            </span>
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => {
                            onCopyPostLink(post.id);
                            setOpenMenuId(null);
                          }}
                          className="w-full px-4 py-2.5 text-start hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2.5 cursor-pointer"
                        >
                          <Link2 className="w-4 h-4 text-[#0E6B63]" />
                          <span>
                            {isAr ? 'نسخ رابط الفيديو' : 'Copy Video Link'}
                          </span>
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            onToggleBookmark(post.id);
                            setOpenMenuId(null);
                          }}
                          className="w-full px-4 py-2.5 text-start hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2.5 cursor-pointer"
                        >
                          <Bookmark className="w-4 h-4 text-[#F2A93B]" />
                          <span>
                            {isSaved
                              ? isAr
                                ? 'إزالة من المحفوظات'
                                : 'Remove Bookmark'
                              : isAr
                              ? 'حفظ في المحفوظات'
                              : 'Bookmark Video'}
                          </span>
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            onSharePost(post);
                            setOpenMenuId(null);
                          }}
                          className="w-full px-4 py-2.5 text-start hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2.5 cursor-pointer"
                        >
                          <Share2 className="w-4 h-4 text-sky-500" />
                          <span>
                            {isAr
                              ? 'مشاركة وإرسال لأصدقاء'
                              : 'Share to Friends'}
                          </span>
                        </button>

                        {post.authorId === currentUser.id && (
                          <button
                            type="button"
                            onClick={() => {
                              onTogglePinPost(post.id);
                              setOpenMenuId(null);
                            }}
                            className="w-full px-4 py-2.5 text-start hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2.5 cursor-pointer"
                          >
                            <Pin className="w-4 h-4 text-teal-600" />
                            <span>
                              {post.isPinned
                                ? isAr
                                  ? 'إلغاء تثبيت من الملف الشخصي'
                                  : 'Unpin from Profile'
                                : isAr
                                ? 'تثبيت في الملف الشخصي'
                                : 'Pin to Profile'}
                            </span>
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => {
                            onReportPost(post.id);
                            setOpenMenuId(null);
                          }}
                          className="w-full px-4 py-2.5 text-start hover:bg-rose-50 dark:hover:bg-rose-950/40 text-rose-600 flex items-center gap-2.5 cursor-pointer"
                        >
                          <Flag className="w-4 h-4" />
                          <span>
                            {isAr ? 'إبلاغ عن الفيديو' : 'Report Video'}
                          </span>
                        </button>

                        {post.authorId === currentUser.id && (
                          <button
                            type="button"
                            onClick={() => {
                              onDeletePost(post.id);
                              setOpenMenuId(null);
                            }}
                            className="w-full px-4 py-2.5 text-start hover:bg-rose-50 dark:hover:bg-rose-950/40 text-rose-600 flex items-center gap-2.5 cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                            <span>
                              {isAr ? 'حذف الفيديو' : 'Delete Video'}
                            </span>
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                {post.content && (
                  <p className="px-4 pb-3 text-sm sm:text-base text-slate-800 dark:text-slate-200 selectable-text">
                    {post.content}
                  </p>
                )}

                {post.videoUrl && post.videoUrl !== 'builtin:video' ? (
                  <div className="relative bg-black">
                    <video
                      src={post.videoUrl}
                      controls
                      playsInline
                      className="w-full max-h-[460px] bg-black object-contain"
                    />
                    <button
                      type="button"
                      onClick={() =>
                        downloadMediaToDevice(post.videoUrl!, 'wanas-video')
                      }
                      className="absolute top-3 end-3 px-3 py-1.5 rounded-xl bg-black/70 hover:bg-black text-white text-xs font-bold flex items-center gap-1.5 backdrop-blur-md cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5 text-[#F2A93B]" />
                      <span>{isAr ? 'حفظ الفيديو' : 'Save Video'}</span>
                    </button>
                  </div>
                ) : (
                  <div className="px-4">
                    <PostMediaVisual
                      mediaKey={post.mediaKey || 'cairo_sunset'}
                    />
                  </div>
                )}

                <div className="p-4 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-600 dark:text-slate-400">
                  <div className="flex flex-wrap items-center gap-2">
                    <ReactionPickerBar
                      lang={lang}
                      currentUserId={currentUser.id}
                      reactions={post.reactions}
                      likesFallback={post.likes}
                      onSelectReaction={(r) => onReactToPost(post.id, r)}
                    />

                    <button
                      type="button"
                      onClick={() => onOpenCommentsPage(post)}
                      className="min-h-[38px] px-3 py-1.5 rounded-xl bg-slate-100/80 dark:bg-slate-800/80 hover:bg-slate-200/70 flex items-center gap-1.5 font-bold cursor-pointer"
                    >
                      <MessageCircle className="w-4 h-4 text-[#0E6B63] dark:text-[#5FD0C4]" />
                      <span>{post.comments.length}</span>
                      <span>{isAr ? 'التعليقات' : 'Comments'}</span>
                    </button>

                    {/* Repost Video Button ("إعادة نشر الفيديو") */}
                    <button
                      type="button"
                      onClick={() => onRepost(post)}
                      className="min-h-[38px] px-3 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 font-bold flex items-center gap-1.5 cursor-pointer"
                    >
                      <Repeat2 className="w-4 h-4" />
                      <span>{isAr ? 'إعادة نشر' : 'Repost'}</span>
                      {(post.repostsCount || 0) > 0 && (
                        <span className="font-mono">{post.repostsCount}</span>
                      )}
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={() => onSharePost(post)}
                    className="min-h-[38px] px-3.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Share2 className="w-4 h-4 text-sky-500" />
                    <span>{isAr ? 'مشاركة للأصدقاء' : 'Share'}</span>
                    {(post.sharesCount || 0) > 0 && (
                      <span className="font-mono">{post.sharesCount}</span>
                    )}
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
};
