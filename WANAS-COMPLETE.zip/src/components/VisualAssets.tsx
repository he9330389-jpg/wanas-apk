import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause, Volume2 } from 'lucide-react';
import type { User } from '../types.ts';

export const WanasBrandIcon: React.FC<{ className?: string }> = ({
  className = 'w-9 h-9',
}) => (
  <svg
    viewBox="0 0 100 100"
    className={`${className} shrink-0 select-none`}
    role="img"
    aria-label="WANAS ونس"
  >
    <rect width="100" height="100" rx="24" fill="#0E6B63" />
    <defs>
      <clipPath id="wanasLeftCircleClip">
        <circle cx="39" cy="50" r="22" />
      </clipPath>
    </defs>
    <circle
      cx="61"
      cy="50"
      r="22"
      fill="#F2A93B"
      clipPath="url(#wanasLeftCircleClip)"
    />
    <circle
      cx="39"
      cy="50"
      r="22"
      fill="none"
      stroke="#FFFFFF"
      strokeWidth="6.5"
    />
    <circle
      cx="61"
      cy="50"
      r="22"
      fill="none"
      stroke="#FFFFFF"
      strokeWidth="6.5"
    />
  </svg>
);

interface AvatarProps {
  avatarKey?: User['avatarKey'];
  customAvatarUrl?: string;
  name: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  isOnline?: boolean;
  isSpeaking?: boolean;
}

const sizeMap = {
  sm: 'w-9 h-9 text-xs',
  md: 'w-11 h-11 text-sm',
  lg: 'w-14 h-14 text-base',
  xl: 'w-20 h-20 text-xl',
};

export const UserAvatar: React.FC<AvatarProps> = ({
  avatarKey = 'abdallah',
  customAvatarUrl,
  name,
  size = 'md',
  isSpeaking = false,
}) => {
  const paletteMap: Record<
    User['avatarKey'],
    { bg: string; accent: string; skin: string; hair: string; shirt: string }
  > = {
    abdallah: {
      bg: 'from-[#0E6B63] to-[#0F1514]',
      accent: '#5FD0C4',
      skin: '#E8B89A',
      hair: '#1E293B',
      shirt: '#0E6B63',
    },
    omar: {
      bg: 'from-slate-700 to-slate-900',
      accent: '#0EA5E9',
      skin: '#E0AC8B',
      hair: '#0F172A',
      shirt: '#1E40AF',
    },
    layla: {
      bg: 'from-[#F2A93B] to-amber-900',
      accent: '#F2A93B',
      skin: '#F1C6A7',
      hair: '#292524',
      shirt: '#B45309',
    },
    tariq: {
      bg: 'from-emerald-700 to-teal-950',
      accent: '#10B981',
      skin: '#D69E76',
      hair: '#1C1917',
      shirt: '#065F46',
    },
    noor: {
      bg: 'from-indigo-700 to-slate-900',
      accent: '#6366F1',
      skin: '#F3CBB2',
      hair: '#1E1B4B',
      shirt: '#3730A3',
    },
  };

  const p = paletteMap[avatarKey] || paletteMap.abdallah;

  if (customAvatarUrl) {
    return (
      <div
        className={`relative inline-flex items-center justify-center rounded-full bg-[#0E6B63] ${sizeMap[size]} shrink-0 select-none overflow-hidden ${
          isSpeaking
            ? 'ring-2 ring-offset-2 ring-[#F2A93B] dark:ring-offset-[#0F1514]'
            : 'border border-slate-200/60 dark:border-slate-700/60'
        }`}
        title={name}
      >
        <img
          src={customAvatarUrl}
          alt={name}
          className="w-full h-full object-cover"
        />
      </div>
    );
  }

  return (
    <div
      className={`relative inline-flex items-center justify-center rounded-full bg-gradient-to-br ${p.bg} ${sizeMap[size]} shrink-0 select-none overflow-hidden ${
        isSpeaking
          ? 'ring-2 ring-offset-2 ring-[#F2A93B] dark:ring-offset-[#0F1514]'
          : 'border border-slate-200/60 dark:border-slate-700/60'
      }`}
      title={name}
    >
      <svg
        viewBox="0 0 80 80"
        className="w-full h-full"
        role="img"
        aria-label={name}
      >
        <defs>
          <radialGradient id={`grad_${avatarKey}`} cx="30%" cy="25%" r="75%">
            <stop offset="0%" stopColor={p.accent} stopOpacity="0.35" />
            <stop offset="100%" stopColor="#0F1514" stopOpacity="0.9" />
          </radialGradient>
        </defs>
        <rect width="80" height="80" fill={`url(#grad_${avatarKey})`} />
        <circle
          cx="40"
          cy="40"
          r="32"
          fill="none"
          stroke={p.accent}
          strokeOpacity="0.22"
          strokeWidth="1.2"
        />
        <path d="M14 78 C16 58, 64 58, 66 78 Z" fill={p.shirt} />
        <path
          d="M28 60 L40 70 L52 60"
          fill="none"
          stroke="#FFFFFF"
          strokeOpacity="0.35"
          strokeWidth="2"
        />
        <rect x="34" y="45" width="12" height="12" rx="4" fill={p.skin} />
        <circle cx="40" cy="34" r="14" fill={p.skin} />
        {avatarKey === 'layla' || avatarKey === 'noor' ? (
          <path
            d="M24 34 C24 17, 56 17, 56 34 C56 44, 53 50, 50 52 C51 40, 48 26, 40 26 C32 26, 29 40, 30 52 C27 50, 24 44, 24 34 Z"
            fill={p.hair}
          />
        ) : (
          <>
            <path
              d="M25 31 C25 18, 55 18, 55 31 C52 24, 28 24, 25 31 Z"
              fill={p.hair}
            />
            <path
              d="M28 36 C28 46, 52 46, 52 36 C50 42, 30 42, 28 36 Z"
              fill={p.hair}
              fillOpacity="0.75"
            />
          </>
        )}
        <circle cx="35" cy="33" r="1.5" fill="#0F1514" />
        <circle cx="45" cy="33" r="1.5" fill="#0F1514" />
        <path
          d="M35 39 Q40 43 45 39"
          fill="none"
          stroke="#0F1514"
          strokeWidth="1.6"
          strokeLinecap="round"
        />
      </svg>
    </div>
  );
};

interface AudioWavePlayerProps {
  audioUrl: string;
  durationLabel?: string;
  title?: string;
  compact?: boolean;
}

export const AudioWavePlayer: React.FC<AudioWavePlayerProps> = ({
  audioUrl,
  durationLabel = '0:18',
  title,
  compact = false,
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (timerRef.current) window.clearInterval(timerRef.current);
      if (audioRef.current) {
        audioRef.current.pause();
      }
    };
  }, []);

  const togglePlay = () => {
    if (isPlaying) {
      audioRef.current?.pause();
      if (timerRef.current) window.clearInterval(timerRef.current);
      setIsPlaying(false);
      return;
    }

    if (audioUrl && audioUrl !== 'synth:voice') {
      try {
        if (!audioRef.current) {
          audioRef.current = new Audio(audioUrl);
          audioRef.current.ontimeupdate = () => {
            if (audioRef.current && audioRef.current.duration) {
              setProgress(
                Math.min(
                  100,
                  Math.round(
                    (audioRef.current.currentTime / audioRef.current.duration) * 100
                  )
                )
              );
            }
          };
          audioRef.current.onended = () => {
            setIsPlaying(false);
            setProgress(0);
          };
        }
        audioRef.current.play().catch(() => {
          // Fallback progress animation if audio codec unsupported
        });
      } catch {
        // Fallback animation
      }
    }

    setIsPlaying(true);
    timerRef.current = window.setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          if (timerRef.current) window.clearInterval(timerRef.current);
          setIsPlaying(false);
          return 0;
        }
        return prev + 5;
      });
    }, 350);
  };

  const bars = [28, 52, 74, 42, 88, 64, 35, 92, 58, 45, 80, 62, 38, 70, 50, 84, 44, 60];

  return (
    <div
      className={`rounded-2xl border border-[#0E6B63]/25 dark:border-[#5FD0C4]/25 bg-[#0E6B63]/8 dark:bg-[#0E6B63]/20 ${
        compact ? 'p-2.5' : 'p-3.5'
      } flex items-center gap-3`}
    >
      <button
        type="button"
        onClick={togglePlay}
        className={`${
          compact ? 'w-9 h-9' : 'w-11 h-11'
        } rounded-full bg-[#0E6B63] hover:bg-[#0b5650] text-white flex items-center justify-center shrink-0 shadow-xs cursor-pointer transition-transform active:scale-95`}
      >
        {isPlaying ? (
          <Pause className="w-4 h-4 fill-current" />
        ) : (
          <Play className="w-4 h-4 fill-current ms-0.5" />
        )}
      </button>

      <div className="flex-1 min-w-0 space-y-1.5">
        {title && (
          <div className="text-xs font-bold text-slate-800 dark:text-slate-100 truncate flex items-center gap-1.5">
            <Volume2 className="w-3.5 h-3.5 text-[#0E6B63] dark:text-[#5FD0C4]" />
            <span>{title}</span>
          </div>
        )}
        <div className="flex items-center gap-1 h-6">
          {bars.map((h, i) => {
            const active = (i / bars.length) * 100 <= progress;
            return (
              <div
                key={i}
                style={{ height: `${Math.max(20, isPlaying ? ((h + progress * 3) % 90) + 15 : h)}%` }}
                className={`flex-1 rounded-full transition-all duration-150 ${
                  active
                    ? 'bg-[#F2A93B]'
                    : 'bg-[#0E6B63]/40 dark:bg-[#5FD0C4]/40'
                }`}
              />
            );
          })}
        </div>
      </div>

      <span className="text-xs font-mono font-semibold text-[#0E6B63] dark:text-[#5FD0C4] shrink-0">
        {durationLabel}
      </span>
    </div>
  );
};

interface PostMediaVisualProps {
  mediaKey: 'majlis_coffee' | 'workspace_code' | 'cairo_sunset' | 'audio_waves';
  aspect?: 'video' | 'story';
}

export const PostMediaVisual: React.FC<PostMediaVisualProps> = ({
  mediaKey,
  aspect = 'video',
}) => {
  const heightClass = aspect === 'story' ? 'h-64' : 'h-60 sm:h-72';

  if (mediaKey === 'majlis_coffee') {
    return (
      <div
        className={`relative w-full ${heightClass} rounded-xl overflow-hidden bg-stone-900 border border-stone-800 select-none`}
      >
        <svg
          viewBox="0 0 800 450"
          className="w-full h-full object-cover"
          preserveAspectRatio="xMidYMid slice"
        >
          <defs>
            <linearGradient id="majlisGrad" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#0F1514" />
              <stop offset="55%" stopColor="#0E6B63" />
              <stop offset="100%" stopColor="#1F1A12" />
            </linearGradient>
            <radialGradient id="lantern" cx="50%" cy="38%" r="48%">
              <stop offset="0%" stopColor="#F2A93B" stopOpacity="0.55" />
              <stop offset="60%" stopColor="#D97706" stopOpacity="0.18" />
              <stop offset="100%" stopColor="#000000" stopOpacity="0" />
            </radialGradient>
          </defs>
          <rect width="800" height="450" fill="url(#majlisGrad)" />
          <rect width="800" height="450" fill="url(#lantern)" />
          <path
            d="M230 450 L230 190 A170 170 0 0 1 570 190 L570 450 Z"
            fill="#0F1514"
            fillOpacity="0.55"
            stroke="#F2A93B"
            strokeOpacity="0.4"
            strokeWidth="2"
          />
          <line x1="400" y1="0" x2="400" y2="125" stroke="#F2A93B" strokeWidth="2" />
          <path d="M365 125 Q400 95 435 125 Z" fill="#F2A93B" />
          <circle cx="400" cy="132" r="14" fill="#FEF3C7" />
          <ellipse
            cx="400"
            cy="365"
            rx="220"
            ry="36"
            fill="#1F1A12"
            stroke="#F2A93B"
            strokeOpacity="0.4"
            strokeWidth="1.5"
          />
          <path
            d="M360 350 L372 265 L418 265 L430 350 Z"
            fill="#F2A93B"
            fillOpacity="0.85"
            stroke="#FDE68A"
            strokeWidth="2"
          />
        </svg>
        <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent p-4 flex items-center justify-between text-xs text-amber-100">
          <span>مجلس ونس المسائي · قهوة وحوارات دافئة</span>
          <span>WANAS Majlis</span>
        </div>
      </div>
    );
  }

  return (
    <div
      className={`relative w-full ${heightClass} rounded-xl overflow-hidden bg-[#0F1514] border border-slate-800 select-none`}
    >
      <svg
        viewBox="0 0 800 450"
        className="w-full h-full object-cover"
        preserveAspectRatio="xMidYMid slice"
      >
        <defs>
          <linearGradient id="sunsetGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#0F1514" />
            <stop offset="50%" stopColor="#0E6B63" />
            <stop offset="100%" stopColor="#1F1A12" />
          </linearGradient>
        </defs>
        <rect width="800" height="450" fill="url(#sunsetGrad)" />
        <circle cx="400" cy="185" r="85" fill="#F2A93B" fillOpacity="0.28" />
        <circle cx="365" cy="185" r="55" fill="none" stroke="#FFFFFF" strokeWidth="8" strokeOpacity="0.8" />
        <circle cx="435" cy="185" r="55" fill="none" stroke="#FFFFFF" strokeWidth="8" strokeOpacity="0.8" />
        <path
          d="M0 320 Q200 260 400 310 T800 290 L800 450 L0 450 Z"
          fill="#0F1514"
          fillOpacity="0.65"
        />
        <path
          d="M0 365 Q260 315 520 355 T800 340 L800 450 L0 450 Z"
          fill="#0F1514"
          fillOpacity="0.92"
        />
      </svg>
      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent p-4 flex items-center justify-between text-xs text-slate-200">
        <span>منصة ونس للتواصل الاجتماعي</span>
        <span>WANAS Social</span>
      </div>
    </div>
  );
};

interface CoverBannerVisualProps {
  coverKey?: 'royal_majlis' | 'teal_horizon' | 'cairo_nights' | 'tech_oasis';
  customCoverUrl?: string;
  heightClass?: string;
  children?: React.ReactNode;
}

export const CoverBannerVisual: React.FC<CoverBannerVisualProps> = ({
  coverKey = 'royal_majlis',
  customCoverUrl,
  heightClass = 'h-36 sm:h-44',
  children,
}) => {
  const themes = {
    royal_majlis: {
      stop1: '#0F1514',
      stop2: '#0E6B63',
      stop3: '#1F1A12',
      accent: '#F2A93B',
      accentSoft: '#FAF7F2',
    },
    teal_horizon: {
      stop1: '#073B36',
      stop2: '#0E6B63',
      stop3: '#0F1514',
      accent: '#5FD0C4',
      accentSoft: '#FAF7F2',
    },
    cairo_nights: {
      stop1: '#1F1A12',
      stop2: '#78350f',
      stop3: '#0F1514',
      accent: '#F2A93B',
      accentSoft: '#FEF3C7',
    },
    tech_oasis: {
      stop1: '#0F1514',
      stop2: '#0E6B63',
      stop3: '#1e293b',
      accent: '#F2A93B',
      accentSoft: '#5FD0C4',
    },
  };

  const t = themes[coverKey] || themes.royal_majlis;

  return (
    <div
      className={`relative w-full ${heightClass} overflow-hidden select-none bg-[#0F1514]`}
    >
      {customCoverUrl ? (
        <img
          src={customCoverUrl}
          alt="Cover"
          className="w-full h-full object-cover"
        />
      ) : (
        <svg
          viewBox="0 0 1200 360"
          className="w-full h-full object-cover"
          preserveAspectRatio="xMidYMid slice"
        >
          <defs>
            <linearGradient id={`coverGrad_${coverKey}`} x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor={t.stop1} />
              <stop offset="52%" stopColor={t.stop2} />
              <stop offset="100%" stopColor={t.stop3} />
            </linearGradient>
            <radialGradient id={`coverGlow_${coverKey}`} cx="80%" cy="25%" r="55%">
              <stop offset="0%" stopColor={t.accent} stopOpacity="0.45" />
              <stop offset="60%" stopColor={t.accent} stopOpacity="0.12" />
              <stop offset="100%" stopColor={t.accent} stopOpacity="0" />
            </radialGradient>
            <clipPath id={`coverLogoClip_${coverKey}`}>
              <circle cx="932" cy="115" r="52" />
            </clipPath>
          </defs>
          <rect width="1200" height="360" fill={`url(#coverGrad_${coverKey})`} />
          <rect width="1200" height="360" fill={`url(#coverGlow_${coverKey})`} />

          {/* Official Brand Overlapping Rings Watermark on Cover */}
          <g opacity="0.32">
            <circle
              cx="984"
              cy="115"
              r="52"
              fill="#F2A93B"
              clipPath={`url(#coverLogoClip_${coverKey})`}
            />
            <circle
              cx="932"
              cy="115"
              r="52"
              fill="none"
              stroke="#FFFFFF"
              strokeWidth="12"
            />
            <circle
              cx="984"
              cy="115"
              r="52"
              fill="none"
              stroke="#FFFFFF"
              strokeWidth="12"
            />
          </g>

          <path
            d="M0 265 Q180 205 360 250 T720 235 T1080 255 L1200 245 L1200 360 L0 360 Z"
            fill="#0F1514"
            fillOpacity="0.48"
          />
          <path
            d="M0 300 Q240 250 480 295 T960 280 L1200 295 L1200 360 L0 360 Z"
            fill="#0F1514"
            fillOpacity="0.78"
          />

          <text
            x="600"
            y="185"
            textAnchor="middle"
            fill="#ffffff"
            fillOpacity="0.06"
            fontSize="110"
            fontWeight="800"
            fontFamily="Tajawal, sans-serif"
          >
            ونس WANAS
          </text>
        </svg>
      )}
      {children}
    </div>
  );
};
