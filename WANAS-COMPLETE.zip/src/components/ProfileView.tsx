import React, { useState } from 'react';
import {
  Edit3,
  Pin,
  Bookmark,
  Heart,
  MessageCircle,
  Share2,
  MoreVertical,
  Link2,
  Trash2,
  Camera,
  Image as ImageIcon,
  Check,
  MapPin,
  Globe,
  ExternalLink,
  FolderOpen,
} from 'lucide-react';
import type { Language, User, Post, CoverKey } from '../types.ts';
import {
  UserAvatar,
  CoverBannerVisual,
  AudioWavePlayer,
  PostMediaVisual,
} from './VisualAssets.tsx';
import { PhotoStudioModal } from './PhotoStudioModal.tsx';
import { readFileAsCompressedDataUrl } from '../utils/mediaUtils.ts';

interface ProfileViewProps {
  lang: Language;
  currentUser: User;
  posts: Post[];
  onUpdateUser: (updated: Partial<User>) => void;
  onToggleLike: (postId: string) => void;
  onToggleBookmark: (postId: string) => void;
  onTogglePinPost: (postId: string) => void;
  onDeletePost: (postId: string) => void;
  onCopyPostLink: (postId: string) => void;
  onSharePost: (post: Post) => void;
  onOpenCommentsPage: (post: Post) => void;
}

const COVER_KEYS: CoverKey[] = [
  'royal_majlis',
  'teal_horizon',
  'cairo_nights',
  'tech_oasis',
];

export const ProfileView: React.FC<ProfileViewProps> = ({
  lang,
  currentUser,
  posts,
  onUpdateUser,
  onToggleLike,
  onToggleBookmark,
  onTogglePinPost,
  onDeletePost,
  onCopyPostLink,
  onSharePost,
  onOpenCommentsPage,
}) => {
  const isAr = lang === 'ar';

  const [isEditing, setIsEditing] = useState(false);
  const [nameDraft, setNameDraft] = useState(currentUser.name);
  const [handleDraft, setHandleDraft] = useState(currentUser.handle);
  const [roleDraft, setRoleDraft] = useState(currentUser.role);
  const [bioDraft, setBioDraft] = useState(currentUser.bio);
  const [locationDraft, setLocationDraft] = useState(currentUser.location || '');
  const [websiteDraft, setWebsiteDraft] = useState(currentUser.website || '');

  // Photo Studio Modal state ('avatar' | 'cover' | null)
  const [studioMode, setStudioMode] = useState<'avatar' | 'cover' | null>(null);

  const [profileTab, setProfileTab] = useState<
    'posts' | 'pinned' | 'saved' | 'media'
  >('posts');
  const [openMenuId, setOpenMenuId] = useState<string | null>(null);

  const myPosts = posts.filter((p) => p.authorId === currentUser.id);
  const pinnedPosts = myPosts.filter((p) => p.isPinned);
  const savedPosts = posts.filter((p) => p.bookmarks.includes(currentUser.id));
  const mediaPosts = myPosts.filter(
    (p) => Boolean(p.imageUrl || p.videoUrl || p.audioUrl || p.mediaKey)
  );

  const displayedPosts =
    profileTab === 'pinned'
      ? pinnedPosts
      : profileTab === 'saved'
      ? savedPosts
      : profileTab === 'media'
      ? mediaPosts
      : myPosts;

  const handleQuickAvatarUpload = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressed = await readFileAsCompressedDataUrl(file, 'avatar');
      onUpdateUser({ customAvatarUrl: compressed });
    } catch {
      // ignore
    }
  };

  const handleQuickCoverUpload = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressed = await readFileAsCompressedDataUrl(file, 'cover');
      onUpdateUser({ customCoverUrl: compressed });
    } catch {
      // ignore
    }
  };

  const handleCycleCover = () => {
    const curr = currentUser.coverKey || 'royal_majlis';
    const next = COVER_KEYS[(COVER_KEYS.indexOf(curr) + 1) % COVER_KEYS.length];
    onUpdateUser({ coverKey: next, customCoverUrl: undefined });
  };

  const handleSaveBioAndProfile = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateUser({
      name: nameDraft.trim() || currentUser.name,
      nameEn: nameDraft.trim() || currentUser.nameEn,
      handle: handleDraft.trim().startsWith('@')
        ? handleDraft.trim()
        : `@${handleDraft.trim()}`,
      role: roleDraft.trim() || currentUser.role,
      roleEn: roleDraft.trim() || currentUser.roleEn,
      bio: bioDraft.trim(),
      bioEn: bioDraft.trim(),
      location: locationDraft.trim(),
      website: websiteDraft.trim(),
    });
    setIsEditing(false);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Main Profile Header Card with Cover & Avatar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl overflow-hidden shadow-xs">
        <CoverBannerVisual
          coverKey={currentUser.coverKey || 'royal_majlis'}
          customCoverUrl={currentUser.customCoverUrl}
          heightClass="h-48 sm:h-60"
        >
          {/* Cover Action Buttons */}
          <div className="absolute top-3.5 end-3.5 flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setStudioMode('cover')}
              className="px-3.5 py-2 rounded-xl bg-black/65 hover:bg-black/80 backdrop-blur-md text-white text-xs font-bold flex items-center gap-1.5 border border-white/20 cursor-pointer shadow-sm"
            >
              <Camera className="w-3.5 h-3.5 text-[#F2A93B]" />
              <span>
                {isAr
                  ? 'تغيير الغلاف (كاميرا / ملفات الهاتف)'
                  : 'Change Cover (Camera / Files)'}
              </span>
            </button>

            <label className="px-3 py-2 rounded-xl bg-black/65 hover:bg-black/80 backdrop-blur-md text-white text-xs font-bold flex items-center gap-1.5 border border-white/20 cursor-pointer shadow-sm">
              <FolderOpen className="w-3.5 h-3.5 text-[#5FD0C4]" />
              <span>{isAr ? 'رفع غلاف من الملفات' : 'Upload File'}</span>
              <input
                type="file"
                accept="image/*"
                onChange={handleQuickCoverUpload}
                className="hidden"
              />
            </label>

            <button
              type="button"
              onClick={handleCycleCover}
              className="px-3 py-2 rounded-xl bg-black/55 hover:bg-black/75 backdrop-blur-md text-white text-xs font-bold flex items-center gap-1.5 border border-white/15 cursor-pointer"
            >
              <ImageIcon className="w-3.5 h-3.5 text-[#F2A93B]" />
              <span>{isAr ? 'تبديل الثيم' : 'Theme'}</span>
            </button>
          </div>
        </CoverBannerVisual>

        <div className="px-5 sm:px-7 pb-6">
          <div className="flex flex-wrap items-end justify-between gap-4 -mt-12 relative z-10">
            <div className="flex items-end gap-3">
              <div className="relative group">
                <div
                  onClick={() => setStudioMode('avatar')}
                  className="ring-4 ring-white dark:ring-slate-900 rounded-full cursor-pointer"
                  title={isAr ? 'اضغط لتغيير الصورة الشخصية' : 'Tap to change photo'}
                >
                  <UserAvatar
                    avatarKey={currentUser.avatarKey}
                    customAvatarUrl={currentUser.customAvatarUrl}
                    name={currentUser.name}
                    size="xl"
                  />
                </div>
                <button
                  type="button"
                  onClick={() => setStudioMode('avatar')}
                  title={isAr ? 'تغيير الصورة الشخصية' : 'Change Profile Photo'}
                  className="absolute bottom-0 end-0 w-9 h-9 rounded-full bg-[#0E6B63] hover:bg-[#0b5650] text-white flex items-center justify-center shadow-md cursor-pointer border-2 border-white dark:border-slate-900"
                >
                  <Camera className="w-4 h-4 text-[#F2A93B]" />
                </button>
              </div>

              {/* Direct Quick Buttons for Changing Profile Picture */}
              <div className="flex flex-wrap items-center gap-1.5 pb-1">
                <button
                  type="button"
                  onClick={() => setStudioMode('avatar')}
                  className="px-3 py-1.5 rounded-xl bg-[#0E6B63]/10 dark:bg-[#0E6B63]/25 text-[#0E6B63] dark:text-[#5FD0C4] text-xs font-bold flex items-center gap-1.5 hover:bg-[#0E6B63]/20 cursor-pointer"
                >
                  <Camera className="w-3.5 h-3.5" />
                  <span>
                    {isAr ? 'تغيير الصورة الشخصية' : 'Change Avatar'}
                  </span>
                </button>

                <label className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-bold flex items-center gap-1.5 hover:bg-slate-200 dark:hover:bg-slate-700 cursor-pointer">
                  <FolderOpen className="w-3.5 h-3.5 text-[#F2A93B]" />
                  <span>{isAr ? 'من ملفات الهاتف' : 'From Files'}</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleQuickAvatarUpload}
                    className="hidden"
                  />
                </label>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                setNameDraft(currentUser.name);
                setHandleDraft(currentUser.handle);
                setRoleDraft(currentUser.role);
                setBioDraft(currentUser.bio);
                setLocationDraft(currentUser.location || '');
                setWebsiteDraft(currentUser.website || '');
                setIsEditing((prev) => !prev);
              }}
              className="min-h-[42px] px-4 py-2 rounded-xl bg-[#0E6B63] hover:bg-[#0b5650] text-white text-xs sm:text-sm font-bold flex items-center gap-2 cursor-pointer"
            >
              <Edit3 className="w-4 h-4 text-[#F2A93B]" />
              <span>
                {isEditing
                  ? isAr
                    ? 'إغلاق التعديل'
                    : 'Close Editor'
                  : isAr
                  ? 'تعديل الملف الشخصي والسيرة الذاتية'
                  : 'Edit Profile & Bio'}
              </span>
            </button>
          </div>

          {/* Bio & Details Display */}
          {!isEditing ? (
            <div className="mt-4 space-y-3">
              <div>
                <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
                  {currentUser.name}
                </h1>
                <div className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 flex flex-wrap items-center gap-2 mt-0.5">
                  <span dir="ltr">{currentUser.handle}</span>
                  <span>·</span>
                  <span>{currentUser.role}</span>
                  {(currentUser.email || currentUser.phone) && (
                    <>
                      <span>·</span>
                      <span
                        dir="ltr"
                        className="text-[#0E6B63] dark:text-[#5FD0C4] font-mono"
                      >
                        {currentUser.email || currentUser.phone}
                      </span>
                    </>
                  )}
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-800">
                <div className="text-[11px] font-bold text-[#0E6B63] dark:text-[#5FD0C4] mb-1">
                  {isAr ? 'السيرة الذاتية (Bio):' : 'Biography:'}
                </div>
                <p className="text-sm text-slate-700 dark:text-slate-200 whitespace-pre-line leading-relaxed">
                  {currentUser.bio ||
                    (isAr
                      ? 'اضغط على «تعديل الملف الشخصي والسيرة الذاتية» لكتابة نبذتك الشخصية.'
                      : 'Tap Edit Profile to write your biography.')}
                </p>
              </div>

              {(currentUser.location || currentUser.website) && (
                <div className="flex flex-wrap items-center gap-4 text-xs text-slate-500 dark:text-slate-400">
                  {currentUser.location && (
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-[#0E6B63]" />
                      <span>{currentUser.location}</span>
                    </span>
                  )}
                  {currentUser.website && (
                    <a
                      href={
                        currentUser.website.startsWith('http')
                          ? currentUser.website
                          : `https://${currentUser.website}`
                      }
                      target="_blank"
                      rel="noreferrer"
                      className="flex items-center gap-1 text-[#0E6B63] dark:text-[#5FD0C4] hover:underline"
                    >
                      <Globe className="w-3.5 h-3.5" />
                      <span dir="ltr">{currentUser.website}</span>
                    </a>
                  )}
                </div>
              )}

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center gap-6 text-xs sm:text-sm">
                <div>
                  <span className="font-extrabold text-slate-900 dark:text-white font-mono">
                    {myPosts.length}
                  </span>{' '}
                  <span className="text-slate-500">{isAr ? 'منشور' : 'Posts'}</span>
                </div>
                <div>
                  <span className="font-extrabold text-slate-900 dark:text-white font-mono">
                    {pinnedPosts.length}
                  </span>{' '}
                  <span className="text-slate-500">
                    {isAr ? 'منشور مثبت' : 'Pinned'}
                  </span>
                </div>
                <div>
                  <span className="font-extrabold text-slate-900 dark:text-white font-mono">
                    {currentUser.followersCount}
                  </span>{' '}
                  <span className="text-slate-500">
                    {isAr ? 'متابِع' : 'Followers'}
                  </span>
                </div>
                <div>
                  <span className="font-extrabold text-slate-900 dark:text-white font-mono">
                    {currentUser.followingCount}
                  </span>{' '}
                  <span className="text-slate-500">
                    {isAr ? 'يتابِع' : 'Following'}
                  </span>
                </div>
              </div>
            </div>
          ) : (
            <form
              onSubmit={handleSaveBioAndProfile}
              className="mt-5 p-4 sm:p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-4"
            >
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'الاسم الكامل' : 'Full Name'}
                  </label>
                  <input
                    type="text"
                    required
                    value={nameDraft}
                    onChange={(e) => setNameDraft(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'اسم المستخدم (@)' : 'Username (@)'}
                  </label>
                  <input
                    type="text"
                    dir="ltr"
                    value={handleDraft}
                    onChange={(e) => setHandleDraft(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-sm"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'المسمى الشخصي' : 'Headline / Role'}
                  </label>
                  <input
                    type="text"
                    value={roleDraft}
                    onChange={(e) => setRoleDraft(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'المدينة / الدولة' : 'Location'}
                  </label>
                  <input
                    type="text"
                    value={locationDraft}
                    onChange={(e) => setLocationDraft(e.target.value)}
                    placeholder={isAr ? 'مثال: القاهرة، مصر' : 'Cairo, Egypt'}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {isAr ? 'رابط شخصي (اختياري)' : 'Website'}
                  </label>
                  <input
                    type="text"
                    dir="ltr"
                    value={websiteDraft}
                    onChange={(e) => setWebsiteDraft(e.target.value)}
                    placeholder="https://..."
                    className="w-full px-3.5 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  {isAr ? 'كتابة السيرة الذاتية (Bio)' : 'Biography'}
                </label>
                <textarea
                  rows={3}
                  value={bioDraft}
                  onChange={(e) => setBioDraft(e.target.value)}
                  placeholder={
                    isAr
                      ? 'اكتب سيرتك الذاتية واهتماماتك هنا...'
                      : 'Write your bio here...'
                  }
                  className="w-full p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-sm resize-none"
                />
              </div>

              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-400 cursor-pointer"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-[#0E6B63] text-white text-xs sm:text-sm font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  <Check className="w-4 h-4 text-[#F2A93B]" />
                  <span>
                    {isAr ? 'حفظ السيرة الذاتية والبيانات' : 'Save Profile'}
                  </span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>

      {/* Pinned Posts Highlight Section (المنشورات المثبتة) */}
      {pinnedPosts.length > 0 && profileTab === 'posts' && (
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-xs font-extrabold text-[#0E6B63] dark:text-[#5FD0C4] px-1">
            <Pin className="w-4 h-4 text-[#F2A93B]" />
            <span>
              {isAr
                ? `المنشورات المثبتة في ملفك الشخصي (${pinnedPosts.length})`
                : `Pinned Posts (${pinnedPosts.length})`}
            </span>
          </div>
          {pinnedPosts.map((post) => (
            <div
              key={`pin_${post.id}`}
              className="p-4 rounded-2xl bg-amber-50/60 dark:bg-amber-950/20 border border-[#F2A93B]/40 flex items-start justify-between gap-3"
            >
              <div className="space-y-1">
                <div className="inline-flex items-center gap-1 text-[11px] font-bold text-[#F2A93B]">
                  <Pin className="w-3.5 h-3.5" />
                  <span>{isAr ? 'منشور مثبت' : 'Pinned Post'}</span>
                </div>
                <p className="text-sm text-slate-800 dark:text-slate-200 whitespace-pre-line">
                  {post.content}
                </p>
              </div>
              <button
                type="button"
                onClick={() => onTogglePinPost(post.id)}
                className="px-3 py-1 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-600 dark:text-slate-300 shrink-0 cursor-pointer"
              >
                {isAr ? 'إلغاء التثبيت' : 'Unpin'}
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Profile Content Tabs */}
      <div className="grid grid-cols-4 gap-2 p-1.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
        {(
          [
            {
              id: 'posts',
              labelAr: `منشوراتي (${myPosts.length})`,
              labelEn: `Posts (${myPosts.length})`,
            },
            {
              id: 'pinned',
              labelAr: `المثبتة (${pinnedPosts.length})`,
              labelEn: `Pinned (${pinnedPosts.length})`,
            },
            {
              id: 'media',
              labelAr: `الوسائط (${mediaPosts.length})`,
              labelEn: `Media (${mediaPosts.length})`,
            },
            {
              id: 'saved',
              labelAr: `المحفوظات (${savedPosts.length})`,
              labelEn: `Saved (${savedPosts.length})`,
            },
          ] as const
        ).map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setProfileTab(t.id)}
            className={`py-2.5 px-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              profileTab === t.id
                ? 'bg-[#0E6B63] text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {isAr ? t.labelAr : t.labelEn}
          </button>
        ))}
      </div>

      {/* Posts List */}
      {displayedPosts.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-10 text-center space-y-2">
          <p className="text-sm font-bold text-slate-600 dark:text-slate-400">
            {profileTab === 'pinned'
              ? isAr
                ? 'لم تقم بتثبيت أي منشور بعد. يمكنك تثبيت أي منشور من قائمة الثلاث نقاط (⋮) بجانب المنشور.'
                : 'No pinned posts yet. Use the 3-dots menu on any of your posts to pin it here.'
              : isAr
              ? 'لا توجد منشورات في هذا القسم حالياً.'
              : 'No posts in this section yet.'}
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {displayedPosts.map((post) => {
            const isLiked = post.likes.includes(currentUser.id);
            const isSaved = post.bookmarks.includes(currentUser.id);

            return (
              <article
                key={post.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <UserAvatar
                      avatarKey={currentUser.avatarKey}
                      customAvatarUrl={currentUser.customAvatarUrl}
                      name={currentUser.name}
                      size="md"
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-slate-900 dark:text-white">
                          {currentUser.name}
                        </span>
                        {post.isPinned && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-500/15 text-[#F2A93B] text-[10px] font-bold">
                            <Pin className="w-3 h-3" />
                            <span>{isAr ? 'مثبت' : 'Pinned'}</span>
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-slate-500">
                        {currentUser.handle} · {post.createdAt}
                      </div>
                    </div>
                  </div>

                  {/* 3-Dots Menu */}
                  <div className="relative">
                    <button
                      type="button"
                      onClick={() =>
                        setOpenMenuId((prev) =>
                          prev === post.id ? null : post.id
                        )
                      }
                      className="w-9 h-9 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center text-slate-500 cursor-pointer"
                    >
                      <MoreVertical className="w-5 h-5" />
                    </button>

                    {openMenuId === post.id && (
                      <div className="absolute end-0 top-10 z-30 w-52 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 shadow-xl py-1.5 text-xs font-semibold">
                        <button
                          type="button"
                          onClick={() => {
                            onTogglePinPost(post.id);
                            setOpenMenuId(null);
                          }}
                          className="w-full px-4 py-2.5 text-start hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2.5 cursor-pointer"
                        >
                          <Pin className="w-4 h-4 text-[#F2A93B]" />
                          <span>
                            {post.isPinned
                              ? isAr
                                ? 'إلغاء تثبيت المنشور'
                                : 'Unpin Post'
                              : isAr
                              ? 'تثبيت في الملف الشخصي'
                              : 'Pin to Profile'}
                          </span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            onCopyPostLink(post.id);
                            setOpenMenuId(null);
                          }}
                          className="w-full px-4 py-2.5 text-start hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2.5 cursor-pointer"
                        >
                          <Link2 className="w-4 h-4 text-[#0E6B63]" />
                          <span>
                            {isAr ? 'نسخ رابط المنشور' : 'Copy Link'}
                          </span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            onToggleBookmark(post.id);
                            setOpenMenuId(null);
                          }}
                          className="w-full px-4 py-2.5 text-start hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2.5 cursor-pointer"
                        >
                          <Bookmark className="w-4 h-4 text-amber-500" />
                          <span>
                            {isSaved
                              ? isAr
                                ? 'إزالة من المحفوظات'
                                : 'Unsave'
                              : isAr
                              ? 'حفظ المنشور'
                              : 'Save Post'}
                          </span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            onSharePost(post);
                            setOpenMenuId(null);
                          }}
                          className="w-full px-4 py-2.5 text-start hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2.5 cursor-pointer"
                        >
                          <Share2 className="w-4 h-4 text-sky-500" />
                          <span>
                            {isAr ? 'مشاركة المنشور' : 'Share Post'}
                          </span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            onDeletePost(post.id);
                            setOpenMenuId(null);
                          }}
                          className="w-full px-4 py-2.5 text-start hover:bg-rose-50 dark:hover:bg-rose-950/40 text-rose-600 flex items-center gap-2.5 cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                          <span>{isAr ? 'حذف المنشور' : 'Delete Post'}</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {post.content && (
                  <p className="text-sm sm:text-base text-slate-800 dark:text-slate-200 whitespace-pre-line">
                    {post.content}
                  </p>
                )}

                {post.imageUrl && (
                  <img
                    src={post.imageUrl}
                    alt="Post"
                    className="w-full max-h-96 object-cover rounded-2xl border border-slate-200 dark:border-slate-800"
                  />
                )}

                {post.videoUrl && post.videoUrl !== 'builtin:video' && (
                  <video
                    src={post.videoUrl}
                    controls
                    className="w-full max-h-96 rounded-2xl bg-black"
                  />
                )}

                {post.audioUrl && (
                  <AudioWavePlayer
                    audioUrl={post.audioUrl}
                    durationLabel={post.audioDuration || '0:20'}
                    title={
                      post.audioTitle ||
                      (isAr ? 'مقطع صوتي' : 'Voice / Audio Clip')
                    }
                  />
                )}

                {post.linkUrl && (
                  <a
                    href={
                      post.linkUrl.startsWith('http')
                        ? post.linkUrl
                        : `https://${post.linkUrl}`
                    }
                    target="_blank"
                    rel="noreferrer"
                    className="block p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 hover:border-[#0E6B63] transition-colors"
                  >
                    <div className="flex items-center justify-between gap-2 text-xs font-bold text-[#0E6B63] dark:text-[#5FD0C4]">
                      <span className="truncate">
                        {post.linkTitle || post.linkUrl}
                      </span>
                      <ExternalLink className="w-4 h-4 shrink-0" />
                    </div>
                  </a>
                )}

                {post.mediaKey && <PostMediaVisual mediaKey={post.mediaKey} />}

                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-600 dark:text-slate-400">
                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => onToggleLike(post.id)}
                      className={`min-h-[38px] px-3 py-1.5 rounded-xl flex items-center gap-1.5 cursor-pointer ${
                        isLiked
                          ? 'text-rose-600 bg-rose-50 dark:bg-rose-950/30 font-bold'
                          : 'hover:bg-slate-100 dark:hover:bg-slate-800'
                      }`}
                    >
                      <Heart
                        className={`w-4 h-4 ${isLiked ? 'fill-current' : ''}`}
                      />
                      <span>{post.likes.length}</span>
                      <span>{isAr ? 'إعجاب' : 'Like'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => onOpenCommentsPage(post)}
                      className="min-h-[38px] px-3 py-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-1.5 cursor-pointer"
                    >
                      <MessageCircle className="w-4 h-4" />
                      <span>{post.comments.length}</span>
                      <span>{isAr ? 'التعليقات' : 'Comments'}</span>
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={() => onTogglePinPost(post.id)}
                    className={`min-h-[38px] px-3 py-1.5 rounded-xl flex items-center gap-1.5 cursor-pointer ${
                      post.isPinned
                        ? 'text-[#F2A93B] bg-amber-50 dark:bg-amber-950/30 font-bold'
                        : 'hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    <Pin className="w-4 h-4" />
                    <span>
                      {post.isPinned
                        ? isAr
                          ? 'مثبت في صفحتي'
                          : 'Pinned'
                        : isAr
                        ? 'تثبيت في صفحتي'
                        : 'Pin'}
                    </span>
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      )}

      {/* Photo Studio Modal for Avatar or Cover */}
      {studioMode && (
        <PhotoStudioModal
          lang={lang}
          mode={studioMode}
          currentImageUrl={
            studioMode === 'avatar'
              ? currentUser.customAvatarUrl
              : currentUser.customCoverUrl
          }
          currentCoverKey={currentUser.coverKey}
          onClose={() => setStudioMode(null)}
          onSavePhoto={(dataUrl, coverKey) => {
            if (studioMode === 'avatar') {
              onUpdateUser({ customAvatarUrl: dataUrl });
            } else {
              onUpdateUser({
                customCoverUrl: dataUrl,
                coverKey: coverKey || currentUser.coverKey,
              });
            }
          }}
        />
      )}
    </div>
  );
};
