import React, { useEffect } from 'react';
import { Sparkles, ArrowLeft, ArrowRight } from 'lucide-react';
import type { Language } from '../types.ts';
import { WanasBrandIcon } from './VisualAssets.tsx';

interface StartupSplashModalProps {
  lang: Language;
  onDismiss: () => void;
}

export const StartupSplashModal: React.FC<StartupSplashModalProps> = ({
  lang,
  onDismiss,
}) => {
  const isAr = lang === 'ar';

  useEffect(() => {
    const timer = window.setTimeout(() => {
      onDismiss();
    }, 2600);
    return () => window.clearTimeout(timer);
  }, [onDismiss]);

  return (
    <div
      onClick={onDismiss}
      className="fixed inset-0 z-50 bg-gradient-to-b from-[#0B3B36] via-[#0F1514] to-[#090D0C] text-white flex flex-col items-center justify-between p-6 sm:p-10 select-none cursor-pointer"
    >
      {/* Top Attribution Above the Logo */}
      <div className="w-full max-w-lg text-center pt-6 sm:pt-10 space-y-2">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 border border-[#F2A93B]/40 backdrop-blur-md text-xs sm:text-sm font-bold text-[#F2A93B] shadow-lg">
          <Sparkles className="w-4 h-4 text-[#F2A93B] shrink-0" />
          <span>تم بناء وبرمجة هذا التطبيق بواسطة</span>
        </div>
        <div
          dir="ltr"
          className="text-base sm:text-xl font-black tracking-wider text-white uppercase drop-shadow-md"
        >
          ABD.ALLAH ZOHAIR OMARA
        </div>
      </div>

      {/* Center Official Logo + English App Name Underneath */}
      <div className="flex flex-col items-center justify-center space-y-5 my-auto">
        <div className="relative">
          <div className="absolute -inset-4 rounded-[2.2rem] bg-gradient-to-tr from-[#0E6B63] to-[#F2A93B] opacity-40 blur-xl animate-pulse" />
          <WanasBrandIcon className="relative w-28 h-28 sm:w-36 sm:h-36 rounded-[2rem] shadow-2xl ring-4 ring-[#F2A93B]/60" />
        </div>

        {/* English Name Below the Logo as requested */}
        <div className="text-center space-y-1.5">
          <h1
            dir="ltr"
            className="text-4xl sm:text-5xl font-black tracking-[0.22em] text-white drop-shadow-lg"
          >
            WANAS
          </h1>
          <p className="text-xs sm:text-sm font-bold text-[#5FD0C4] tracking-wide">
            {isAr
              ? 'منصة ونس للتواصل الاجتماعي والمجالس الصوتية'
              : 'WANAS Social Networking & Live Audio Platform'}
          </p>
        </div>
      </div>

      {/* Bottom Enter Button & Progress Bar */}
      <div className="w-full max-w-xs space-y-4 pb-4 text-center">
        <div className="w-full h-1.5 rounded-full bg-white/15 overflow-hidden">
          <div className="h-full w-full bg-gradient-to-r from-[#0E6B63] via-[#5FD0C4] to-[#F2A93B] animate-pulse" />
        </div>
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onDismiss();
          }}
          className="w-full py-3 px-6 rounded-2xl bg-[#0E6B63] hover:bg-[#0B5650] border border-[#5FD0C4]/30 text-white text-xs sm:text-sm font-extrabold flex items-center justify-center gap-2 shadow-xl cursor-pointer transition-all"
        >
          <span>{isAr ? 'الدخول إلى ونس الآن' : 'Enter WANAS Now'}</span>
          {isAr ? (
            <ArrowLeft className="w-4 h-4 text-[#F2A93B]" />
          ) : (
            <ArrowRight className="w-4 h-4 text-[#F2A93B]" />
          )}
        </button>
      </div>
    </div>
  );
};
