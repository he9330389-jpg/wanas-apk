import React, { useState } from 'react';
import {
  X,
  Send,
  Check,
  Copy,
  Share2,
  UserPlus,
  Download,
  Repeat2,
} from 'lucide-react';
import type { Language, Post, User } from '../types.ts';
import { UserAvatar } from './VisualAssets.tsx';
import { downloadMediaToDevice } from '../utils/mediaUtils.ts';

interface ShareToFriendsModalProps {
  lang: Language;
  post: Post;
  users: User[];
  currentUser: User;
  onClose: () => void;
  onSendPostToUsers: (
    post: Post,
    recipientIds: string[],
    customNote: string
  ) => void;
  onRepost: (post: Post) => void;
  onCopyLink: (postId: string) => void;
  onAddQuickFriend?: (name: string, handle: string) => User;
}

export const ShareToFriendsModal: React.FC<ShareToFriendsModalProps> = ({
  lang,
  post,
  users,
  currentUser,
  onClose,
  onSendPostToUsers,
  onRepost,
  onCopyLink,
  onAddQuickFriend,
}) => {
  const isAr = lang === 'ar';
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [note, setNote] = useState<string>('');
  const [newFriendName, setNewFriendName] = useState<string>('');
  const [newFriendHandle, setNewFriendHandle] = useState<string>('');
  const [showAddFriend, setShowAddFriend] = useState<boolean>(false);

  const otherUsers = users.filter((u) => u.id !== currentUser.id);

  const toggleSelectUser = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const handleSelectAll = () => {
    if (selectedIds.length === otherUsers.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(otherUsers.map((u) => u.id));
    }
  };

  const handleQuickAddFriend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFriendName.trim() || !onAddQuickFriend) return;
    const created = onAddQuickFriend(
      newFriendName.trim(),
      newFriendHandle.trim() || newFriendName.trim()
    );
    setSelectedIds((prev) =>
      prev.includes(created.id) ? prev : [...prev, created.id]
    );
    setNewFriendName('');
    setNewFriendHandle('');
    setShowAddFriend(false);
  };

  const handleSendNow = () => {
    if (selectedIds.length === 0) return;
    onSendPostToUsers(post, selectedIds, note.trim());
    onClose();
  };

  const handleNativeExternalShare = () => {
    const shareUrl = `${window.location.origin}/?post=${post.id}`;
    if (navigator.share) {
      navigator
        .share({
          title: 'WANAS ونس',
          text: post.content,
          url: shareUrl,
        })
        .catch(() => {});
    } else {
      onCopyLink(post.id);
    }
  };

  const hasDownloadableMedia = Boolean(
    post.imageUrl ||
      (post.videoUrl && post.videoUrl !== 'builtin:video') ||
      (post.audioUrl && post.audioUrl !== 'synth:voice')
  );

  const handleDownloadMedia = () => {
    if (post.videoUrl && post.videoUrl !== 'builtin:video') {
      downloadMediaToDevice(post.videoUrl, 'wanas-video');
    } else if (post.imageUrl) {
      downloadMediaToDevice(post.imageUrl, 'wanas-photo');
    } else if (post.audioUrl && post.audioUrl !== 'synth:voice') {
      downloadMediaToDevice(post.audioUrl, 'wanas-audio');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white dark:bg-[#151D1C] border border-slate-200 dark:border-slate-800 rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div>
            <h3 className="text-base sm:text-lg font-extrabold text-[#1F1A12] dark:text-white">
              {isAr
                ? 'مشاركة وإرسال المنشور لأكثر من شخص'
                : 'Share & Send Post to Multiple Friends'}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {isAr
                ? 'اختر الأصدقاء لإرسال المنشور لهم في الرسائل أو أعد نشره في حسابك'
                : 'Select friends to send this post directly or repost to your feed'}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-4 max-h-[80vh] overflow-y-auto">
          {/* Quick Actions Row: Repost, Copy Link, Save Media, External Share */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <button
              type="button"
              onClick={() => {
                onRepost(post);
                onClose();
              }}
              className="p-2.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 text-xs font-extrabold flex flex-col items-center gap-1 cursor-pointer"
            >
              <Repeat2 className="w-4 h-4" />
              <span>{isAr ? 'إعادة نشر' : 'Repost'}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                onCopyLink(post.id);
                onClose();
              }}
              className="p-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-bold flex flex-col items-center gap-1 cursor-pointer"
            >
              <Copy className="w-4 h-4 text-[#0E6B63]" />
              <span>{isAr ? 'نسخ الرابط' : 'Copy Link'}</span>
            </button>

            <button
              type="button"
              onClick={handleNativeExternalShare}
              className="p-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-bold flex flex-col items-center gap-1 cursor-pointer"
            >
              <Share2 className="w-4 h-4 text-sky-500" />
              <span>{isAr ? 'مشاركة خارجية' : 'External Share'}</span>
            </button>

            {hasDownloadableMedia && (
              <button
                type="button"
                onClick={handleDownloadMedia}
                className="p-2.5 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-amber-800 dark:text-[#F2A93B] text-xs font-bold flex flex-col items-center gap-1 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>{isAr ? 'حفظ بالهاتف' : 'Save Media'}</span>
              </button>
            )}
          </div>

          {/* Friends Multi-Select List */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-extrabold text-slate-700 dark:text-slate-300">
                {isAr
                  ? `اختر الأصدقاء للإرسال (${selectedIds.length} محدد):`
                  : `Select Friends (${selectedIds.length} selected):`}
              </span>
              <div className="flex items-center gap-2">
                {otherUsers.length > 0 && (
                  <button
                    type="button"
                    onClick={handleSelectAll}
                    className="text-xs font-bold text-[#0E6B63] dark:text-[#5FD0C4] hover:underline cursor-pointer"
                  >
                    {selectedIds.length === otherUsers.length
                      ? isAr
                        ? 'إلغاء تحديد الكل'
                        : 'Deselect All'
                      : isAr
                      ? 'تحديد الكل'
                      : 'Select All'}
                  </button>
                )}
                {onAddQuickFriend && (
                  <button
                    type="button"
                    onClick={() => setShowAddFriend((p) => !p)}
                    className="px-2.5 py-1 rounded-xl bg-[#0E6B63]/10 text-[#0E6B63] dark:text-[#5FD0C4] text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <UserPlus className="w-3.5 h-3.5" />
                    <span>{isAr ? 'إضافة صديق' : 'Add Friend'}</span>
                  </button>
                )}
              </div>
            </div>

            {showAddFriend && (
              <form
                onSubmit={handleQuickAddFriend}
                className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 grid grid-cols-1 sm:grid-cols-3 gap-2"
              >
                <input
                  type="text"
                  value={newFriendName}
                  onChange={(e) => setNewFriendName(e.target.value)}
                  placeholder={isAr ? 'اسم الصديق' : 'Friend Name'}
                  className="px-3 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                />
                <input
                  type="text"
                  dir="ltr"
                  value={newFriendHandle}
                  onChange={(e) => setNewFriendHandle(e.target.value)}
                  placeholder="@username / phone"
                  className="px-3 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
                />
                <button
                  type="submit"
                  className="px-3 py-2 rounded-xl bg-[#0E6B63] text-white text-xs font-bold cursor-pointer"
                >
                  {isAr ? 'إضافة وتحديد' : 'Add & Select'}
                </button>
              </form>
            )}

            {otherUsers.length === 0 ? (
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900 text-center text-xs text-slate-500">
                {isAr
                  ? 'اضغط على «إضافة صديق» بالأعلى لإضافة أصدقائك وإرسال المنشور إليهم مباشرة.'
                  : 'Tap "Add Friend" above to add friends and send posts directly to them.'}
              </div>
            ) : (
              <div className="max-h-48 overflow-y-auto space-y-1.5 pr-1">
                {otherUsers.map((u) => {
                  const isChecked = selectedIds.includes(u.id);
                  return (
                    <div
                      key={u.id}
                      onClick={() => toggleSelectUser(u.id)}
                      className={`p-2.5 rounded-2xl border flex items-center justify-between cursor-pointer transition-colors ${
                        isChecked
                          ? 'bg-[#0E6B63]/10 border-[#0E6B63] dark:border-[#5FD0C4]'
                          : 'bg-slate-50 dark:bg-slate-900/60 border-slate-200/70 dark:border-slate-800'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <UserAvatar
                          avatarKey={u.avatarKey}
                          customAvatarUrl={u.customAvatarUrl}
                          name={u.name}
                          size="sm"
                        />
                        <div>
                          <div className="text-xs font-bold text-slate-900 dark:text-white">
                            {u.name}
                          </div>
                          <div className="text-[11px] text-slate-500" dir="ltr">
                            {u.handle}
                          </div>
                        </div>
                      </div>

                      <div
                        className={`w-6 h-6 rounded-lg flex items-center justify-center border ${
                          isChecked
                            ? 'bg-[#0E6B63] border-[#0E6B63] text-white'
                            : 'border-slate-300 dark:border-slate-600'
                        }`}
                      >
                        {isChecked && <Check className="w-3.5 h-3.5" />}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Optional Message Note */}
          <input
            type="text"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder={
              isAr
                ? 'أضف رسالة مع المنشور (اختياري)...'
                : 'Add a message with this post (optional)...'
            }
            className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm"
          />

          <button
            type="button"
            disabled={selectedIds.length === 0}
            onClick={handleSendNow}
            className="w-full min-h-[46px] py-3 rounded-xl bg-[#0E6B63] hover:bg-[#0b5650] disabled:opacity-50 text-white font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 cursor-pointer shadow-md"
          >
            <Send className="w-4 h-4 text-[#F2A93B]" />
            <span>
              {isAr
                ? `إرسال المنشور إلى (${selectedIds.length}) الآن`
                : `Send Post to (${selectedIds.length}) Selected`}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
