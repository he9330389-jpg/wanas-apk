import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  Camera,
  FolderOpen,
  RefreshCw,
  Check,
  ZoomIn,
  MoveVertical,
  Trash2,
  Sparkles,
} from 'lucide-react';
import type { Language, CoverKey } from '../types.ts';
import { compressImageSource } from '../utils/mediaUtils.ts';

interface PhotoStudioModalProps {
  lang: Language;
  mode: 'avatar' | 'cover';
  currentImageUrl?: string;
  currentCoverKey?: CoverKey;
  onClose: () => void;
  onSavePhoto: (dataUrl: string | undefined, coverKey?: CoverKey) => void;
}

const COVER_PRESETS: { key: CoverKey; labelAr: string; labelEn: string }[] = [
  { key: 'royal_majlis', labelAr: 'المجلس الملكي', labelEn: 'Royal Majlis' },
  { key: 'teal_horizon', labelAr: 'الأفق الفيروزي', labelEn: 'Teal Horizon' },
  { key: 'cairo_nights', labelAr: 'ليالي القاهرة', labelEn: 'Cairo Nights' },
  { key: 'tech_oasis', labelAr: 'الواحة الرقمية', labelEn: 'Tech Oasis' },
];

export const PhotoStudioModal: React.FC<PhotoStudioModalProps> = ({
  lang,
  mode,
  currentImageUrl,
  currentCoverKey = 'royal_majlis',
  onClose,
  onSavePhoto,
}) => {
  const isAr = lang === 'ar';
  const [rawImageSrc, setRawImageSrc] = useState<string | null>(
    currentImageUrl || null
  );
  const [zoom, setZoom] = useState<number>(1);
  const [offsetY, setOffsetY] = useState<number>(0);
  const [selectedCoverKey, setSelectedCoverKey] =
    useState<CoverKey>(currentCoverKey);
  const [isSaving, setIsSaving] = useState<boolean>(false);

  // Live WebRTC Camera State
  const [isCameraActive, setIsCameraActive] = useState<boolean>(false);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>(
    mode === 'avatar' ? 'user' : 'environment'
  );
  const [cameraError, setCameraError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const nativeCameraInputRef = useRef<HTMLInputElement | null>(null);

  const stopCameraStream = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setIsCameraActive(false);
  };

  useEffect(() => {
    return () => {
      stopCameraStream();
    };
  }, []);

  const startLiveCamera = async (nextFacing: 'user' | 'environment' = facingMode) => {
    setCameraError(null);
    stopCameraStream();
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        // Fallback to native mobile camera file input
        nativeCameraInputRef.current?.click();
        return;
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: nextFacing,
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
        audio: false,
      });
      streamRef.current = stream;
      setIsCameraActive(true);
      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play().catch(() => {});
        }
      }, 60);
    } catch {
      // If browser blocks live stream, trigger native phone camera capture input
      setCameraError(
        isAr
          ? 'تم تحويلك إلى كاميرا الهاتف المباشرة لالتقاط الصورة.'
          : 'Opening native phone camera...'
      );
      nativeCameraInputRef.current?.click();
    }
  };

  const handleFlipCamera = () => {
    const next = facingMode === 'user' ? 'environment' : 'user';
    setFacingMode(next);
    if (isCameraActive) {
      startLiveCamera(next);
    }
  };

  const handleCaptureFromLiveVideo = () => {
    if (!videoRef.current) return;
    const video = videoRef.current;
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 800;
    canvas.height = video.videoHeight || 800;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      if (facingMode === 'user') {
        ctx.translate(canvas.width, 0);
        ctx.scale(-1, 1);
      }
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
      setRawImageSrc(dataUrl);
      setZoom(1);
      setOffsetY(0);
    }
    stopCameraStream();
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setRawImageSrc(reader.result);
        setZoom(1);
        setOffsetY(0);
        stopCameraStream();
      }
    };
    reader.readAsDataURL(file);
  };

  const handleConfirmSave = async () => {
    setIsSaving(true);
    try {
      if (rawImageSrc) {
        const targetW = mode === 'avatar' ? 512 : 1200;
        const targetH = mode === 'avatar' ? 512 : 480;
        const compressed = await compressImageSource(
          rawImageSrc,
          targetW,
          targetH,
          0.86,
          zoom,
          offsetY
        );
        onSavePhoto(compressed, selectedCoverKey);
      } else {
        onSavePhoto(undefined, selectedCoverKey);
      }
      onClose();
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white dark:bg-[#151D1C] border border-slate-200 dark:border-slate-800 rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div>
            <h3 className="text-base sm:text-lg font-extrabold text-[#1F1A12] dark:text-white">
              {mode === 'avatar'
                ? isAr
                  ? 'تغيير الصورة الشخصية للملف الشخصي'
                  : 'Change Profile Picture'
                : isAr
                ? 'تغيير صورة الغلاف (الكاڤر)'
                : 'Change Cover Banner Photo'}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {isAr
                ? 'التقط صورة بكاميرا الهاتف أو اختر صورة من ملفات واستوديو الهاتف'
                : 'Take a photo with your phone camera or choose from device files'}
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              stopCameraStream();
              onClose();
            }}
            className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500 hover:bg-slate-200 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 space-y-4 max-h-[80vh] overflow-y-auto">
          {/* Hidden File & Native Camera Inputs */}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileSelect}
            className="hidden"
          />
          <input
            ref={nativeCameraInputRef}
            type="file"
            accept="image/*"
            capture={mode === 'avatar' ? 'user' : 'environment'}
            onChange={handleFileSelect}
            className="hidden"
          />

          {/* Main Source Buttons: Phone Files vs Phone Camera */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="min-h-[48px] px-4 py-3 rounded-2xl bg-[#0E6B63] hover:bg-[#0b5650] text-white text-xs sm:text-sm font-bold flex items-center justify-center gap-2 shadow-xs cursor-pointer transition-colors"
            >
              <FolderOpen className="w-4 h-4 text-[#F2A93B]" />
              <span>
                {isAr
                  ? 'اختيار من ملفات الهاتف / المعرض'
                  : 'Choose from Phone Files'}
              </span>
            </button>

            <button
              type="button"
              onClick={() => startLiveCamera(facingMode)}
              className="min-h-[48px] px-4 py-3 rounded-2xl bg-[#F2A93B]/15 hover:bg-[#F2A93B]/25 border border-[#F2A93B]/40 text-amber-950 dark:text-[#F2A93B] text-xs sm:text-sm font-bold flex items-center justify-center gap-2 cursor-pointer transition-colors"
            >
              <Camera className="w-4 h-4 text-[#0E6B63] dark:text-[#F2A93B]" />
              <span>
                {isAr
                  ? 'التقاط صورة من كاميرا الهاتف'
                  : 'Take Photo with Camera'}
              </span>
            </button>
          </div>

          {cameraError && (
            <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-xs font-semibold text-amber-800 dark:text-amber-300 flex items-center justify-between gap-2">
              <span>{cameraError}</span>
              <button
                type="button"
                onClick={() => nativeCameraInputRef.current?.click()}
                className="px-3 py-1 rounded-lg bg-[#0E6B63] text-white text-xs font-bold shrink-0 cursor-pointer"
              >
                {isAr ? 'فتح كاميرا الموبايل' : 'Open Camera'}
              </button>
            </div>
          )}

          {/* Live Camera Viewfinder if active */}
          {isCameraActive && (
            <div className="rounded-2xl overflow-hidden bg-black border border-slate-800 relative">
              <video
                ref={videoRef}
                playsInline
                muted
                className={`w-full h-64 object-cover ${
                  facingMode === 'user' ? 'scale-x-[-1]' : ''
                }`}
              />
              <div className="p-3 bg-black/80 flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={handleFlipCamera}
                  className="px-3 py-2 rounded-xl bg-white/15 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>
                    {isAr ? 'تبديل الكاميرا' : 'Flip Camera'}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={handleCaptureFromLiveVideo}
                  className="px-5 py-2 rounded-xl bg-[#F2A93B] text-[#1F1A12] text-xs sm:text-sm font-extrabold flex items-center gap-1.5 cursor-pointer shadow-md"
                >
                  <Camera className="w-4 h-4" />
                  <span>{isAr ? 'التقاط الصورة الآن' : 'Capture Now'}</span>
                </button>

                <button
                  type="button"
                  onClick={stopCameraStream}
                  className="px-3 py-2 rounded-xl bg-rose-600/80 text-white text-xs font-bold cursor-pointer"
                >
                  {isAr ? 'إغلاق' : 'Close'}
                </button>
              </div>
            </div>
          )}

          {/* Image Preview & Framing Area */}
          {!isCameraActive && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs font-bold text-slate-600 dark:text-slate-400">
                <span>
                  {isAr ? 'معاينة وضبط أبعاد الصورة:' : 'Preview & Adjust:'}
                </span>
                {rawImageSrc && (
                  <button
                    type="button"
                    onClick={() => {
                      setRawImageSrc(null);
                      setZoom(1);
                      setOffsetY(0);
                    }}
                    className="text-rose-600 hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>
                      {isAr ? 'إزالة الصورة المختارة' : 'Remove Photo'}
                    </span>
                  </button>
                )}
              </div>

              <div className="rounded-2xl bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 flex flex-col items-center justify-center min-h-[210px]">
                {rawImageSrc ? (
                  mode === 'avatar' ? (
                    <div className="w-40 h-40 rounded-full overflow-hidden ring-4 ring-[#0E6B63] shadow-lg bg-black relative">
                      <img
                        src={rawImageSrc}
                        alt="Avatar preview"
                        style={{
                          transform: `scale(${zoom}) translateY(${offsetY}px)`,
                        }}
                        className="w-full h-full object-cover transition-transform duration-75"
                      />
                    </div>
                  ) : (
                    <div className="w-full h-44 rounded-2xl overflow-hidden ring-2 ring-[#0E6B63] shadow-md bg-black relative">
                      <img
                        src={rawImageSrc}
                        alt="Cover preview"
                        style={{
                          transform: `scale(${zoom}) translateY(${offsetY}px)`,
                        }}
                        className="w-full h-full object-cover transition-transform duration-75"
                      />
                    </div>
                  )
                ) : (
                  <div className="text-center space-y-2 py-4">
                    <Sparkles className="w-8 h-8 text-[#0E6B63] dark:text-[#5FD0C4] mx-auto" />
                    <p className="text-xs font-bold text-slate-600 dark:text-slate-300">
                      {mode === 'avatar'
                        ? isAr
                          ? 'اختر صورة من ملفات الهاتف أو التقط صورة بالكاميرا لتعيينها كصورتك الشخصية'
                          : 'Choose a file or take a photo to set your profile picture'
                        : isAr
                        ? 'اختر صورة غلاف من ملفات الهاتف أو اختر أحد الأغلفة الرسمية بالأسفل'
                        : 'Choose a cover image from phone files or select a preset below'}
                    </p>
                  </div>
                )}
              </div>

              {/* Zoom & Vertical Offset Sliders when a custom photo is loaded */}
              {rawImageSrc && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-800">
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-600 dark:text-slate-300 flex items-center gap-1.5">
                      <ZoomIn className="w-3.5 h-3.5 text-[#0E6B63]" />
                      <span>
                        {isAr ? 'تكبير / تصغير الصورة' : 'Zoom'} (
                        {Math.round(zoom * 100)}%)
                      </span>
                    </label>
                    <input
                      type="range"
                      min="1"
                      max="2.2"
                      step="0.05"
                      value={zoom}
                      onChange={(e) => setZoom( parseFloat(e.target.value) )}
                      className="w-full accent-[#0E6B63]"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-600 dark:text-slate-300 flex items-center gap-1.5">
                      <MoveVertical className="w-3.5 h-3.5 text-[#F2A93B]" />
                      <span>
                        {isAr ? 'موضع الصورة عمودياً' : 'Vertical Position'}
                      </span>
                    </label>
                    <input
                      type="range"
                      min="-80"
                      max="80"
                      step="2"
                      value={offsetY}
                      onChange={(e) => setOffsetY(parseInt(e.target.value, 10))}
                      className="w-full accent-[#0E6B63]"
                    />
                  </div>
                </div>
              )}

              {/* Cover Presets if in cover mode */}
              {mode === 'cover' && (
                <div className="space-y-2 pt-1">
                  <span className="block text-xs font-bold text-slate-600 dark:text-slate-300">
                    {isAr
                      ? 'أو اختر غلافاً فنياً جاهزاً من هوية ونس:'
                      : 'Or select a built-in WANAS cover theme:'}
                  </span>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {COVER_PRESETS.map((preset) => (
                      <button
                        key={preset.key}
                        type="button"
                        onClick={() => {
                          setRawImageSrc(null);
                          setSelectedCoverKey(preset.key);
                        }}
                        className={`py-2 px-2.5 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                          !rawImageSrc && selectedCoverKey === preset.key
                            ? 'bg-[#0E6B63] text-white border-[#0E6B63]'
                            : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                        }`}
                      >
                        {isAr ? preset.labelAr : preset.labelEn}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="px-5 py-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-end gap-2 bg-slate-50/60 dark:bg-slate-900/50">
          <button
            type="button"
            onClick={() => {
              stopCameraStream();
              onClose();
            }}
            className="min-h-[42px] px-4 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            {isAr ? 'إلغاء' : 'Cancel'}
          </button>

          <button
            type="button"
            disabled={isSaving}
            onClick={handleConfirmSave}
            className="min-h-[42px] px-6 py-2 rounded-xl bg-[#0E6B63] hover:bg-[#0b5650] disabled:opacity-50 text-white text-xs sm:text-sm font-extrabold flex items-center gap-2 shadow-sm cursor-pointer"
          >
            <Check className="w-4 h-4 text-[#F2A93B]" />
            <span>
              {isSaving
                ? isAr
                  ? 'جاري الحفظ...'
                  : 'Saving...'
                : mode === 'avatar'
                ? isAr
                  ? 'اعتماد الصورة الشخصية'
                  : 'Save Profile Photo'
                : isAr
                ? 'اعتماد صورة الغلاف'
                : 'Save Cover Photo'}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
