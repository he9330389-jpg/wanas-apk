import React, { useState } from 'react';
import {
  Lock,
  Bell,
  User as UserIcon,
  Moon,
  Sun,
  Globe,
  LogOut,
  Check,
  EyeOff,
  Mic,
  UserX,
  Plus,
  Trash2,
  Camera,
  FolderOpen,
  RefreshCw,
  Download,
  Sparkles,
  CheckCircle2,
  ExternalLink,
} from 'lucide-react';
import type { Language, User, UserSettings } from '../types.ts';
import { DEFAULT_USER_SETTINGS } from '../defaultData.ts';
import { UserAvatar, CoverBannerVisual } from './VisualAssets.tsx';
import { PhotoStudioModal } from './PhotoStudioModal.tsx';
import { readFileAsCompressedDataUrl, getApiUrl } from '../utils/mediaUtils.ts';

interface SettingsViewProps {
  lang: Language;
  darkMode: boolean;
  currentUser: User;
  onToggleDarkMode: (dark: boolean) => void;
  onToggleLang: () => void;
  onUpdateUser: (updated: Partial<User>) => void;
  onLogout: () => void;
  onShowToast: (msg: string) => void;
}

const APP_CURRENT_VERSION = '3.3.0';
const EXTERNAL_APK_UPDATE_URL =
  'https://ais-dev-ocrkpzsio7kgfcpnhgkfbd-896405915761.europe-west2.run.app/WANAS-v3.2.0-official.apk';

export const SettingsView: React.FC<SettingsViewProps> = ({
  lang,
  darkMode,
  currentUser,
  onToggleDarkMode,
  onToggleLang,
  onUpdateUser,
  onLogout,
  onShowToast,
}) => {
  const isAr = lang === 'ar';
  const settings: UserSettings = {
    ...DEFAULT_USER_SETTINGS,
    ...(currentUser.settings || {}),
  };

  const [emailDraft, setEmailDraft] = useState(currentUser.email || '');
  const [phoneDraft, setPhoneDraft] = useState(currentUser.phone || '');
  const [newPasswordDraft, setNewPasswordDraft] = useState('');
  const [blockHandleInput, setBlockHandleInput] = useState('');

  // Photo Studio Modal ('avatar' | 'cover' | null)
  const [studioMode, setStudioMode] = useState<'avatar' | 'cover' | null>(null);

  // In-App & External Update Center State
  const [updateStatus, setUpdateStatus] = useState<
    'idle' | 'checking' | 'downloading' | 'up_to_date'
  >('idle');
  const [updateProgress, setUpdateProgress] = useState<number>(0);
  const [installedVersion, setInstalledVersion] = useState<string>(() => {
    try {
      return localStorage.getItem('wanas_installed_version') || APP_CURRENT_VERSION;
    } catch {
      return APP_CURRENT_VERSION;
    }
  });
  const [autoUpdateEnabled, setAutoUpdateEnabled] = useState<boolean>(() => {
    try {
      return localStorage.getItem('wanas_auto_update') !== 'false';
    } catch {
      return true;
    }
  });
  const [lastCheckedTime, setLastCheckedTime] = useState<string>(
    isAr ? 'الآن' : 'Just now'
  );

  const updateSetting = <K extends keyof UserSettings>(
    key: K,
    val: UserSettings[K]
  ) => {
    const nextSettings: UserSettings = {
      ...settings,
      [key]: val,
    };
    onUpdateUser({ settings: nextSettings });
    onShowToast(
      isAr ? 'تم حفظ إعدادات الخصوصية والحساب ✓' : 'Settings updated ✓'
    );
  };

  const handleQuickFileChange = async (
    e: React.ChangeEvent<HTMLInputElement>,
    kind: 'avatar' | 'cover'
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressed = await readFileAsCompressedDataUrl(file, kind);
      if (kind === 'avatar') {
        onUpdateUser({ customAvatarUrl: compressed });
      } else {
        onUpdateUser({ customCoverUrl: compressed });
      }
    } catch {
      // ignore
    }
  };

  // In-App Update Handler (تحديث البرنامج من داخل التطبيق)
  const handleRunInAppUpdate = async () => {
    if (updateStatus === 'checking' || updateStatus === 'downloading') return;
    setUpdateStatus('checking');
    setUpdateProgress(15);

    try {
      // Check server version if online
      const res = await fetch(getApiUrl('/api/app-version')).catch(() => null);
      let targetVer = APP_CURRENT_VERSION;
      if (res && res.ok) {
        const data = await res.json();
        if (data?.version) targetVer = data.version;
      }

      setUpdateStatus('downloading');
      for (const step of [35, 60, 85, 100]) {
        await new Promise((r) => setTimeout(r, 220));
        setUpdateProgress(step);
      }

      // Clear outdated Service Worker / Cache storage if present so fresh assets load
      if ('caches' in window) {
        try {
          const keys = await caches.keys();
          await Promise.all(keys.map((k) => caches.delete(k)));
        } catch {
          // ignore
        }
      }
      if ('serviceWorker' in navigator) {
        try {
          const regs = await navigator.serviceWorker.getRegistrations();
          for (const reg of regs) {
            await reg.update();
          }
        } catch {
          // ignore
        }
      }

      setInstalledVersion(targetVer);
      try {
        localStorage.setItem('wanas_installed_version', targetVer);
      } catch {
        // ignore
      }
      setLastCheckedTime(
        new Date().toLocaleTimeString(isAr ? 'ar-EG' : 'en-US', {
          hour: '2-digit',
          minute: '2-digit',
        })
      );
      setUpdateStatus('up_to_date');
      onShowToast(
        isAr
          ? `تم تحديث برنامج ونس من داخل التطبيق إلى النسخة v${targetVer} بنجاح ✓`
          : `WANAS updated in-app to v${targetVer} ✓`
      );
    } catch {
      setUpdateStatus('up_to_date');
    }
  };

  const handleToggleAutoUpdate = () => {
    const next = !autoUpdateEnabled;
    setAutoUpdateEnabled(next);
    try {
      localStorage.setItem('wanas_auto_update', String(next));
    } catch {
      // ignore
    }
    onShowToast(
      next
        ? isAr
          ? 'تم تفعيل التحديث التلقائي للبرنامج ✓'
          : 'Auto-update enabled ✓'
        : isAr
        ? 'تم إيقاف التحديث التلقائي'
        : 'Auto-update disabled'
    );
  };

  const handleSaveAccountCredentials = (e: React.FormEvent) => {
    e.preventDefault();
    const patch: Partial<User> = {
      email: emailDraft.trim() || undefined,
      phone: phoneDraft.trim() || undefined,
    };
    if (newPasswordDraft.trim().length >= 6) {
      patch.password = newPasswordDraft.trim();
      setNewPasswordDraft('');
    }
    onUpdateUser(patch);
    onShowToast(
      isAr
        ? 'تم تحديث بيانات الحساب وكلمة المرور بنجاح ✓'
        : 'Account credentials saved ✓'
    );
  };

  const handleAddBlocked = (e: React.FormEvent) => {
    e.preventDefault();
    const h = blockHandleInput.trim();
    if (!h) return;
    const formatted = h.startsWith('@') ? h : `@${h}`;
    if (!settings.blockedHandles.includes(formatted)) {
      updateSetting('blockedHandles', [...settings.blockedHandles, formatted]);
    }
    setBlockHandleInput('');
  };

  const handleRemoveBlocked = (handle: string) => {
    updateSetting(
      'blockedHandles',
      settings.blockedHandles.filter((x) => x !== handle)
    );
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6 pb-8">
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 flex items-center justify-between">
        <div>
          <h1 className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white">
            {isAr
              ? 'إعدادات الحساب، الصور، وتحديث البرنامج'
              : 'Account, Photos & App Update Settings'}
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            {isAr
              ? 'تغيير الصورة الشخصية والغلاف، تحديث البرنامج، التحكم في الخصوصية (البرايفت)، والأمان'
              : 'Change profile & cover photos, update the app, and manage privacy & security'}
          </p>
        </div>
      </div>

      {/* 1. Profile Picture & Cover Photo Studio Card (تغيير الصورة الشخصية وصورة الغلاف) */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden space-y-4">
        <CoverBannerVisual
          coverKey={currentUser.coverKey || 'royal_majlis'}
          customCoverUrl={currentUser.customCoverUrl}
          heightClass="h-36 sm:h-44"
        >
          <div className="absolute top-3 end-3 flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => setStudioMode('cover')}
              className="px-3 py-1.5 rounded-xl bg-black/65 hover:bg-black/80 text-white text-xs font-bold flex items-center gap-1.5 border border-white/20 cursor-pointer"
            >
              <Camera className="w-3.5 h-3.5 text-[#F2A93B]" />
              <span>
                {isAr
                  ? 'تغيير صورة الغلاف (كاميرا / ملفات)'
                  : 'Change Cover (Camera / Files)'}
              </span>
            </button>
          </div>
        </CoverBannerVisual>

        <div className="px-5 pb-5">
          <div className="flex flex-wrap items-end justify-between gap-4 -mt-10 relative z-10">
            <div className="flex items-end gap-3">
              <div
                onClick={() => setStudioMode('avatar')}
                className="ring-4 ring-white dark:ring-slate-900 rounded-full cursor-pointer relative"
              >
                <UserAvatar
                  avatarKey={currentUser.avatarKey}
                  customAvatarUrl={currentUser.customAvatarUrl}
                  name={currentUser.name}
                  size="xl"
                />
                <span className="absolute bottom-0 end-0 w-8 h-8 rounded-full bg-[#0E6B63] text-white flex items-center justify-center border-2 border-white dark:border-slate-900">
                  <Camera className="w-4 h-4 text-[#F2A93B]" />
                </span>
              </div>
              <div className="pb-1">
                <div className="font-extrabold text-base text-slate-900 dark:text-white">
                  {currentUser.name}
                </div>
                <div className="text-xs text-slate-500">{currentUser.handle}</div>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => setStudioMode('avatar')}
                className="min-h-[40px] px-3.5 py-2 rounded-xl bg-[#0E6B63] hover:bg-[#0b5650] text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <Camera className="w-4 h-4 text-[#F2A93B]" />
                <span>
                  {isAr
                    ? 'تغيير الصورة الشخصية (كاميرا / استوديو)'
                    : 'Change Profile Picture'}
                </span>
              </button>

              <label className="min-h-[40px] px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer">
                <FolderOpen className="w-4 h-4 text-[#0E6B63] dark:text-[#5FD0C4]" />
                <span>
                  {isAr ? 'صورة شخصية من الملفات' : 'Avatar from Files'}
                </span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleQuickFileChange(e, 'avatar')}
                  className="hidden"
                />
              </label>

              <label className="min-h-[40px] px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer">
                <FolderOpen className="w-4 h-4 text-[#F2A93B]" />
                <span>{isAr ? 'غلاف من الملفات' : 'Cover from Files'}</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleQuickFileChange(e, 'cover')}
                  className="hidden"
                />
              </label>
            </div>
          </div>
        </div>
      </div>

      {/* 2. App Update Center (ميزة تحديث البرنامج من داخل التطبيق أو من خارج التطبيق) */}
      <div className="bg-white dark:bg-slate-900 border-2 border-[#0E6B63]/30 dark:border-[#5FD0C4]/30 rounded-2xl p-5 space-y-4 shadow-xs">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2.5 text-sm font-extrabold text-[#0E6B63] dark:text-[#5FD0C4]">
            <Sparkles className="w-5 h-5 text-[#F2A93B]" />
            <h2>
              {isAr
                ? 'مركز تحديث البرنامج (تحديث داخلي أو خارجي APK)'
                : 'Application Update Center (In-App & External APK)'}
            </h2>
          </div>
          <span className="px-3 py-1 rounded-full bg-[#0E6B63]/10 dark:bg-[#5FD0C4]/15 text-[#0E6B63] dark:text-[#5FD0C4] text-xs font-extrabold font-mono">
            v{installedVersion} Official
          </span>
        </div>

        <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
          {isAr
            ? 'يمكنك فحص وتحديث البرنامج مباشرة من داخل التطبيق لمزامنة أحدث المميزات فوراً، أو تحميل وتثبيت أحدث حزمة APK من خارج التطبيق على هاتفك.'
            : 'Check and apply updates directly inside the app, or download the latest standalone APK package externally.'}
        </p>

        {/* Update Status / Progress Box */}
        <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200/80 dark:border-slate-700 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-2 font-bold text-slate-800 dark:text-slate-200">
              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
              <span>
                {updateStatus === 'checking'
                  ? isAr
                    ? 'جاري الاتصال بخادم التحديثات وفحص النسخة الجديدة...'
                    : 'Checking for new updates...'
                  : updateStatus === 'downloading'
                  ? isAr
                    ? `جاري تنزيل وتطبيق التحديث الداخلي... (${updateProgress}%)`
                    : `Downloading & applying update... (${updateProgress}%)`
                  : updateStatus === 'up_to_date'
                  ? isAr
                    ? `البرنامج محدّث إلى آخر إصدار رسمي (v${installedVersion})`
                    : `App is up to date (v${installedVersion})`
                  : isAr
                  ? `الإصدار الحالي المثبت: v${installedVersion} · آخر فحص: ${lastCheckedTime}`
                  : `Installed version: v${installedVersion} · Last checked: ${lastCheckedTime}`}
              </span>
            </div>
            <span className="text-[11px] text-slate-500 font-mono">
              Build 2026.310
            </span>
          </div>

          {(updateStatus === 'checking' || updateStatus === 'downloading') && (
            <div className="w-full h-2.5 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
              <div
                style={{ width: `${updateProgress}%` }}
                className="h-full bg-gradient-to-r from-[#0E6B63] to-[#F2A93B] transition-all duration-200"
              />
            </div>
          )}

          {/* Two Update Buttons: In-App Update & External APK Update */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            <button
              type="button"
              onClick={handleRunInAppUpdate}
              disabled={
                updateStatus === 'checking' || updateStatus === 'downloading'
              }
              className="min-h-[46px] px-4 py-2.5 rounded-xl bg-[#0E6B63] hover:bg-[#0b5650] disabled:opacity-60 text-white text-xs sm:text-sm font-extrabold flex items-center justify-center gap-2 shadow-sm cursor-pointer transition-colors"
            >
              <RefreshCw
                className={`w-4 h-4 text-[#F2A93B] ${
                  updateStatus === 'checking' || updateStatus === 'downloading'
                    ? 'animate-spin'
                    : ''
                }`}
              />
              <span>
                {isAr
                  ? 'تحديث البرنامج من داخل التطبيق'
                  : 'Update Inside App Now'}
              </span>
            </button>

            <a
              href={EXTERNAL_APK_UPDATE_URL}
              download="WANAS-v3.2.0-official.apk"
              target="_blank"
              rel="noopener noreferrer"
              className="min-h-[46px] px-4 py-2.5 rounded-xl bg-[#F2A93B]/15 hover:bg-[#F2A93B]/25 border border-[#F2A93B]/50 text-amber-950 dark:text-[#F2A93B] text-xs sm:text-sm font-extrabold flex items-center justify-center gap-2 cursor-pointer transition-colors"
            >
              <Download className="w-4 h-4 text-[#0E6B63] dark:text-[#F2A93B]" />
              <span>
                {isAr
                  ? 'تحديث من خارج التطبيق (تحميل APK)'
                  : 'External Update (Download APK)'}
              </span>
              <ExternalLink className="w-3.5 h-3.5 opacity-75" />
            </a>
          </div>
        </div>

        {/* Auto-Update Toggle */}
        <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/70 dark:border-slate-800 flex items-center justify-between gap-4">
          <div>
            <div className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
              {isAr
                ? 'التحديث التلقائي للبرنامج عند توفر نسخة جديدة'
                : 'Automatic App Updates'}
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              {isAr
                ? 'تنزيل التحديثات والميزات الجديدة تلقائياً فور صدورها دون فقدان بيانات حسابك'
                : 'Automatically download new features and fixes as soon as they are released'}
            </p>
          </div>
          <button
            type="button"
            onClick={handleToggleAutoUpdate}
            className={`w-14 h-8 rounded-full transition-colors p-1 cursor-pointer shrink-0 ${
              autoUpdateEnabled
                ? 'bg-[#0E6B63]'
                : 'bg-slate-300 dark:bg-slate-700'
            }`}
          >
            <div
              className={`w-6 h-6 rounded-full bg-white shadow-xs transition-transform ${
                autoUpdateEnabled
                  ? isAr
                    ? '-translate-x-6'
                    : 'translate-x-6'
                  : 'translate-x-0'
              }`}
            />
          </button>
        </div>
      </div>

      {/* 3. Privacy & Private Account (إعدادات الخصوصية والبرايفت) */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
        <div className="flex items-center gap-2.5 text-sm font-extrabold text-[#0E6B63] dark:text-[#5FD0C4]">
          <Lock className="w-4 h-4 text-[#F2A93B]" />
          <h2>
            {isAr
              ? 'إعدادات الخصوصية والحساب الخاص (البرايفت)'
              : 'Privacy & Private Account'}
          </h2>
        </div>

        {/* Private Account Toggle */}
        <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 flex items-center justify-between gap-4">
          <div>
            <div className="text-sm font-bold text-slate-900 dark:text-white">
              {isAr ? 'حساب خاص (Private Account / برايفت)' : 'Private Account'}
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              {isAr
                ? 'عند التفعيل، لن يتمكن سوى متابعيك الموافق عليهم من رؤية منشوراتك، مقاطعك، والستوري الخاص بك.'
                : 'When enabled, only approved followers can see your posts, videos, and stories.'}
            </p>
          </div>
          <button
            type="button"
            onClick={() =>
              updateSetting('isPrivateAccount', !settings.isPrivateAccount)
            }
            className={`w-14 h-8 rounded-full transition-colors p-1 cursor-pointer shrink-0 ${
              settings.isPrivateAccount
                ? 'bg-[#0E6B63]'
                : 'bg-slate-300 dark:bg-slate-700'
            }`}
          >
            <div
              className={`w-6 h-6 rounded-full bg-white shadow-xs transition-transform ${
                settings.isPrivateAccount
                  ? isAr
                    ? '-translate-x-6'
                    : 'translate-x-6'
                  : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        {/* Online & Activity Status Toggle ("إلغاء أو تفعيل حالة الظهور وحالة النشاط") */}
        <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <EyeOff className="w-4 h-4 text-[#0E6B63] dark:text-[#5FD0C4]" />
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-slate-900 dark:text-white">
                  {isAr
                    ? 'حالة الظهور وحالة النشاط (نشط الآن / نشط منذ...)'
                    : 'Online & Activity Status'}
                </span>
                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold ${
                    settings.showOnlineStatus
                      ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                      : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {settings.showOnlineStatus
                    ? isAr
                      ? 'نشط الآن 🟢'
                      : 'Active Now 🟢'
                    : isAr
                    ? 'مخفي ⚫'
                    : 'Hidden ⚫'}
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                {isAr
                  ? 'عند الإيقاف، لن يظهر لأي شخص أنك نشط الآن أو متى كنت نشطاً آخر مرة.'
                  : 'When disabled, nobody can see when you are online or last active.'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => {
              const nextVal = !settings.showOnlineStatus;
              const nextSettings: UserSettings = {
                ...settings,
                showOnlineStatus: nextVal,
              };
              onUpdateUser({
                isOnline: nextVal,
                lastActiveAtMs: Date.now(),
                settings: nextSettings,
              });
              onShowToast(
                nextVal
                  ? isAr
                    ? 'تم تفعيل حالة الظهور وحالة النشاط (نشط الآن) ✓'
                    : 'Activity status visible ✓'
                  : isAr
                  ? 'تم إخفاء حالة الظهور وحالة النشاط عن الجميع ✓'
                  : 'Activity status hidden ✓'
              );
            }}
            className={`w-14 h-8 rounded-full transition-colors p-1 cursor-pointer shrink-0 ${
              settings.showOnlineStatus
                ? 'bg-[#0E6B63]'
                : 'bg-slate-300 dark:bg-slate-700'
            }`}
          >
            <div
              className={`w-6 h-6 rounded-full bg-white shadow-xs transition-transform ${
                settings.showOnlineStatus
                  ? isAr
                    ? '-translate-x-6'
                    : 'translate-x-6'
                  : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        {/* Official Verification Badge Toggle */}
        <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 flex items-center justify-between gap-4">
          <div>
            <div className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <span>
                {isAr
                  ? 'شارة التوثيق الرسمية للحساب (✓)'
                  : 'Official Verification Badge (✓)'}
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              {isAr
                ? 'إظهار علامة التوثيق الرسمية بجانب اسمك في المنشورات، التعليقات، والملف الشخصي.'
                : 'Display the official verification badge next to your name across WANAS.'}
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              onUpdateUser({ isVerified: !currentUser.isVerified });
            }}
            className={`w-14 h-8 rounded-full transition-colors p-1 cursor-pointer shrink-0 ${
              currentUser.isVerified
                ? 'bg-[#0E6B63]'
                : 'bg-slate-300 dark:bg-slate-700'
            }`}
          >
            <div
              className={`w-6 h-6 rounded-full bg-white shadow-xs transition-transform ${
                currentUser.isVerified
                  ? isAr
                    ? '-translate-x-6'
                    : 'translate-x-6'
                  : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        {/* Voice Comments Permission Toggle */}
        <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Mic className="w-4 h-4 text-[#F2A93B]" />
            <div>
              <div className="text-sm font-bold text-slate-900 dark:text-white">
                {isAr
                  ? 'السماح بالتعليقات الصوتية على منشوراتي'
                  : 'Allow Voice Comments on My Posts'}
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {isAr
                  ? 'تمكين المتابعين من تسجيل تعليقات صوتية على منشوراتك ومقاطعك'
                  : 'Allow users to leave voice comments on your posts'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() =>
              updateSetting('allowVoiceComments', !settings.allowVoiceComments)
            }
            className={`w-14 h-8 rounded-full transition-colors p-1 cursor-pointer shrink-0 ${
              settings.allowVoiceComments
                ? 'bg-[#0E6B63]'
                : 'bg-slate-300 dark:bg-slate-700'
            }`}
          >
            <div
              className={`w-6 h-6 rounded-full bg-white shadow-xs transition-transform ${
                settings.allowVoiceComments
                  ? isAr
                    ? '-translate-x-6'
                    : 'translate-x-6'
                  : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        {/* Direct Messages Lock Toggle ("من لا يريد أن أي شخص يرسل له رسائل") */}
        <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Lock className="w-4 h-4 text-rose-500" />
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-slate-900 dark:text-white">
                  {isAr
                    ? 'إغلاق استقبال الرسائل الخاصة (منع أي شخص من مراسلتي)'
                    : 'Disable Incoming Direct Messages'}
                </span>
                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold ${
                    settings.whoCanMessage === 'nobody'
                      ? 'bg-rose-500/15 text-rose-600 dark:text-rose-400'
                      : 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                  }`}
                >
                  {settings.whoCanMessage === 'nobody'
                    ? isAr
                      ? 'الرسائل مغلقة 🔒'
                      : 'Locked 🔒'
                    : isAr
                    ? 'الرسائل مفعلة ✓'
                    : 'Open ✓'}
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                {isAr
                  ? 'عند تفعيل هذا الخيار، لن يتمكن أي شخص من إرسال رسائل خاصة إلى حسابك.'
                  : 'When enabled, nobody will be able to send direct messages to your account.'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() =>
              updateSetting(
                'whoCanMessage',
                settings.whoCanMessage === 'nobody' ? 'everyone' : 'nobody'
              )
            }
            className={`w-14 h-8 rounded-full transition-colors p-1 cursor-pointer shrink-0 ${
              settings.whoCanMessage === 'nobody'
                ? 'bg-rose-600'
                : 'bg-slate-300 dark:bg-slate-700'
            }`}
          >
            <div
              className={`w-6 h-6 rounded-full bg-white shadow-xs transition-transform ${
                settings.whoCanMessage === 'nobody'
                  ? isAr
                    ? '-translate-x-6'
                    : 'translate-x-6'
                  : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        {/* Who can comment & Who can message */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 space-y-2">
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
              {isAr ? 'من يمكنه التعليق على منشوراتي:' : 'Who can comment:'}
            </label>
            <select
              value={settings.whoCanComment}
              onChange={(e) =>
                updateSetting(
                  'whoCanComment',
                  e.target.value as UserSettings['whoCanComment']
                )
              }
              className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm font-semibold"
            >
              <option value="everyone">{isAr ? 'الجميع' : 'Everyone'}</option>
              <option value="followers">
                {isAr ? 'الأصدقاء والمتابعون فقط' : 'Friends & Followers Only'}
              </option>
              <option value="nobody">{isAr ? 'لا أحد (إيقاف)' : 'Nobody'}</option>
            </select>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-800 space-y-2">
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
              {isAr ? 'من يمكنه مراسلتي في الرسائل الخاصة:' : 'Who can message me:'}
            </label>
            <select
              value={settings.whoCanMessage}
              onChange={(e) =>
                updateSetting(
                  'whoCanMessage',
                  e.target.value as UserSettings['whoCanMessage']
                )
              }
              className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm font-semibold"
            >
              <option value="everyone">{isAr ? 'الجميع' : 'Everyone'}</option>
              <option value="followers">
                {isAr ? 'الأصدقاء والمتابعون فقط' : 'Friends & Followers Only'}
              </option>
              <option value="nobody">
                {isAr
                  ? 'لا أحد (إغلاق استقبال الرسائل 🔒)'
                  : 'Nobody (Block DMs 🔒)'}
              </option>
            </select>
          </div>
        </div>
      </div>

      {/* 4. Account Credentials (إعدادات بيانات الحساب وكلمة المرور) */}
      <form
        onSubmit={handleSaveAccountCredentials}
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4"
      >
        <div className="flex items-center gap-2.5 text-sm font-extrabold text-[#0E6B63] dark:text-[#5FD0C4]">
          <UserIcon className="w-4 h-4 text-[#F2A93B]" />
          <h2>
            {isAr
              ? 'إعدادات الحساب (البريد الإلكتروني، الهاتف، وكلمة المرور)'
              : 'Account Credentials'}
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              {isAr ? 'البريد الإلكتروني المرتبط بالحساب' : 'Email Address'}
            </label>
            <input
              type="email"
              dir="ltr"
              value={emailDraft}
              onChange={(e) => setEmailDraft(e.target.value)}
              placeholder="name@example.com"
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              {isAr ? 'رقم الهاتف المرتبط بالحساب' : 'Phone Number'}
            </label>
            <input
              type="tel"
              dir="ltr"
              value={phoneDraft}
              onChange={(e) => setPhoneDraft(e.target.value)}
              placeholder="+2010..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
            {isAr ? 'تغيير كلمة المرور (اختياري)' : 'Change Password (Optional)'}
          </label>
          <input
            type="password"
            value={newPasswordDraft}
            onChange={(e) => setNewPasswordDraft(e.target.value)}
            placeholder={
              isAr
                ? 'أدخل كلمة المرور الجديدة لتحديثها...'
                : 'Enter new password to update...'
            }
            className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm"
          />
        </div>

        <button
          type="submit"
          className="px-5 py-2.5 rounded-xl bg-[#0E6B63] hover:bg-[#0b5650] text-white text-xs sm:text-sm font-bold flex items-center gap-2 cursor-pointer"
        >
          <Check className="w-4 h-4 text-[#F2A93B]" />
          <span>{isAr ? 'حفظ بيانات الحساب' : 'Save Account Credentials'}</span>
        </button>
      </form>

      {/* 5. Blocked Users Management (الحسابات المحظورة) */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
        <div className="flex items-center gap-2.5 text-sm font-extrabold text-[#0E6B63] dark:text-[#5FD0C4]">
          <UserX className="w-4 h-4 text-rose-500" />
          <h2>{isAr ? 'قائمة الحظر (الحسابات المحظورة)' : 'Blocked Accounts'}</h2>
        </div>

        <form onSubmit={handleAddBlocked} className="flex gap-2">
          <input
            type="text"
            dir="ltr"
            value={blockHandleInput}
            onChange={(e) => setBlockHandleInput(e.target.value)}
            placeholder="@username"
            className="flex-1 px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm"
          />
          <button
            type="submit"
            className="px-4 py-2 rounded-xl bg-rose-600 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{isAr ? 'حظر حساب' : 'Block'}</span>
          </button>
        </form>

        {settings.blockedHandles.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {settings.blockedHandles.map((h) => (
              <div
                key={h}
                className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold flex items-center gap-2"
              >
                <span dir="ltr">{h}</span>
                <button
                  type="button"
                  onClick={() => handleRemoveBlocked(h)}
                  className="text-rose-500 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 6. Notifications & Appearance (الإشعارات والمظهر) */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
        <div className="flex items-center gap-2.5 text-sm font-extrabold text-[#0E6B63] dark:text-[#5FD0C4]">
          <Bell className="w-4 h-4 text-[#F2A93B]" />
          <h2>
            {isAr ? 'المظهر، اللغة، والإشعارات' : 'Appearance, Language & Alerts'}
          </h2>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60">
          <span className="text-sm font-bold">
            {isAr ? 'وضع الإضاءة (نهاري / ليلي):' : 'Theme Mode:'}
          </span>
          <div className="inline-flex items-center p-1 rounded-xl bg-slate-200/70 dark:bg-slate-900">
            <button
              type="button"
              onClick={() => onToggleDarkMode(false)}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer ${
                !darkMode ? 'bg-white text-[#F2A93B] shadow-xs' : 'text-slate-500'
              }`}
            >
              <Sun className="w-4 h-4" />
              <span>{isAr ? 'وضع نهاري' : 'Light'}</span>
            </button>
            <button
              type="button"
              onClick={() => onToggleDarkMode(true)}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer ${
                darkMode
                  ? 'bg-[#0F1514] text-[#5FD0C4] shadow-xs'
                  : 'text-slate-500'
              }`}
            >
              <Moon className="w-4 h-4" />
              <span>{isAr ? 'وضع ليلي' : 'Dark'}</span>
            </button>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60">
          <span className="text-sm font-bold">
            {isAr ? 'لغة البرنامج:' : 'Application Language:'}
          </span>
          <button
            type="button"
            onClick={onToggleLang}
            className="px-4 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold flex items-center gap-2 cursor-pointer"
          >
            <Globe className="w-4 h-4 text-[#0E6B63]" />
            <span>{isAr ? 'التبديل إلى English' : 'Switch to العربية'}</span>
          </button>
        </div>
      </div>

      {/* 7. Logout Button */}
      <div className="bg-white dark:bg-slate-900 border border-rose-200 dark:border-rose-900/50 rounded-2xl p-5 flex items-center justify-between">
        <div>
          <div className="text-sm font-bold text-rose-600 dark:text-rose-400">
            {isAr ? 'تسجيل الخروج من الحساب' : 'Sign Out of Account'}
          </div>
          <p className="text-xs text-slate-500">
            {isAr
              ? 'الخروج من حسابك الحالي والعودة إلى شاشة الدخول أو إنشاء حساب آخر'
              : 'Sign out and return to the login screen'}
          </p>
        </div>
        <button
          type="button"
          onClick={onLogout}
          className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs sm:text-sm font-bold flex items-center gap-2 cursor-pointer"
        >
          <LogOut className="w-4 h-4" />
          <span>{isAr ? 'تسجيل الخروج' : 'Logout'}</span>
        </button>
      </div>

      {/* Photo Studio Modal */}
      {studioMode && (
        <PhotoStudioModal
          lang={lang}
          mode={studioMode}
          currentImageUrl={
            studioMode === 'avatar'
              ? currentUser.customAvatarUrl
              : currentUser.customCoverUrl
          }
          currentCoverKey={currentUser.coverKey}
          onClose={() => setStudioMode(null)}
          onSavePhoto={(dataUrl, coverKey) => {
            if (studioMode === 'avatar') {
              onUpdateUser({ customAvatarUrl: dataUrl });
            } else {
              onUpdateUser({
                customCoverUrl: dataUrl,
                coverKey: coverKey || currentUser.coverKey,
              });
            }
          }}
        />
      )}
    </div>
  );
};
