import React, { useState } from 'react';
import {
  UserPlus,
  UserCheck,
  MessageSquare,
  MapPin,
  Sparkles,
  CheckCircle2,
  SlidersHorizontal,
  X,
  Plus,
  Lock,
  Users,
} from 'lucide-react';
import type { Language, User } from '../types.ts';
import {
  AVAILABLE_COUNTRIES,
  AVAILABLE_INTERESTS,
} from '../defaultData.ts';
import { UserAvatar, CoverBannerVisual } from './VisualAssets.tsx';

interface PeopleDiscoverySectionProps {
  lang: Language;
  currentUser: User;
  users: User[];
  onToggleFriend: (targetUserId: string) => void;
  onToggleFollow: (targetUserId: string) => void;
  onMessageUser: (targetUser: User) => void;
  onUpdateCurrentUser: (updates: Partial<User>) => void;
  onAddContactUser: (
    name: string,
    handleOrPhone: string,
    country?: string,
    city?: string,
    interests?: string[]
  ) => User;
  compact?: boolean;
}

export const PeopleDiscoverySection: React.FC<PeopleDiscoverySectionProps> = ({
  lang,
  currentUser,
  users,
  onToggleFriend,
  onToggleFollow,
  onMessageUser,
  onUpdateCurrentUser,
  onAddContactUser,
  compact = false,
}) => {
  const isAr = lang === 'ar';

  const [filterMode, setFilterMode] = useState<
    'all' | 'location' | 'interests'
  >('all');
  const [selectedCountryFilter, setSelectedCountryFilter] =
    useState<string>('all');
  const [showPreferencesEditor, setShowPreferencesEditor] =
    useState<boolean>(false);
  const [showAddPersonModal, setShowAddPersonModal] = useState<boolean>(false);
  const [inspectedUser, setInspectedUser] = useState<User | null>(null);

  // New person form
  const [newPersonName, setNewPersonName] = useState('');
  const [newPersonHandle, setNewPersonHandle] = useState('');
  const [newPersonCountry, setNewPersonCountry] = useState(
    currentUser.country || 'مصر'
  );
  const [newPersonCity, setNewPersonCity] = useState(
    currentUser.city || 'القاهرة'
  );

  const myCountry = currentUser.country || 'مصر';
  const myCity = currentUser.city || 'القاهرة';
  const myInterests = currentUser.interests || [
    'البرمجة والتقنية',
    'الأخبار والمجتمع',
  ];

  const otherUsers = users.filter((u) => u.id !== currentUser.id);

  // Compute match score & reasons for each user
  const scoredUsers = otherUsers
    .map((u) => {
      const sameCountry = (u.country || '') === myCountry;
      const sameCity = sameCountry && (u.city || '') === myCity;
      const sharedInterests = (u.interests || []).filter((i) =>
        myInterests.includes(i)
      );
      const isFriend = (currentUser.friendIds || []).includes(u.id);
      const isFollowing =
        (currentUser.followingIds || []).includes(u.id) || Boolean(u.isFollowing);

      let score = 0;
      if (sameCity) score += 5;
      else if (sameCountry) score += 3;
      score += sharedInterests.length * 2;

      return {
        user: u,
        sameCountry,
        sameCity,
        sharedInterests,
        isFriend,
        isFollowing,
        score,
      };
    })
    .filter((item) => {
      if (
        selectedCountryFilter !== 'all' &&
        item.user.country !== selectedCountryFilter
      ) {
        return false;
      }
      if (filterMode === 'location') {
        return item.sameCountry;
      }
      if (filterMode === 'interests') {
        return item.sharedInterests.length > 0;
      }
      return true;
    })
    .sort((a, b) => b.score - a.score);

  const handleToggleMyInterest = (interestAr: string) => {
    const next = myInterests.includes(interestAr)
      ? myInterests.filter((x) => x !== interestAr)
      : [...myInterests, interestAr];
    onUpdateCurrentUser({ interests: next });
  };

  const handleAddPersonSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPersonName.trim()) return;
    onAddContactUser(
      newPersonName.trim(),
      newPersonHandle.trim() || newPersonName.trim(),
      newPersonCountry,
      newPersonCity,
      myInterests.slice(0, 2)
    );
    setNewPersonName('');
    setNewPersonHandle('');
    setShowAddPersonModal(false);
  };

  const activeCountryObj =
    AVAILABLE_COUNTRIES.find((c) => c.nameAr === myCountry) ||
    AVAILABLE_COUNTRIES[0];

  return (
    <div className="bg-white dark:bg-[#151D1C] border border-slate-200/80 dark:border-slate-800 rounded-3xl p-4 sm:p-5 space-y-4 shadow-xs">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-[#0E6B63]/10 dark:bg-[#5FD0C4]/15 text-[#0E6B63] dark:text-[#5FD0C4] flex items-center justify-center">
            <Users className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-extrabold text-sm sm:text-base text-[#1F1A12] dark:text-white">
              {isAr
                ? 'أشخاص قد تعرفهم (اقتراحات حسب البلد والاهتمامات)'
                : 'People You May Know (By Location & Interests)'}
            </h3>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              {isAr
                ? `موقعك الحالي: 📍 ${myCountry} (${myCity}) · ${myInterests.length} اهتمامات نشطة`
                : `Your location: 📍 ${myCountry} (${myCity}) · ${myInterests.length} interests`}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => setShowPreferencesEditor((p) => !p)}
            className="px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-[#0E6B63]/10 text-[11px] font-bold text-slate-700 dark:text-slate-200 flex items-center gap-1 cursor-pointer"
            title={
              isAr
                ? 'تعديل بلدك وموقعك واهتماماتك'
                : 'Edit your country & interests'
            }
          >
            <SlidersHorizontal className="w-3.5 h-3.5 text-[#0E6B63] dark:text-[#5FD0C4]" />
            <span>{isAr ? 'بلدي واهتماماتي' : 'My Location & Interests'}</span>
          </button>

          <button
            type="button"
            onClick={() => setShowAddPersonModal(true)}
            className="px-2.5 py-1.5 rounded-xl bg-[#0E6B63] hover:bg-[#0B5650] text-white text-[11px] font-bold flex items-center gap-1 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5 text-[#F2A93B]" />
            <span>{isAr ? 'إضافة شخص' : 'Add Person'}</span>
          </button>
        </div>
      </div>

      {/* Inline Preferences Editor (Country, City & Interests) */}
      {showPreferencesEditor && (
        <div className="p-3.5 rounded-2xl bg-[#FAF7F2] dark:bg-slate-900 border border-[#0E6B63]/30 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-extrabold text-[#0E6B63] dark:text-[#5FD0C4] flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-[#F2A93B]" />
              <span>
                {isAr
                  ? 'تحديد بلدك وموقعك واهتماماتك لتحديث الاقتراحات فوراً'
                  : 'Update your Country, City & Interests'}
              </span>
            </span>
            <button
              type="button"
              onClick={() => setShowPreferencesEditor(false)}
              className="text-slate-400 hover:text-slate-600 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-300 mb-1">
                {isAr ? 'البلد:' : 'Country:'}
              </label>
              <select
                value={myCountry}
                onChange={(e) => {
                  const nextC = e.target.value;
                  const found = AVAILABLE_COUNTRIES.find(
                    (c) => c.nameAr === nextC
                  );
                  const nextCity = found ? found.citiesAr[0] : '';
                  onUpdateCurrentUser({
                    country: nextC,
                    city: nextCity,
                    location: `${nextC} · ${nextCity}`,
                  });
                }}
                className="w-full px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
              >
                {AVAILABLE_COUNTRIES.map((c) => (
                  <option key={c.code} value={c.nameAr}>
                    {isAr ? c.nameAr : c.nameEn}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-300 mb-1">
                {isAr ? 'المدينة / المحافظة:' : 'City:'}
              </label>
              <select
                value={myCity}
                onChange={(e) => {
                  const nextCity = e.target.value;
                  onUpdateCurrentUser({
                    city: nextCity,
                    location: `${myCountry} · ${nextCity}`,
                  });
                }}
                className="w-full px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
              >
                {activeCountryObj.citiesAr.map((cityAr, idx) => (
                  <option key={cityAr} value={cityAr}>
                    {isAr ? cityAr : activeCountryObj.citiesEn[idx]}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-300 mb-1.5">
              {isAr ? 'اهتماماتك:' : 'Your Interests:'}
            </label>
            <div className="flex flex-wrap gap-1.5">
              {AVAILABLE_INTERESTS.map((item) => {
                const active = myInterests.includes(item.labelAr);
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleToggleMyInterest(item.labelAr)}
                    className={`px-2.5 py-1 rounded-xl text-[11px] font-bold cursor-pointer transition-colors ${
                      active
                        ? 'bg-[#0E6B63] text-white'
                        : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    {isAr ? item.labelAr : item.labelEn} {active ? '✓' : '+'}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Filter Tabs: All / Same Country & Location / Shared Interests + Country Selector */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            type="button"
            onClick={() => setFilterMode('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
              filterMode === 'all'
                ? 'bg-[#0E6B63] text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            {isAr ? 'كل الاقتراحات' : 'All'}
          </button>
          <button
            type="button"
            onClick={() => setFilterMode('location')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer ${
              filterMode === 'location'
                ? 'bg-[#0E6B63] text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            <MapPin className="w-3.5 h-3.5 text-[#F2A93B]" />
            <span>
              {isAr ? `في بلدك (${myCountry})` : `In ${myCountry}`}
            </span>
          </button>
          <button
            type="button"
            onClick={() => setFilterMode('interests')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer ${
              filterMode === 'interests'
                ? 'bg-[#0E6B63] text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-[#F2A93B]" />
            <span>{isAr ? 'حسب اهتماماتك' : 'Shared Interests'}</span>
          </button>
        </div>

        <select
          value={selectedCountryFilter}
          onChange={(e) => setSelectedCountryFilter(e.target.value)}
          className="px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200"
        >
          <option value="all">{isAr ? '🌍 كل الدول' : '🌍 All Countries'}</option>
          {AVAILABLE_COUNTRIES.map((c) => (
            <option key={c.code} value={c.nameAr}>
              📍 {isAr ? c.nameAr : c.nameEn}
            </option>
          ))}
        </select>
      </div>

      {/* Horizontal / Grid Cards of Suggested People */}
      {scoredUsers.length === 0 ? (
        <div className="p-6 text-center rounded-2xl bg-slate-50 dark:bg-slate-900/50 border border-slate-200/60 dark:border-slate-800 space-y-2">
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {isAr
              ? 'لا توجد حسابات مطابقة لهذا الفلتر حالياً. جرّب عرض كل الدول أو كل الاقتراحات.'
              : 'No matching accounts for this filter. Try viewing all countries.'}
          </p>
          <button
            type="button"
            onClick={() => {
              setFilterMode('all');
              setSelectedCountryFilter('all');
            }}
            className="px-3 py-1.5 rounded-xl bg-[#0E6B63] text-white text-xs font-bold cursor-pointer"
          >
            {isAr ? 'عرض جميع الحسابات المقترحة' : 'Show All Suggestions'}
          </button>
        </div>
      ) : (
        <div
          className={
            compact
              ? 'space-y-3'
              : 'flex gap-3.5 overflow-x-auto pb-2 snap-x'
          }
        >
          {scoredUsers.map(
            ({
              user: u,
              sameCountry,
              sameCity,
              sharedInterests,
              isFriend,
              isFollowing,
            }) => {
              const messagesDisabled = u.settings?.whoCanMessage === 'nobody';
              return (
                <div
                  key={u.id}
                  className={`${
                    compact ? 'w-full' : 'min-w-[250px] max-w-[270px] shrink-0 snap-start'
                  } rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-[#FAF7F2]/70 dark:bg-slate-900/80 p-3.5 flex flex-col justify-between gap-3 hover:border-[#0E6B63] transition-colors`}
                >
                  <div className="space-y-2.5">
                    {/* Top Row: Avatar + Name + Location Badge */}
                    <div className="flex items-start justify-between gap-2">
                      <div
                        onClick={() => setInspectedUser(u)}
                        className="flex items-center gap-2.5 cursor-pointer group min-w-0"
                      >
                        <div className="relative shrink-0">
                          <UserAvatar
                            avatarKey={u.avatarKey}
                            customAvatarUrl={u.customAvatarUrl}
                            name={u.name}
                            size="md"
                          />
                          {u.isOnline &&
                            u.settings?.showOnlineStatus !== false && (
                              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-slate-900 absolute bottom-0 end-0" />
                            )}
                        </div>
                        <div className="min-w-0">
                          <div className="flex items-center gap-1">
                            <span className="font-extrabold text-xs sm:text-sm text-[#1F1A12] dark:text-white truncate group-hover:text-[#0E6B63] dark:group-hover:text-[#5FD0C4]">
                              {isAr ? u.name : u.nameEn}
                            </span>
                            {u.isVerified && (
                              <CheckCircle2 className="w-3.5 h-3.5 text-[#0E6B63] dark:text-[#5FD0C4] shrink-0" />
                            )}
                          </div>
                          <div
                            dir="ltr"
                            className="text-[11px] text-slate-500 truncate"
                          >
                            {u.handle}
                          </div>
                        </div>
                      </div>

                      {u.country && (
                        <span className="px-2 py-0.5 rounded-lg bg-[#0E6B63]/10 dark:bg-[#5FD0C4]/15 text-[#0E6B63] dark:text-[#5FD0C4] text-[10px] font-bold shrink-0 flex items-center gap-1">
                          <MapPin className="w-2.5 h-2.5 text-[#F2A93B]" />
                          <span>
                            {u.country}
                            {u.city ? ` · ${u.city}` : ''}
                          </span>
                        </span>
                      )}
                    </div>

                    {/* Role & Match Reason */}
                    <p className="text-[11px] text-slate-600 dark:text-slate-300 line-clamp-2 leading-relaxed">
                      {isAr ? u.role || u.bio : u.roleEn || u.bioEn}
                    </p>

                    {/* Match Badges (Same Country/City + Shared Interests) */}
                    <div className="flex flex-wrap gap-1">
                      {sameCity ? (
                        <span className="px-2 py-0.5 rounded-md bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 text-[10px] font-extrabold">
                          {isAr
                            ? `📍 من مدينتك (${u.city})`
                            : `📍 In your city (${u.city})`}
                        </span>
                      ) : sameCountry ? (
                        <span className="px-2 py-0.5 rounded-md bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 text-[10px] font-extrabold">
                          {isAr
                            ? `📍 من بلدك (${u.country})`
                            : `📍 Same country (${u.country})`}
                        </span>
                      ) : null}

                      {sharedInterests.slice(0, 2).map((intr) => (
                        <span
                          key={intr}
                          className="px-2 py-0.5 rounded-md bg-[#F2A93B]/20 text-amber-900 dark:text-[#F2A93B] text-[10px] font-bold"
                        >
                          🎯 {intr}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Action Buttons: Add Friend + Follow + Send Message */}
                  <div className="space-y-1.5 pt-2 border-t border-slate-200/70 dark:border-slate-800">
                    <div className="grid grid-cols-2 gap-1.5">
                      <button
                        type="button"
                        onClick={() => onToggleFriend(u.id)}
                        className={`min-h-[34px] px-2.5 py-1.5 rounded-xl text-[11px] font-extrabold flex items-center justify-center gap-1 transition-colors cursor-pointer ${
                          isFriend
                            ? 'bg-emerald-600 text-white'
                            : 'bg-[#0E6B63] hover:bg-[#0B5650] text-white'
                        }`}
                      >
                        {isFriend ? (
                          <>
                            <UserCheck className="w-3.5 h-3.5" />
                            <span>{isAr ? 'صديق ✓' : 'Friends ✓'}</span>
                          </>
                        ) : (
                          <>
                            <UserPlus className="w-3.5 h-3.5" />
                            <span>{isAr ? 'إضافة صديق' : 'Add Friend'}</span>
                          </>
                        )}
                      </button>

                      <button
                        type="button"
                        onClick={() => onToggleFollow(u.id)}
                        className={`min-h-[34px] px-2.5 py-1.5 rounded-xl text-[11px] font-extrabold flex items-center justify-center gap-1 border transition-colors cursor-pointer ${
                          isFollowing
                            ? 'border-[#0E6B63] bg-[#0E6B63]/15 text-[#0E6B63] dark:text-[#5FD0C4]'
                            : 'border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:border-[#0E6B63]'
                        }`}
                      >
                        <span>
                          {isFollowing
                            ? isAr
                              ? 'متابَع ✓'
                              : 'Following ✓'
                            : isAr
                            ? '+ متابعة'
                            : '+ Follow'}
                        </span>
                      </button>
                    </div>

                    <button
                      type="button"
                      onClick={() => onMessageUser(u)}
                      className={`w-full min-h-[34px] px-3 py-1.5 rounded-xl text-[11px] font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                        messagesDisabled
                          ? 'bg-slate-200 dark:bg-slate-800 text-slate-500'
                          : 'bg-[#F2A93B]/20 hover:bg-[#F2A93B]/30 text-amber-950 dark:text-[#F2A93B]'
                      }`}
                    >
                      {messagesDisabled ? (
                        <>
                          <Lock className="w-3.5 h-3.5" />
                          <span>
                            {isAr ? 'الرسائل مغلقة 🔒' : 'Messages Locked 🔒'}
                          </span>
                        </>
                      ) : (
                        <>
                          <MessageSquare className="w-3.5 h-3.5" />
                          <span>
                            {isAr ? 'إرسال رسالة خاصة' : 'Send Message'}
                          </span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              );
            }
          )}
        </div>
      )}

      {/* Inspected User Full Profile Modal */}
      {inspectedUser && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-[#151D1C] border border-slate-200 dark:border-slate-800 rounded-3xl max-w-md w-full overflow-hidden shadow-2xl">
            <CoverBannerVisual
              coverKey={inspectedUser.coverKey || 'royal_majlis'}
              customCoverUrl={inspectedUser.customCoverUrl}
              heightClass="h-32"
            >
              <button
                type="button"
                onClick={() => setInspectedUser(null)}
                className="absolute top-3 end-3 w-8 h-8 rounded-full bg-black/60 text-white flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </CoverBannerVisual>

            <div className="px-5 pb-5 space-y-4">
              <div className="flex items-end justify-between -mt-10 relative z-10">
                <div className="ring-4 ring-white dark:ring-[#151D1C] rounded-full">
                  <UserAvatar
                    avatarKey={inspectedUser.avatarKey}
                    customAvatarUrl={inspectedUser.customAvatarUrl}
                    name={inspectedUser.name}
                    size="xl"
                  />
                </div>
                {inspectedUser.country && (
                  <span className="px-3 py-1 rounded-full bg-[#0E6B63]/10 text-[#0E6B63] dark:text-[#5FD0C4] text-xs font-bold flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-[#F2A93B]" />
                    <span>
                      {inspectedUser.country}
                      {inspectedUser.city ? ` · ${inspectedUser.city}` : ''}
                    </span>
                  </span>
                )}
              </div>

              <div>
                <h3 className="text-lg font-extrabold text-[#1F1A12] dark:text-white flex items-center gap-1.5">
                  <span>{inspectedUser.name}</span>
                  {inspectedUser.isVerified && (
                    <CheckCircle2 className="w-4 h-4 text-[#0E6B63] dark:text-[#5FD0C4]" />
                  )}
                </h3>
                <div dir="ltr" className="text-xs text-slate-500">
                  {inspectedUser.handle}
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300 mt-2 leading-relaxed">
                  {inspectedUser.bio}
                </p>
              </div>

              {(inspectedUser.interests || []).length > 0 && (
                <div className="flex flex-wrap gap-1.5">
                  {(inspectedUser.interests || []).map((intr) => (
                    <span
                      key={intr}
                      className="px-2.5 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 text-[11px] font-bold text-slate-700 dark:text-slate-300"
                    >
                      🎯 {intr}
                    </span>
                  ))}
                </div>
              )}

              <div className="grid grid-cols-3 gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => onToggleFriend(inspectedUser.id)}
                  className="py-2.5 px-3 rounded-xl bg-[#0E6B63] text-white text-xs font-extrabold flex items-center justify-center gap-1 cursor-pointer"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>
                    {(currentUser.friendIds || []).includes(inspectedUser.id)
                      ? isAr
                        ? 'صديق ✓'
                        : 'Friends ✓'
                      : isAr
                      ? 'إضافة صديق'
                      : 'Add Friend'}
                  </span>
                </button>
                <button
                  type="button"
                  onClick={() => onToggleFollow(inspectedUser.id)}
                  className="py-2.5 px-3 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-white text-xs font-extrabold cursor-pointer"
                >
                  {(currentUser.followingIds || []).includes(inspectedUser.id)
                    ? isAr
                      ? 'متابَع ✓'
                      : 'Following ✓'
                    : isAr
                    ? '+ متابعة'
                    : '+ Follow'}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const target = inspectedUser;
                    setInspectedUser(null);
                    onMessageUser(target);
                  }}
                  className="py-2.5 px-3 rounded-xl bg-[#F2A93B] text-[#1F1A12] text-xs font-extrabold flex items-center justify-center gap-1 cursor-pointer"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>{isAr ? 'مراسلة' : 'Message'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add New Person Modal */}
      {showAddPersonModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-[#151D1C] border border-slate-200 dark:border-slate-800 rounded-3xl max-w-md w-full p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between">
              <h3 className="text-sm sm:text-base font-extrabold text-[#1F1A12] dark:text-white">
                {isAr
                  ? 'إضافة صديق أو حساب جديد في مجتمع ونس'
                  : 'Add Person to WANAS'}
              </h3>
              <button
                type="button"
                onClick={() => setShowAddPersonModal(false)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddPersonSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
                  {isAr ? 'الاسم الكامل *' : 'Full Name *'}
                </label>
                <input
                  type="text"
                  required
                  value={newPersonName}
                  onChange={(e) => setNewPersonName(e.target.value)}
                  placeholder={isAr ? 'اسم الصديق...' : 'Friend name...'}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-transparent text-xs sm:text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
                  {isAr ? 'المعرف (@handle) أو الهاتف' : 'Handle or Phone'}
                </label>
                <input
                  type="text"
                  dir="ltr"
                  value={newPersonHandle}
                  onChange={(e) => setNewPersonHandle(e.target.value)}
                  placeholder="@friend_handle"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-transparent text-xs sm:text-sm"
                />
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
                    {isAr ? 'البلد' : 'Country'}
                  </label>
                  <select
                    value={newPersonCountry}
                    onChange={(e) => setNewPersonCountry(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-bold"
                  >
                    {AVAILABLE_COUNTRIES.map((c) => (
                      <option key={c.code} value={c.nameAr}>
                        {isAr ? c.nameAr : c.nameEn}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
                    {isAr ? 'المدينة' : 'City'}
                  </label>
                  <input
                    type="text"
                    value={newPersonCity}
                    onChange={(e) => setNewPersonCity(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-transparent text-xs font-bold"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddPersonModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-500 cursor-pointer"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-[#0E6B63] text-white text-xs font-extrabold cursor-pointer"
                >
                  {isAr ? 'إضافة ومتابعة' : 'Add & Follow'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
