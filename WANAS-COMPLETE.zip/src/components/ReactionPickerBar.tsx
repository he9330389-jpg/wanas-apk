import React, { useState } from 'react';
import type { Language, ReactionType } from '../types.ts';

export const REACTION_CONFIG: {
  type: ReactionType;
  emoji: string;
  labelAr: string;
  labelEn: string;
  colorClass: string;
}[] = [
  {
    type: 'like',
    emoji: '👍',
    labelAr: 'لايك',
    labelEn: 'Like',
    colorClass: 'text-sky-600 dark:text-sky-400 bg-sky-50 dark:bg-sky-950/40',
  },
  {
    type: 'love',
    emoji: '❤️',
    labelAr: 'أحببت',
    labelEn: 'Love',
    colorClass: 'text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40',
  },
  {
    type: 'haha',
    emoji: '😂',
    labelAr: 'أضحكني',
    labelEn: 'Haha',
    colorClass:
      'text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40',
  },
  {
    type: 'support',
    emoji: '🥰',
    labelAr: 'أدعمه',
    labelEn: 'Support',
    colorClass:
      'text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40',
  },
  {
    type: 'angry',
    emoji: '😡',
    labelAr: 'أغضبني',
    labelEn: 'Angry',
    colorClass:
      'text-orange-600 dark:text-orange-400 bg-orange-50 dark:bg-orange-950/40',
  },
  {
    type: 'disagree',
    emoji: '👎',
    labelAr: 'لا أوافق',
    labelEn: 'Disagree',
    colorClass:
      'text-slate-700 dark:text-slate-300 bg-slate-200/70 dark:bg-slate-800',
  },
];

interface ReactionPickerBarProps {
  lang: Language;
  currentUserId: string;
  reactions?: Partial<Record<ReactionType, string[]>>;
  likesFallback?: string[];
  onSelectReaction: (reaction: ReactionType) => void;
  compact?: boolean;
}

export const ReactionPickerBar: React.FC<ReactionPickerBarProps> = ({
  lang,
  currentUserId,
  reactions = {},
  likesFallback = [],
  onSelectReaction,
  compact = false,
}) => {
  const isAr = lang === 'ar';
  const [showTray, setShowTray] = useState(false);

  // Determine current user's active reaction
  let myReaction: ReactionType | null = null;
  for (const item of REACTION_CONFIG) {
    const list = reactions[item.type] || [];
    if (list.includes(currentUserId)) {
      myReaction = item.type;
      break;
    }
  }
  if (!myReaction && likesFallback.includes(currentUserId)) {
    myReaction = 'like';
  }

  // Compute total reaction count across all 6 types
  const countsByType: { cfg: (typeof REACTION_CONFIG)[number]; count: number }[] =
    [];
  let totalCount = 0;

  for (const cfg of REACTION_CONFIG) {
    const setIds = new Set<string>(reactions[cfg.type] || []);
    if (cfg.type === 'like') {
      likesFallback.forEach((id) => setIds.add(id));
    }
    const c = setIds.size;
    if (c > 0) {
      countsByType.push({ cfg, count: c });
      totalCount += c;
    }
  }

  const activeConfig = myReaction
    ? REACTION_CONFIG.find((r) => r.type === myReaction)
    : null;

  return (
    <div className="relative inline-flex items-center gap-1.5">
      {/* Reaction Tray Popup */}
      {showTray && (
        <div
          onMouseLeave={() => setShowTray(false)}
          className="absolute bottom-full mb-2 start-0 z-40 px-2.5 py-1.5 rounded-2xl bg-white dark:bg-[#1A2423] border border-slate-200 dark:border-slate-700 shadow-2xl flex items-center gap-1 animate-in fade-in zoom-in-95 duration-150"
        >
          {REACTION_CONFIG.map((r) => {
            const isSelected = myReaction === r.type;
            return (
              <button
                key={r.type}
                type="button"
                onClick={() => {
                  onSelectReaction(r.type);
                  setShowTray(false);
                }}
                className={`px-2 py-1 rounded-xl flex flex-col items-center gap-0.5 transition-transform hover:scale-115 cursor-pointer ${
                  isSelected
                    ? 'bg-[#0E6B63]/15 ring-1 ring-[#0E6B63]'
                    : 'hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
                title={isAr ? r.labelAr : r.labelEn}
              >
                <span className={compact ? 'text-base' : 'text-lg'}>
                  {r.emoji}
                </span>
                <span className="text-[9px] font-extrabold text-slate-700 dark:text-slate-200 whitespace-nowrap">
                  {isAr ? r.labelAr : r.labelEn}
                </span>
              </button>
            );
          })}
        </div>
      )}

      {/* Main Trigger Button */}
      <div className="inline-flex items-center rounded-xl bg-slate-100/80 dark:bg-slate-800/80 p-0.5">
        <button
          type="button"
          onClick={() => {
            if (myReaction) {
              onSelectReaction(myReaction);
            } else {
              onSelectReaction('like');
            }
          }}
          className={`${
            compact ? 'min-h-[30px] px-2.5 py-1 text-[11px]' : 'min-h-[38px] px-3 py-1.5 text-xs'
          } rounded-xl font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
            activeConfig
              ? activeConfig.colorClass
              : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200/60 dark:hover:bg-slate-700/60'
          }`}
        >
          <span className={compact ? 'text-sm' : 'text-base'}>
            {activeConfig ? activeConfig.emoji : '👍'}
          </span>
          <span>
            {activeConfig
              ? isAr
                ? activeConfig.labelAr
                : activeConfig.labelEn
              : isAr
              ? 'تفاعل'
              : 'React'}
          </span>
          {totalCount > 0 && (
            <span className="font-mono tabular-nums font-extrabold">
              {totalCount}
            </span>
          )}
        </button>

        {/* Expand 6-Reactions Picker Button */}
        <button
          type="button"
          onClick={() => setShowTray((prev) => !prev)}
          title={
            isAr
              ? 'اختر رياكت (لايك، أحببت، أضحكني، أدعمه، أغضبني، لا أوافق)'
              : 'Choose Reaction'
          }
          className={`${
            compact ? 'min-h-[30px] px-1.5 text-[10px]' : 'min-h-[38px] px-2 text-xs'
          } rounded-xl text-slate-500 hover:text-[#0E6B63] dark:hover:text-[#5FD0C4] font-bold cursor-pointer`}
        >
          ❤️😂😡
        </button>
      </div>

      {/* Summary Badges of Active Reactions */}
      {countsByType.length > 0 && !compact && (
        <div className="hidden sm:flex items-center gap-1">
          {countsByType.slice(0, 4).map(({ cfg, count }) => (
            <button
              key={cfg.type}
              type="button"
              onClick={() => onSelectReaction(cfg.type)}
              className="px-1.5 py-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-[11px] font-bold flex items-center gap-0.5 cursor-pointer hover:ring-1 hover:ring-[#0E6B63]"
              title={isAr ? cfg.labelAr : cfg.labelEn}
            >
              <span>{cfg.emoji}</span>
              <span className="font-mono text-[10px] text-slate-600 dark:text-slate-300">
                {count}
              </span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
