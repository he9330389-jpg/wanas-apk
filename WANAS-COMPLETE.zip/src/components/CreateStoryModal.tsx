import React, { useState, useRef } from 'react';
import {
  X,
  Type,
  Mic,
  Image as ImageIcon,
  Video,
  Music,
  Square,
  Check,
  Link2,
  Shield,
  Users,
  Globe,
  UserCheck,
  UserX,
  Camera,
} from 'lucide-react';
import type {
  Language,
  StoryItem,
  StoryType,
  StoryPrivacyMode,
  User,
} from '../types.ts';
import { AudioWavePlayer, UserAvatar } from './VisualAssets.tsx';
import {
  readFileAsCompressedDataUrl,
  readMediaFileWithDuration,
} from '../utils/mediaUtils.ts';

interface CreateStoryModalProps {
  lang: Language;
  currentUser: User;
  users?: User[];
  onClose: () => void;
  onCreateStory: (story: StoryItem) => void;
}

const STORY_BG_COLORS = [
  '#0E6B63',
  '#1F1A12',
  '#F2A93B',
  '#1E3A8A',
  '#881337',
  '#047857',
];

const STORY_PRIVACY_OPTIONS: {
  mode: StoryPrivacyMode;
  labelAr: string;
  labelEn: string;
  descAr: string;
  descEn: string;
  icon: React.FC<{ className?: string }>;
}[] = [
  {
    mode: 'public',
    labelAr: 'للعامة (الجميع)',
    labelEn: 'Public (Everyone)',
    descAr: 'يظهر لجميع مستخدمي البرنامج',
    descEn: 'Visible to everyone on WANAS',
    icon: Globe,
  },
  {
    mode: 'friends_only',
    labelAr: 'للأصدقاء فقط',
    labelEn: 'Friends Only',
    descAr: 'يظهر لأصدقائك ومتابعيك فقط',
    descEn: 'Visible only to your friends',
    icon: Users,
  },
  {
    mode: 'public_except_friends',
    labelAr: 'للعامة فقط (خارج الأصدقاء)',
    labelEn: 'Non-Friends Public Only',
    descAr: 'يظهر للعامة خارج قائمة الأصدقاء ولا يظهر للأصدقاء',
    descEn: 'Visible only to public outside your friends list',
    icon: Shield,
  },
  {
    mode: 'friends_of_friends',
    labelAr: 'لأصدقاء الأصدقاء',
    labelEn: 'Friends of Friends',
    descAr: 'يظهر للأصدقاء وأصدقاء الأصدقاء',
    descEn: 'Visible to friends and friends of friends',
    icon: Users,
  },
  {
    mode: 'custom_include',
    labelAr: 'أصدقاء محددون فقط ✓',
    labelEn: 'Specific Friends Only ✓',
    descAr: 'اختر أشخاصاً محددين فقط لرؤية الستوري وحجب الباقين',
    descEn: 'Only people you check below can view this story',
    icon: UserCheck,
  },
  {
    mode: 'custom_exclude',
    labelAr: 'أصدقائي باستثناء... 🚫',
    labelEn: 'My Friends Except... 🚫',
    descAr: 'إخفاء الستوري عن أشخاص محددين (مثل الواتساب)',
    descEn: 'Hide story from specific people (WhatsApp style)',
    icon: UserX,
  },
];

export const CreateStoryModal: React.FC<CreateStoryModalProps> = ({
  lang,
  currentUser,
  users = [],
  onClose,
  onCreateStory,
}) => {
  const isAr = lang === 'ar';
  const [storyType, setStoryType] = useState<StoryType>('text');
  const [caption, setCaption] = useState('');
  const [linkUrl, setLinkUrl] = useState('');
  const [bgColor, setBgColor] = useState('#0E6B63');
  const [imageUrl, setImageUrl] = useState<string | undefined>(undefined);
  const [videoUrl, setVideoUrl] = useState<string | undefined>(undefined);
  const [audioUrl, setAudioUrl] = useState<string | undefined>(undefined);
  const [audioDuration, setAudioDuration] = useState<string>('0:15');
  const [attachedFileName, setAttachedFileName] = useState<string>('');
  const [isRecording, setIsRecording] = useState(false);
  const [recordSeconds, setRecordSeconds] = useState(0);

  // Story Privacy State (WhatsApp-style control)
  const [privacyMode, setPrivacyMode] = useState<StoryPrivacyMode>(
    currentUser.settings?.defaultStoryPrivacy || 'public'
  );
  const [selectedUserIds, setSelectedUserIds] = useState<string[]>([]);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<number | null>(null);

  const otherUsers = users.filter((u) => u.id !== currentUser.id);

  const formatTime = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}:${String(s).padStart(2, '0')}`;
  };

  const toggleUserSelection = (uid: string) => {
    setSelectedUserIds((prev) =>
      prev.includes(uid) ? prev.filter((id) => id !== uid) : [...prev, uid]
    );
  };

  const handleStartVoice = async () => {
    setStoryType('voice');
    setRecordSeconds(0);
    setIsRecording(true);
    timerRef.current = window.setInterval(() => {
      setRecordSeconds((prev) => prev + 1);
    }, 1000);

    try {
      if (navigator.mediaDevices?.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const recorder = new MediaRecorder(stream);
        chunksRef.current = [];
        recorder.ondataavailable = (e) => {
          if (e.data.size > 0) chunksRef.current.push(e.data);
        };
        recorder.onstop = () => {
          stream.getTracks().forEach((t) => t.stop());
          const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
          const reader = new FileReader();
          reader.onloadend = () => {
            if (typeof reader.result === 'string') {
              setAudioUrl(reader.result);
              setAttachedFileName(
                isAr ? 'تسجيل صوتي بالمايك' : 'Microphone Voice Note'
              );
            }
          };
          reader.readAsDataURL(blob);
        };
        mediaRecorderRef.current = recorder;
        recorder.start();
      }
    } catch {
      // Fallback
    }
  };

  const handleStopVoice = () => {
    if (timerRef.current) window.clearInterval(timerRef.current);
    setAudioDuration(formatTime(Math.max(2, recordSeconds)));
    setIsRecording(false);
    if (
      mediaRecorderRef.current &&
      mediaRecorderRef.current.state !== 'inactive'
    ) {
      mediaRecorderRef.current.stop();
    } else {
      setAudioUrl('synth:voice');
      setAttachedFileName(isAr ? 'تسجيل صوتي بالمايك' : 'Microphone Voice Note');
    }
  };

  const handleFileChange = async (
    e: React.ChangeEvent<HTMLInputElement>,
    kind: 'image' | 'video' | 'audio'
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setAttachedFileName(file.name);

    if (kind === 'image') {
      setStoryType('image');
      try {
        const compressed = await readFileAsCompressedDataUrl(file, 'post');
        setImageUrl(compressed);
      } catch {
        // ignore
      }
    } else if (kind === 'video') {
      setStoryType('video');
      try {
        const res = await readMediaFileWithDuration(file, 'video');
        setVideoUrl(res.dataUrl);
        setAudioDuration(res.duration);
      } catch {
        // ignore
      }
    } else if (kind === 'audio') {
      setStoryType('audio_file');
      try {
        const res = await readMediaFileWithDuration(file, 'audio');
        setAudioUrl(res.dataUrl);
        setAudioDuration(res.duration);
      } catch {
        // ignore
      }
    }
    e.target.value = '';
  };

  const handlePublish = (e: React.FormEvent) => {
    e.preventDefault();
    const nowMs = Date.now();
    const newStory: StoryItem = {
      id: `st_${nowMs}`,
      authorId: currentUser.id,
      storyType,
      title:
        caption.trim().slice(0, 28) ||
        (storyType === 'voice' || storyType === 'audio_file'
          ? isAr
            ? 'ستوري صوتي 🎙️'
            : 'Voice Story 🎙️'
          : storyType === 'video'
          ? isAr
            ? 'ستوري فيديو 🎬'
            : 'Video Story 🎬'
          : storyType === 'image'
          ? isAr
            ? 'ستوري صورة 📷'
            : 'Photo Story 📷'
          : storyType === 'link'
          ? isAr
            ? 'ستوري رابط 🔗'
            : 'Link Story 🔗'
          : isAr
          ? 'ستوري جديد ✨'
          : 'New Story ✨'),
      titleEn: caption.trim().slice(0, 28) || 'New Story',
      caption:
        caption.trim() ||
        (linkUrl.trim()
          ? linkUrl.trim()
          : isAr
          ? 'ستوري جديد من حسابي على ونس'
          : 'New story on WANAS'),
      captionEn: caption.trim() || 'New story on WANAS',
      bgColor,
      linkUrl: linkUrl.trim() || undefined,
      imageUrl,
      videoUrl,
      audioUrl,
      audioDuration,
      privacyMode,
      allowedUserIds:
        privacyMode === 'custom_include' ? selectedUserIds : undefined,
      excludedUserIds:
        privacyMode === 'custom_exclude' ? selectedUserIds : undefined,
      createdAt: isAr ? 'الآن' : 'Just now',
      createdAtMs: nowMs,
      viewedBy: [],
      likes: [],
      reactions: {},
    };
    onCreateStory(newStory);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white dark:bg-[#0F1514] border border-slate-200 dark:border-slate-800 rounded-3xl max-w-xl w-full max-h-[92vh] flex flex-col overflow-hidden shadow-2xl">
        <div className="px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div>
            <h2 className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white">
              {isAr
                ? 'استوديو إضافة ستوري (قصة يومية مع التحكم في الخصوصية)'
                : 'Create Story & Privacy Control'}
            </h2>
            <p className="text-[11px] text-slate-500">
              {isAr
                ? 'ارفع صورة أو فيديو أو ملفاً صوتياً من هاتفك، أو سجل صوتك، وحدد من يشاهده'
                : 'Attach photo, video, audio from phone, record voice, and choose who sees it'}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form
          onSubmit={handlePublish}
          className="p-4 sm:p-5 space-y-4 overflow-y-auto flex-1"
        >
          {/* 6 Direct Story Type Buttons — Photo, Video, and Audio directly open phone file picker on tap! */}
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5 p-1.5 rounded-2xl bg-slate-100 dark:bg-slate-800">
            <button
              type="button"
              onClick={() => setStoryType('text')}
              className={`py-2 px-1 rounded-xl text-[11px] font-bold flex flex-col items-center gap-1 transition-all cursor-pointer ${
                storyType === 'text'
                  ? 'bg-[#0E6B63] text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              <Type className="w-4 h-4" />
              <span>{isAr ? 'كتابة' : 'Text'}</span>
            </button>

            {/* Direct Phone Image Picker Tab */}
            <label
              className={`relative overflow-hidden py-2 px-1 rounded-xl text-[11px] font-bold flex flex-col items-center gap-1 transition-all cursor-pointer ${
                storyType === 'image'
                  ? 'bg-[#0E6B63] text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              <ImageIcon className="w-4 h-4" />
              <span>{isAr ? 'صورة هاتف' : 'Photo'}</span>
              <input
                type="file"
                accept="image/*"
                onChange={(e) => handleFileChange(e, 'image')}
                className="absolute inset-0 opacity-0 cursor-pointer"
              />
            </label>

            {/* Direct Phone Video Picker Tab */}
            <label
              className={`relative overflow-hidden py-2 px-1 rounded-xl text-[11px] font-bold flex flex-col items-center gap-1 transition-all cursor-pointer ${
                storyType === 'video'
                  ? 'bg-[#0E6B63] text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              <Video className="w-4 h-4" />
              <span>{isAr ? 'فيديو هاتف' : 'Video'}</span>
              <input
                type="file"
                accept="video/*"
                onChange={(e) => handleFileChange(e, 'video')}
                className="absolute inset-0 opacity-0 cursor-pointer"
              />
            </label>

            <button
              type="button"
              onClick={() => setStoryType('voice')}
              className={`py-2 px-1 rounded-xl text-[11px] font-bold flex flex-col items-center gap-1 transition-all cursor-pointer ${
                storyType === 'voice'
                  ? 'bg-[#0E6B63] text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              <Mic className="w-4 h-4" />
              <span>{isAr ? 'مايك صوتي' : 'Voice'}</span>
            </button>

            {/* Direct Phone Audio File Picker Tab */}
            <label
              className={`relative overflow-hidden py-2 px-1 rounded-xl text-[11px] font-bold flex flex-col items-center gap-1 transition-all cursor-pointer ${
                storyType === 'audio_file'
                  ? 'bg-[#0E6B63] text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              <Music className="w-4 h-4" />
              <span>{isAr ? 'ملف صوتي' : 'Audio File'}</span>
              <input
                type="file"
                accept="audio/*"
                onChange={(e) => handleFileChange(e, 'audio')}
                className="absolute inset-0 opacity-0 cursor-pointer"
              />
            </label>

            <button
              type="button"
              onClick={() => setStoryType('link')}
              className={`py-2 px-1 rounded-xl text-[11px] font-bold flex flex-col items-center gap-1 transition-all cursor-pointer ${
                storyType === 'link'
                  ? 'bg-[#0E6B63] text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              <Link2 className="w-4 h-4" />
              <span>{isAr ? 'رابط' : 'Link'}</span>
            </button>
          </div>

          {/* Story Preview Canvas */}
          <div
            style={{ backgroundColor: bgColor }}
            className="relative h-56 rounded-2xl overflow-hidden flex flex-col items-center justify-center p-4 text-white text-center shadow-inner"
          >
            {storyType === 'image' && imageUrl ? (
              <img
                src={imageUrl}
                alt="Story preview"
                className="absolute inset-0 w-full h-full object-contain bg-black"
              />
            ) : storyType === 'video' && videoUrl ? (
              <video
                src={videoUrl}
                controls
                playsInline
                className="absolute inset-0 w-full h-full object-contain bg-black"
              />
            ) : null}

            <div className="relative z-10 w-full space-y-2.5">
              {(storyType === 'voice' || storyType === 'audio_file') &&
                audioUrl && (
                  <div className="bg-black/65 backdrop-blur-md p-3 rounded-2xl">
                    <AudioWavePlayer
                      audioUrl={audioUrl}
                      durationLabel={audioDuration}
                      title={
                        attachedFileName ||
                        (isAr ? 'مقطع صوتي في الستوري' : 'Story Voice Note')
                      }
                    />
                  </div>
                )}

              <textarea
                rows={2}
                value={caption}
                onChange={(e) => setCaption(e.target.value)}
                placeholder={
                  isAr
                    ? 'اكتب نص الستوري أو تعليقك على الصورة أو الفيديو...'
                    : 'Type your story text or caption here...'
                }
                className="w-full bg-black/35 backdrop-blur-xs rounded-xl p-2.5 text-center text-white placeholder:text-white/80 font-bold text-sm sm:text-base focus:outline-none resize-none"
              />
            </div>
          </div>

          {/* Specific Media Controls */}
          {storyType === 'text' && (
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-600 dark:text-slate-300">
                {isAr ? 'لون خلفية الستوري:' : 'Background Color:'}
              </span>
              <div className="flex items-center gap-2">
                {STORY_BG_COLORS.map((col) => (
                  <button
                    key={col}
                    type="button"
                    onClick={() => setBgColor(col)}
                    style={{ backgroundColor: col }}
                    className={`w-6 h-6 rounded-full cursor-pointer ${
                      bgColor === col ? 'ring-2 ring-offset-2 ring-[#0E6B63]' : ''
                    }`}
                  />
                ))}
              </div>
            </div>
          )}

          {storyType === 'link' && (
            <div className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
              <Link2 className="w-4 h-4 text-[#0E6B63]" />
              <input
                type="url"
                dir="ltr"
                value={linkUrl}
                onChange={(e) => setLinkUrl(e.target.value)}
                placeholder="https://example.com"
                className="flex-1 bg-transparent text-xs sm:text-sm focus:outline-none"
              />
            </div>
          )}

          {storyType === 'voice' && (
            <div className="flex items-center justify-center">
              {!isRecording ? (
                <button
                  type="button"
                  onClick={handleStartVoice}
                  className="w-full py-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 text-amber-900 dark:text-[#F2A93B] font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Mic className="w-4 h-4" />
                  <span>
                    {isAr
                      ? 'اضغط هنا لفتح المايك وتسجيل ستوري بصوتك الآن'
                      : 'Tap to open Mic & record voice story'}
                  </span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleStopVoice}
                  className="w-full py-3 rounded-xl bg-rose-600 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Square className="w-4 h-4 fill-current" />
                  <span>
                    {isAr ? 'إيقاف التسجيل واعتماد الصوت' : 'Stop Recording'} (
                    {formatTime(recordSeconds)})
                  </span>
                </button>
              )}
            </div>
          )}

          {storyType === 'audio_file' && (
            <label className="relative overflow-hidden w-full py-3 rounded-xl border border-dashed border-[#0E6B63] bg-[#0E6B63]/5 text-[#0E6B63] dark:text-[#5FD0C4] font-bold text-xs sm:text-sm flex items-center justify-center gap-2 cursor-pointer">
              <Music className="w-4 h-4" />
              <span>
                {audioUrl
                  ? isAr
                    ? `تم إرفاق الملف الصوتي (${attachedFileName}) ✓ — اضغط للتغيير`
                    : `Audio attached (${attachedFileName}) ✓`
                  : isAr
                  ? 'اضغط لاختيار ملف صوتي من ملفات الموبايل'
                  : 'Choose audio file from phone'}
              </span>
              <input
                type="file"
                accept="audio/*"
                onChange={(e) => handleFileChange(e, 'audio')}
                className="absolute inset-0 opacity-0 cursor-pointer"
              />
            </label>
          )}

          {storyType === 'image' && (
            <div className="grid grid-cols-2 gap-2">
              <label className="relative overflow-hidden py-2.5 px-3 rounded-xl border border-dashed border-[#0E6B63] bg-[#0E6B63]/5 text-[#0E6B63] dark:text-[#5FD0C4] font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer">
                <ImageIcon className="w-4 h-4" />
                <span>
                  {imageUrl
                    ? isAr
                      ? 'تغيير الصورة من الهاتف'
                      : 'Change Photo'
                    : isAr
                    ? 'اختيار صورة من الموبايل'
                    : 'Choose from Phone'}
                </span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleFileChange(e, 'image')}
                  className="absolute inset-0 opacity-0 cursor-pointer"
                />
              </label>

              <label className="relative overflow-hidden py-2.5 px-3 rounded-xl border border-[#F2A93B]/50 bg-[#F2A93B]/15 text-amber-950 dark:text-[#F2A93B] font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer">
                <Camera className="w-4 h-4" />
                <span>
                  {isAr ? 'التقاط بكاميرا الهاتف' : 'Take with Camera'}
                </span>
                <input
                  type="file"
                  accept="image/*"
                  capture="environment"
                  onChange={(e) => handleFileChange(e, 'image')}
                  className="absolute inset-0 opacity-0 cursor-pointer"
                />
              </label>
            </div>
          )}

          {storyType === 'video' && (
            <div className="grid grid-cols-2 gap-2">
              <label className="relative overflow-hidden py-2.5 px-3 rounded-xl border border-dashed border-[#0E6B63] bg-[#0E6B63]/5 text-[#0E6B63] dark:text-[#5FD0C4] font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer">
                <Video className="w-4 h-4" />
                <span>
                  {videoUrl
                    ? isAr
                      ? 'تغيير الفيديو من الهاتف'
                      : 'Change Video'
                    : isAr
                    ? 'اختيار فيديو من الموبايل'
                    : 'Choose Video from Phone'}
                </span>
                <input
                  type="file"
                  accept="video/*"
                  onChange={(e) => handleFileChange(e, 'video')}
                  className="absolute inset-0 opacity-0 cursor-pointer"
                />
              </label>

              <label className="relative overflow-hidden py-2.5 px-3 rounded-xl border border-[#F2A93B]/50 bg-[#F2A93B]/15 text-amber-950 dark:text-[#F2A93B] font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer">
                <Camera className="w-4 h-4" />
                <span>
                  {isAr ? 'تصوير فيديو بالكاميرا' : 'Record Camera Video'}
                </span>
                <input
                  type="file"
                  accept="video/*"
                  capture="environment"
                  onChange={(e) => handleFileChange(e, 'video')}
                  className="absolute inset-0 opacity-0 cursor-pointer"
                />
              </label>
            </div>
          )}

          {/* WhatsApp-Style Story Privacy Control ("تحديد من يشاهد الستوري ومن لا يشاهده") */}
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-900/80 border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-extrabold text-[#0E6B63] dark:text-[#5FD0C4] flex items-center gap-1.5">
                <Shield className="w-4 h-4 text-[#F2A93B]" />
                <span>
                  {isAr
                    ? 'خصوصية الستوري (من يمكنه مشاهدة هذه القصة؟):'
                    : 'Story Privacy (Who can view this story?):'}
                </span>
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
              {STORY_PRIVACY_OPTIONS.map((opt) => {
                const IconComp = opt.icon;
                const active = privacyMode === opt.mode;
                return (
                  <button
                    key={opt.mode}
                    type="button"
                    onClick={() => setPrivacyMode(opt.mode)}
                    className={`p-2.5 rounded-xl border text-start transition-all cursor-pointer flex items-start gap-2 ${
                      active
                        ? 'bg-[#0E6B63]/10 border-[#0E6B63] dark:border-[#5FD0C4]'
                        : 'bg-white dark:bg-slate-800/70 border-slate-200/80 dark:border-slate-700'
                    }`}
                  >
                    <IconComp
                      className={`w-4 h-4 mt-0.5 shrink-0 ${
                        active ? 'text-[#0E6B63] dark:text-[#5FD0C4]' : 'text-slate-400'
                      }`}
                    />
                    <div className="min-w-0">
                      <div className="text-xs font-extrabold text-slate-900 dark:text-white">
                        {isAr ? opt.labelAr : opt.labelEn}
                      </div>
                      <div className="text-[10px] text-slate-500 dark:text-slate-400 leading-tight mt-0.5">
                        {isAr ? opt.descAr : opt.descEn}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Custom Friend Checklist when custom_include or custom_exclude is selected */}
            {(privacyMode === 'custom_include' ||
              privacyMode === 'custom_exclude') && (
              <div className="pt-2 border-t border-slate-200 dark:border-slate-800 space-y-2">
                <div className="text-[11px] font-bold text-slate-700 dark:text-slate-300">
                  {privacyMode === 'custom_include'
                    ? isAr
                      ? `حدد الأصدقاء المسموح لهم فقط برؤية الستوري (${selectedUserIds.length}):`
                      : `Select friends allowed to see this story (${selectedUserIds.length}):`
                    : isAr
                    ? `حدد الأشخاص المحجوبين من رؤية الستوري (${selectedUserIds.length}):`
                    : `Select people blocked from seeing this story (${selectedUserIds.length}):`}
                </div>

                {otherUsers.length === 0 ? (
                  <p className="text-[11px] text-slate-500">
                    {isAr
                      ? 'سيتم تطبيق هذا الإعداد تلقائياً على قائمة أصدقائك.'
                      : 'This privacy filter will apply to your friends list.'}
                  </p>
                ) : (
                  <div className="max-h-32 overflow-y-auto space-y-1">
                    {otherUsers.map((u) => {
                      const checked = selectedUserIds.includes(u.id);
                      return (
                        <div
                          key={u.id}
                          onClick={() => toggleUserSelection(u.id)}
                          className="p-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-between cursor-pointer"
                        >
                          <div className="flex items-center gap-2">
                            <UserAvatar
                              avatarKey={u.avatarKey}
                              customAvatarUrl={u.customAvatarUrl}
                              name={u.name}
                              size="sm"
                            />
                            <span className="text-xs font-bold">{u.name}</span>
                          </div>
                          <span
                            className={`px-2 py-0.5 rounded-lg text-[10px] font-bold ${
                              checked
                                ? privacyMode === 'custom_exclude'
                                  ? 'bg-rose-600 text-white'
                                  : 'bg-[#0E6B63] text-white'
                                : 'bg-slate-100 dark:bg-slate-700 text-slate-500'
                            }`}
                          >
                            {checked
                              ? privacyMode === 'custom_exclude'
                                ? isAr
                                  ? 'محجوب 🚫'
                                  : 'Blocked 🚫'
                                : isAr
                                ? 'مسموح ✓'
                                : 'Allowed ✓'
                              : isAr
                              ? 'تحديد'
                              : 'Select'}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}
          </div>

          <button
            type="submit"
            className="w-full min-h-[46px] py-3 rounded-xl bg-[#0E6B63] hover:bg-[#0b5650] text-white font-extrabold text-sm flex items-center justify-center gap-2 cursor-pointer shadow-md"
          >
            <Check className="w-4 h-4 text-[#F2A93B]" />
            <span>{isAr ? 'نشر الستوري الآن' : 'Publish Story Now'}</span>
          </button>
        </form>
      </div>
    </div>
  );
};
