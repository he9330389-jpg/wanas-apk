import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  MessageSquare,
  UserPlus,
  Mic,
  Square,
  Trash2,
  Search,
  Lock,
  Unlock,
  CheckCircle2,
  MapPin,
} from 'lucide-react';
import type { DirectMessage, Language, User, UserSettings } from '../types.ts';
import { DEFAULT_USER_SETTINGS } from '../defaultData.ts';
import { UserAvatar, AudioWavePlayer } from './VisualAssets.tsx';

interface DirectMessagesViewProps {
  lang: Language;
  users: User[];
  currentUser: User;
  messages: DirectMessage[];
  initialSelectedUserId?: string | null;
  onSendDirectMessage: (
    receiverId: string,
    text: string,
    audioUrl?: string
  ) => void;
  onAddContactUser: (name: string, handleOrPhone: string) => User;
  onToggleFriend?: (userId: string) => void;
  onToggleFollow?: (userId: string) => void;
  onUpdateCurrentUser?: (updates: Partial<User>) => void;
}

export const DirectMessagesView: React.FC<DirectMessagesViewProps> = ({
  lang,
  users,
  currentUser,
  messages,
  initialSelectedUserId,
  onSendDirectMessage,
  onAddContactUser,
  onToggleFriend,
  onToggleFollow,
  onUpdateCurrentUser,
}) => {
  const isAr = lang === 'ar';
  const contacts = users.filter((u) => u.id !== currentUser.id);
  const [selectedContactId, setSelectedContactId] = useState<string>(
    initialSelectedUserId || contacts[0]?.id || ''
  );

  useEffect(() => {
    if (initialSelectedUserId) {
      setSelectedContactId(initialSelectedUserId);
    }
  }, [initialSelectedUserId]);

  const [draft, setDraft] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const [showNewChatModal, setShowNewChatModal] = useState(false);
  const [newContactName, setNewContactName] = useState('');
  const [newContactHandle, setNewContactHandle] = useState('');

  const [isRecording, setIsRecording] = useState(false);
  const [recordSeconds, setRecordSeconds] = useState(0);
  const [recordedAudioUrl, setRecordedAudioUrl] = useState<string | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<number | null>(null);

  const activeContact =
    contacts.find((c) => c.id === selectedContactId) || contacts[0];

  const myMsgPrivacy = currentUser.settings?.whoCanMessage || 'everyone';

  const handleToggleMyMessageLock = () => {
    if (!onUpdateCurrentUser) return;
    const nextWhoCanMessage: UserSettings['whoCanMessage'] =
      myMsgPrivacy === 'nobody' ? 'everyone' : 'nobody';
    onUpdateCurrentUser({
      settings: {
        ...DEFAULT_USER_SETTINGS,
        ...(currentUser.settings || {}),
        whoCanMessage: nextWhoCanMessage,
      },
    });
  };

  // Check if activeContact allows messages from currentUser
  const activeContactMsgPolicy =
    activeContact?.settings?.whoCanMessage || 'everyone';
  const isFriendOrFollowing =
    (currentUser.friendIds || []).includes(activeContact?.id || '') ||
    (currentUser.followingIds || []).includes(activeContact?.id || '');
  const canSendMessageToActiveContact =
    activeContactMsgPolicy === 'everyone' ||
    (activeContactMsgPolicy === 'followers' && isFriendOrFollowing);

  const filteredContacts = contacts.filter((c) => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return true;
    return (
      c.name.toLowerCase().includes(q) ||
      c.handle.toLowerCase().includes(q) ||
      (c.country || '').toLowerCase().includes(q) ||
      (c.phone || '').toLowerCase().includes(q) ||
      (c.email || '').toLowerCase().includes(q)
    );
  });

  const conversationMessages = messages.filter(
    (m) =>
      (m.senderId === currentUser.id && m.receiverId === activeContact?.id) ||
      (m.senderId === activeContact?.id && m.receiverId === currentUser.id)
  );

  const startVoiceRecord = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;
      chunksRef.current = [];

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };

      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.onloadend = () => {
          if (typeof reader.result === 'string') {
            setRecordedAudioUrl(reader.result);
          }
        };
        reader.readAsDataURL(blob);
        stream.getTracks().forEach((t) => t.stop());
      };

      recorder.start();
      setIsRecording(true);
      setRecordSeconds(0);
      timerRef.current = window.setInterval(() => {
        setRecordSeconds((s) => s + 1);
      }, 1000);
    } catch {
      setIsRecording(true);
      setRecordSeconds(0);
      timerRef.current = window.setInterval(() => {
        setRecordSeconds((s) => s + 1);
      }, 1000);
    }
  };

  const stopVoiceRecord = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    if (
      mediaRecorderRef.current &&
      mediaRecorderRef.current.state !== 'inactive'
    ) {
      mediaRecorderRef.current.stop();
    } else {
      setRecordedAudioUrl('synth:voice');
    }
    setIsRecording(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeContact || !canSendMessageToActiveContact) return;
    if (!draft.trim() && !recordedAudioUrl) return;
    onSendDirectMessage(
      activeContact.id,
      draft.trim() || (isAr ? 'رسالة صوتية 🎙️' : 'Voice message 🎙️'),
      recordedAudioUrl || undefined
    );
    setDraft('');
    setRecordedAudioUrl(null);
  };

  const handleCreateContact = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newContactName.trim()) return;
    const created = onAddContactUser(
      newContactName.trim(),
      newContactHandle.trim() || newContactName.trim()
    );
    setSelectedContactId(created.id);
    setNewContactName('');
    setNewContactHandle('');
    setShowNewChatModal(false);
  };

  return (
    <div className="bg-white dark:bg-[#151D1C] border border-slate-200/80 dark:border-slate-800 rounded-3xl overflow-hidden grid grid-cols-1 md:grid-cols-12 min-h-[560px] shadow-xs">
      {/* Contacts List */}
      <div className="md:col-span-4 border-b md:border-b-0 md:border-e border-slate-200 dark:border-slate-800 flex flex-col">
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-[#0E6B63] dark:text-[#5FD0C4]" />
              <h2 className="font-extrabold text-base text-[#1F1A12] dark:text-white">
                {isAr ? 'الرسائل الخاصة' : 'Direct Messages'}
              </h2>
            </div>
            <button
              type="button"
              onClick={() => setShowNewChatModal(true)}
              className="px-3 py-1.5 rounded-xl bg-[#0E6B63] hover:bg-[#0B5650] text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>{isAr ? 'محادثة جديدة' : 'New Chat'}</span>
            </button>
          </div>

          {/* Quick Toggle: Allow or Block Incoming Messages to Me */}
          <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 flex items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 text-[11px] font-bold">
              {myMsgPrivacy === 'nobody' ? (
                <Lock className="w-3.5 h-3.5 text-rose-500 shrink-0" />
              ) : (
                <Unlock className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
              )}
              <span className="text-slate-700 dark:text-slate-300">
                {myMsgPrivacy === 'nobody'
                  ? isAr
                    ? 'استقبال الرسائل: مغلق 🔒'
                    : 'Incoming DMs: Locked 🔒'
                  : isAr
                  ? 'استقبال الرسائل: مفتوح ✓'
                  : 'Incoming DMs: Open ✓'}
              </span>
            </div>
            <button
              type="button"
              onClick={handleToggleMyMessageLock}
              className={`px-2.5 py-1 rounded-lg text-[10px] font-extrabold cursor-pointer ${
                myMsgPrivacy === 'nobody'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-rose-600/15 text-rose-600 dark:text-rose-400'
              }`}
            >
              {myMsgPrivacy === 'nobody'
                ? isAr
                  ? 'تفعيل الرسائل'
                  : 'Enable DMs'
                : isAr
                ? 'قفل الرسائل'
                : 'Lock DMs'}
            </button>
          </div>

          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute top-1/2 -translate-y-1/2 start-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={
                isAr
                  ? 'ابحث بالاسم أو البلد أو المعرف...'
                  : 'Search contacts...'
              }
              className="w-full ps-9 pe-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-900 text-xs text-[#1F1A12] dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#0E6B63]"
            />
          </div>
        </div>

        <div className="divide-y divide-slate-100 dark:divide-slate-800/70 flex-1 overflow-y-auto max-h-[420px]">
          {filteredContacts.length === 0 ? (
            <div className="p-6 text-center space-y-3">
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                {isAr
                  ? 'لا توجد محادثات مطابقة. يمكنك بدء محادثة جديدة مع أي صديق.'
                  : 'No matching chats. Start a conversation with any friend.'}
              </p>
              <button
                type="button"
                onClick={() => setShowNewChatModal(true)}
                className="px-4 py-2 rounded-xl bg-[#0E6B63]/10 text-[#0E6B63] dark:text-[#5FD0C4] text-xs font-bold cursor-pointer"
              >
                {isAr ? '+ إضافة صديق وبدء محادثة' : '+ Add Contact & Chat'}
              </button>
            </div>
          ) : (
            filteredContacts.map((contact) => {
              const isSelected = contact.id === activeContact?.id;
              const lastMsg = [...messages]
                .reverse()
                .find(
                  (m) =>
                    (m.senderId === currentUser.id &&
                      m.receiverId === contact.id) ||
                    (m.senderId === contact.id &&
                      m.receiverId === currentUser.id)
                );

              return (
                <button
                  key={contact.id}
                  type="button"
                  onClick={() => setSelectedContactId(contact.id)}
                  className={`w-full text-start p-3.5 flex items-center gap-3 transition-colors cursor-pointer ${
                    isSelected
                      ? 'bg-[#0E6B63]/10 dark:bg-[#0E6B63]/20'
                      : 'hover:bg-slate-50 dark:hover:bg-slate-800/50'
                  }`}
                >
                  <div className="relative shrink-0">
                    <UserAvatar
                      avatarKey={contact.avatarKey}
                      customAvatarUrl={contact.customAvatarUrl}
                      name={contact.name}
                      size="md"
                    />
                    {contact.isOnline &&
                      contact.settings?.showOnlineStatus !== false && (
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-[#151D1C] absolute bottom-0 end-0" />
                      )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-bold text-xs sm:text-sm text-[#1F1A12] dark:text-white truncate flex items-center gap-1">
                        <span>{isAr ? contact.name : contact.nameEn}</span>
                        {contact.isVerified && (
                          <CheckCircle2 className="w-3.5 h-3.5 text-[#0E6B63] dark:text-[#5FD0C4] shrink-0" />
                        )}
                      </span>
                      {lastMsg && (
                        <span className="text-[10px] font-mono tabular-nums text-slate-400">
                          {lastMsg.createdAt}
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                      {lastMsg
                        ? lastMsg.text
                        : contact.country
                        ? `📍 ${contact.country}${
                            contact.city ? ` · ${contact.city}` : ''
                          }`
                        : isAr
                        ? 'اضغط لبدء المراسلة...'
                        : 'Tap to message...'}
                    </p>
                  </div>
                </button>
              );
            })
          )}
        </div>
      </div>

      {/* Active Conversation Thread */}
      {activeContact ? (
        <div className="md:col-span-8 flex flex-col justify-between">
          <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-3">
              <UserAvatar
                avatarKey={activeContact.avatarKey}
                customAvatarUrl={activeContact.customAvatarUrl}
                name={activeContact.name}
                size="md"
              />
              <div>
                <div className="font-bold text-sm text-[#1F1A12] dark:text-white flex items-center gap-1.5">
                  <span>
                    {isAr ? activeContact.name : activeContact.nameEn}
                  </span>
                  {activeContact.isVerified && (
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#0E6B63] dark:text-[#5FD0C4]" />
                  )}
                </div>
                <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-2">
                  <span dir="ltr">{activeContact.handle}</span>
                  {activeContact.country && (
                    <span className="inline-flex items-center gap-0.5 text-[11px] text-[#0E6B63] dark:text-[#5FD0C4] font-bold">
                      <MapPin className="w-3 h-3 text-[#F2A93B]" />
                      {activeContact.country}
                    </span>
                  )}
                </div>
              </div>
            </div>

            {onToggleFriend && (
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => onToggleFriend(activeContact.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer ${
                    (currentUser.friendIds || []).includes(activeContact.id)
                      ? 'bg-emerald-600 text-white'
                      : 'bg-[#0E6B63]/10 text-[#0E6B63] dark:text-[#5FD0C4]'
                  }`}
                >
                  {(currentUser.friendIds || []).includes(activeContact.id)
                    ? isAr
                      ? 'صديق ✓'
                      : 'Friends ✓'
                    : isAr
                    ? '+ إضافة صديق'
                    : '+ Add Friend'}
                </button>
              </div>
            )}
          </div>

          <div className="flex-1 p-4 sm:p-5 space-y-3 overflow-y-auto max-h-[380px]">
            {conversationMessages.length === 0 ? (
              <div className="text-center py-12 text-sm text-slate-500 dark:text-slate-400">
                {isAr
                  ? `ابدأ المحادثة مع ${activeContact.name} الآن بالرسائل النصية أو الصوتية!`
                  : `No messages with ${activeContact.nameEn} yet. Say hello!`}
              </div>
            ) : (
              conversationMessages.map((m) => {
                const isMine = m.senderId === currentUser.id;
                return (
                  <div
                    key={m.id}
                    className={`flex flex-col ${
                      isMine ? 'items-end' : 'items-start'
                    }`}
                  >
                    <div
                      className={`max-w-[82%] rounded-2xl px-4 py-2.5 text-sm space-y-2 ${
                        isMine
                          ? 'bg-[#0E6B63] text-white'
                          : 'bg-slate-100 dark:bg-slate-800 text-[#1F1A12] dark:text-slate-100'
                      }`}
                    >
                      {m.text && (
                        <p className="leading-relaxed selectable-text">
                          {m.text}
                        </p>
                      )}
                      {m.audioUrl && (
                        <div className="min-w-[210px]">
                          <AudioWavePlayer
                            audioUrl={m.audioUrl}
                            title={isAr ? 'رسالة صوتية' : 'Voice Message'}
                          />
                        </div>
                      )}
                    </div>
                    <span className="text-[11px] font-mono tabular-nums text-slate-400 mt-1 px-1">
                      {m.createdAt}
                    </span>
                  </div>
                );
              })
            )}
          </div>

          {/* Message Input or Privacy Lock Notice */}
          {!canSendMessageToActiveContact ? (
            <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-rose-50/70 dark:bg-rose-950/30 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-xs font-bold text-rose-700 dark:text-rose-300">
                <Lock className="w-4 h-4 shrink-0" />
                <span>
                  {activeContactMsgPolicy === 'nobody'
                    ? isAr
                      ? 'هذا المستخدم قام بإغلاق استقبال الرسائل الخاصة من الإعدادات ولا يقبل رسائل من أي شخص حالياً.'
                      : 'This user has disabled incoming direct messages in their privacy settings.'
                    : isAr
                    ? 'هذا المستخدم يستقبل الرسائل من الأصدقاء والمتابعين فقط.'
                    : 'This user only accepts messages from friends and followers.'}
                </span>
              </div>
              {activeContactMsgPolicy === 'followers' &&
                onToggleFriend &&
                onToggleFollow && (
                  <button
                    type="button"
                    onClick={() => {
                      onToggleFriend(activeContact.id);
                      onToggleFollow(activeContact.id);
                    }}
                    className="px-3.5 py-1.5 rounded-xl bg-[#0E6B63] text-white text-xs font-extrabold cursor-pointer"
                  >
                    {isAr
                      ? 'إضافة صديق ومتابعة للمراسلة'
                      : 'Add Friend & Follow to Message'}
                  </button>
                )}
            </div>
          ) : (
            <>
              {(isRecording || recordedAudioUrl) && (
                <div className="px-4 py-2 bg-slate-50 dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2">
                  {isRecording ? (
                    <>
                      <div className="flex items-center gap-2 text-xs font-bold text-red-600 dark:text-red-400">
                        <span className="w-2.5 h-2.5 rounded-full bg-red-600 animate-ping" />
                        <span>
                          {isAr
                            ? `جاري تسجيل رسالة صوتية... (${recordSeconds} ث)`
                            : `Recording voice message... (${recordSeconds}s)`}
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={stopVoiceRecord}
                        className="px-3 py-1 rounded-lg bg-red-600 text-white text-xs font-bold flex items-center gap-1 cursor-pointer"
                      >
                        <Square className="w-3 h-3" />
                        <span>{isAr ? 'إيقاف' : 'Stop'}</span>
                      </button>
                    </>
                  ) : (
                    recordedAudioUrl && (
                      <>
                        <div className="flex-1">
                          <AudioWavePlayer
                            audioUrl={recordedAudioUrl}
                            durationLabel={`0:${String(
                              Math.max(1, recordSeconds)
                            ).padStart(2, '0')}`}
                            title={
                              isAr
                                ? 'تسجيل صوتي جاهز للإرسال'
                                : 'Voice note ready'
                            }
                            compact
                          />
                        </div>
                        <button
                          type="button"
                          onClick={() => setRecordedAudioUrl(null)}
                          className="p-1.5 rounded-lg text-red-600 hover:bg-red-50 dark:hover:bg-red-950/30 cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </>
                    )
                  )}
                </div>
              )}

              <form
                onSubmit={handleSubmit}
                className="p-4 border-t border-slate-200 dark:border-slate-800 flex items-center gap-2"
              >
                <button
                  type="button"
                  onClick={isRecording ? stopVoiceRecord : startVoiceRecord}
                  title={isAr ? 'تسجيل رسالة صوتية' : 'Record voice message'}
                  className={`min-h-[44px] min-w-[44px] rounded-xl flex items-center justify-center transition-colors cursor-pointer ${
                    isRecording
                      ? 'bg-red-600 text-white'
                      : 'bg-slate-100 dark:bg-slate-800 text-[#0E6B63] dark:text-[#5FD0C4] hover:bg-slate-200'
                  }`}
                >
                  <Mic className="w-4 h-4" />
                </button>
                <input
                  type="text"
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  placeholder={
                    isAr
                      ? `اكتب رسالة إلى ${activeContact.name}...`
                      : `Message ${activeContact.nameEn}...`
                  }
                  className="flex-1 min-h-[44px] px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-900 text-sm text-[#1F1A12] dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#0E6B63]"
                />
                <button
                  type="submit"
                  className="min-h-[44px] px-4 py-2 rounded-xl bg-[#0E6B63] hover:bg-[#0B5650] text-white text-sm font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span>{isAr ? 'إرسال' : 'Send'}</span>
                </button>
              </form>
            </>
          )}
        </div>
      ) : (
        <div className="md:col-span-8 flex flex-col items-center justify-center p-8 text-center space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-[#0E6B63]/10 text-[#0E6B63] dark:text-[#5FD0C4] flex items-center justify-center">
            <MessageSquare className="w-7 h-7" />
          </div>
          <div className="max-w-sm space-y-1.5">
            <h3 className="text-base font-extrabold text-[#1F1A12] dark:text-white">
              {isAr
                ? 'ابدأ محادثاتك الخاصة على ونس'
                : 'Start Private Conversations on WANAS'}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              {isAr
                ? 'اختر أي صديق من القائمة أو أضف صديقاً جديداً للتواصل الفوري.'
                : 'Select a contact or add a friend to start messaging.'}
            </p>
          </div>
          <button
            type="button"
            onClick={() => setShowNewChatModal(true)}
            className="min-h-[44px] px-5 py-2.5 rounded-xl bg-[#0E6B63] hover:bg-[#0B5650] text-white text-xs font-bold flex items-center gap-2 cursor-pointer"
          >
            <UserPlus className="w-4 h-4" />
            <span>
              {isAr ? 'بدء محادثة جديدة الآن' : 'Start New Conversation'}
            </span>
          </button>
        </div>
      )}

      {showNewChatModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-[#151D1C] border border-slate-200 dark:border-slate-800 rounded-3xl max-w-md w-full p-6 space-y-4">
            <h3 className="text-base font-extrabold text-[#1F1A12] dark:text-white">
              {isAr
                ? 'بدء محادثة جديدة / إضافة صديق'
                : 'Start New Chat / Add Friend'}
            </h3>
            <form onSubmit={handleCreateContact} className="space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 mb-1">
                  {isAr ? 'اسم الصديق' : 'Friend Name'}
                </label>
                <input
                  type="text"
                  required
                  value={newContactName}
                  onChange={(e) => setNewContactName(e.target.value)}
                  placeholder={
                    isAr ? 'اكتب الاسم الكامل...' : 'Enter full name...'
                  }
                  className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-transparent text-sm text-[#1F1A12] dark:text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 mb-1">
                  {isAr
                    ? 'المعرف (@handle) أو رقم الهاتف'
                    : 'Handle (@username) or Phone'}
                </label>
                <input
                  type="text"
                  value={newContactHandle}
                  onChange={(e) => setNewContactHandle(e.target.value)}
                  placeholder={
                    isAr ? 'مثال: @ahmed أو 010xxxxxxx' : 'e.g., @ahmed or phone'
                  }
                  dir="ltr"
                  className="w-full min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-transparent text-sm text-[#1F1A12] dark:text-white"
                />
              </div>
              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowNewChatModal(false)}
                  className="min-h-[44px] px-4 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="min-h-[44px] px-5 py-2 rounded-xl bg-[#0E6B63] hover:bg-[#0B5650] text-white text-xs font-bold cursor-pointer"
                >
                  {isAr ? 'فتح المحادثة' : 'Open Chat'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
