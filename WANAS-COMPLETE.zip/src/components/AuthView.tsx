import React, { useState } from 'react';
import {
  Mail,
  Phone,
  Lock,
  User as UserIcon,
  Eye,
  EyeOff,
  LogIn,
  UserPlus,
  Sun,
  Moon,
  Globe,
  Check,
  Image as ImageIcon,
  Camera,
  FolderOpen,
  MapPin,
  Sparkles,
} from 'lucide-react';
import type { Language, User, CoverKey } from '../types.ts';
import {
  DEFAULT_USER_SETTINGS,
  AVAILABLE_COUNTRIES,
  AVAILABLE_INTERESTS,
} from '../defaultData.ts';
import {
  UserAvatar,
  CoverBannerVisual,
  WanasBrandIcon,
} from './VisualAssets.tsx';
import { readFileAsCompressedDataUrl, getApiUrl } from '../utils/mediaUtils.ts';
import { setToken } from '../utils/auth.ts';

interface AuthViewProps {
  lang: Language;
  darkMode: boolean;
  users: User[];
  onToggleDarkMode: (dark: boolean) => void;
  onToggleLang: () => void;
  onLoginSuccess: (user: User) => void;
  onRegisterSuccess: (newUser: User) => void;
}

const COUNTRY_CODES = [
  { code: '+20', labelAr: 'مصر (+20)', labelEn: 'Egypt (+20)' },
  { code: '+966', labelAr: 'السعودية (+966)', labelEn: 'Saudi Arabia (+966)' },
  { code: '+971', labelAr: 'الإمارات (+971)', labelEn: 'UAE (+971)' },
  { code: '+965', labelAr: 'الكويت (+965)', labelEn: 'Kuwait (+965)' },
  { code: '+962', labelAr: 'الأردن (+962)', labelEn: 'Jordan (+962)' },
  { code: '+964', labelAr: 'العراق (+964)', labelEn: 'Iraq (+964)' },
  { code: '+212', labelAr: 'المغرب (+212)', labelEn: 'Morocco (+212)' },
];

const COVER_OPTIONS: { key: CoverKey; labelAr: string; labelEn: string }[] = [
  { key: 'royal_majlis', labelAr: 'المجلس الملكي', labelEn: 'Royal Majlis' },
  { key: 'teal_horizon', labelAr: 'الأفق الفيروزي', labelEn: 'Teal Horizon' },
  { key: 'cairo_nights', labelAr: 'ليالي القاهرة', labelEn: 'Cairo Nights' },
  { key: 'tech_oasis', labelAr: 'الواحة الرقمية', labelEn: 'Tech Oasis' },
];

export const AuthView: React.FC<AuthViewProps> = ({
  lang,
  darkMode,
  users,
  onToggleDarkMode,
  onToggleLang,
  onLoginSuccess,
  onRegisterSuccess,
}) => {
  const isAr = lang === 'ar';

  const [authMode, setAuthMode] = useState<'login' | 'register'>('register');
  const [contactMethod, setContactMethod] = useState<'email' | 'phone'>('email');

  const [emailInput, setEmailInput] = useState<string>('');
  const [countryCode, setCountryCode] = useState<string>('+20');
  const [phoneInput, setPhoneInput] = useState<string>('');
  const [passwordInput, setPasswordInput] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);

  const [fullNameInput, setFullNameInput] = useState<string>('');
  const [handleInput, setHandleInput] = useState<string>('');
  const [bioInput, setBioInput] = useState<string>('');
  const [selectedCountry, setSelectedCountry] = useState<string>('مصر');
  const [selectedCity, setSelectedCity] = useState<string>('القاهرة');
  const [selectedInterests, setSelectedInterests] = useState<string[]>([
    'البرمجة والتقنية',
    'الأخبار والمجتمع',
  ]);
  const [selectedCover, setSelectedCover] = useState<CoverKey>('royal_majlis');
  const [customAvatarUrl, setCustomAvatarUrl] = useState<string | undefined>(
    undefined
  );
  const [customCoverUrl, setCustomCoverUrl] = useState<string | undefined>(
    undefined
  );
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const activeCountryObj =
    AVAILABLE_COUNTRIES.find((c) => c.nameAr === selectedCountry) ||
    AVAILABLE_COUNTRIES[0];

  const handleToggleInterest = (labelAr: string) => {
    setSelectedInterests((prev) =>
      prev.includes(labelAr)
        ? prev.filter((item) => item !== labelAr)
        : [...prev, labelAr]
    );
  };

  const handleAvatarFileChange = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressed = await readFileAsCompressedDataUrl(file, 'avatar');
      setCustomAvatarUrl(compressed);
    } catch {
      // ignore
    }
    e.target.value = '';
  };

  const handleCoverFileChange = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressed = await readFileAsCompressedDataUrl(file, 'cover');
      setCustomCoverUrl(compressed);
    } catch {
      // ignore
    }
    e.target.value = '';
  };

  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  const explainAuthError = (code: string | undefined, status: number): string => {
    if (code === 'invalid_credentials')
      return isAr
        ? 'البريد/الهاتف أو كلمة المرور غير صحيحة. لو مفيش عندك حساب اختر «إنشاء حساب».'
        : 'Wrong email/phone or password. No account yet? Choose "Create account".';
    if (code === 'account_exists')
      return isAr
        ? 'يوجد حساب بنفس البريد أو رقم الهاتف. سجّل الدخول بدلاً من ذلك.'
        : 'An account with this email/phone already exists. Please log in instead.';
    if (code === 'too_many_attempts' || status === 429)
      return isAr
        ? 'محاولات كثيرة. انتظر قليلاً ثم حاول مرة أخرى.'
        : 'Too many attempts. Please wait a bit and try again.';
    if (code === 'weak_password')
      return isAr ? 'كلمة المرور يجب ألا تقل عن ٦ أحرف.' : 'Password must be at least 6 characters.';
    return isAr ? 'حدث خطأ غير متوقع، حاول مرة أخرى.' : 'Something went wrong, please try again.';
  };

  const callAuthApi = async (path: string, body: unknown) => {
    setIsSubmitting(true);
    try {
      const res = await fetch(getApiUrl(path), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setErrorMsg(explainAuthError(data?.error, res.status));
        return null;
      }
      return data as { user: User; token: string };
    } catch {
      setErrorMsg(
        isAr
          ? 'تعذر الاتصال بالسيرفر. تأكد من اتصال الإنترنت ثم حاول مرة أخرى.'
          : 'Could not reach the server. Check your internet connection and try again.'
      );
      return null;
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;
    setErrorMsg(null);

    const trimmedEmail = emailInput.trim().toLowerCase();
    const cleanPhone = phoneInput.trim().replace(/\s+/g, '');
    const fullPhone = cleanPhone.startsWith('+')
      ? cleanPhone
      : `${countryCode}${cleanPhone}`;
    const trimmedPass = passwordInput.trim();

    if (contactMethod === 'email') {
      if (!trimmedEmail || !trimmedEmail.includes('@')) {
        setErrorMsg(
          isAr
            ? 'يرجى إدخال بريد إلكتروني صحيح (مثال: name@example.com).'
            : 'Please enter a valid email address.'
        );
        return;
      }
    } else {
      if (!cleanPhone || cleanPhone.length < 7) {
        setErrorMsg(
          isAr
            ? 'يرجى إدخال رقم هاتف صحيح مكون من ٧ أرقام على الأقل.'
            : 'Please enter a valid phone number (at least 7 digits).'
        );
        return;
      }
    }

    if (!trimmedPass || trimmedPass.length < 6) {
      setErrorMsg(
        isAr
          ? 'يرجى إدخال كلمة مرور لا تقل عن ٦ أحرف أو أرقام.'
          : 'Please enter a password of at least 6 characters.'
      );
      return;
    }

    if (authMode === 'login') {
      const result = await callAuthApi('/api/auth/login', {
        email: contactMethod === 'email' ? trimmedEmail : undefined,
        phone: contactMethod === 'phone' ? fullPhone : undefined,
        password: trimmedPass,
      });
      if (result) {
        setToken(result.token);
        onLoginSuccess(result.user);
      }
      return;
    }

    const trimmedName = fullNameInput.trim();
    if (!trimmedName || trimmedName.length < 2) {
      setErrorMsg(
        isAr
          ? 'يرجى إدخال الاسم الكامل لإنشاء الحساب.'
          : 'Please enter your full name to create an account.'
      );
      return;
    }

    const rawHandle =
      handleInput.trim().replace(/^@/, '') ||
      (contactMethod === 'email'
        ? trimmedEmail.split('@')[0]
        : `user_${cleanPhone.slice(-4)}`);

    const newUser: User = {
      id: `u_${Date.now()}`,
      name: trimmedName,
      nameEn: trimmedName,
      handle: `@${rawHandle}`,
      avatarKey: 'abdallah',
      customAvatarUrl,
      coverKey: selectedCover,
      customCoverUrl,
      email: contactMethod === 'email' ? trimmedEmail : undefined,
      phone: contactMethod === 'phone' ? fullPhone : undefined,
      password: trimmedPass,
      role: isAr ? 'عضو في ونس' : 'WANAS Member',
      roleEn: 'WANAS Member',
      bio:
        bioInput.trim() ||
        (isAr
          ? 'أهلاً بكم في صفحتي الرسمية على منصة ونس.'
          : 'Welcome to my official profile on WANAS.'),
      bioEn: bioInput.trim() || 'Welcome to my official profile on WANAS.',
      country: selectedCountry,
      city: selectedCity,
      location: `${selectedCountry} · ${selectedCity}`,
      interests:
        selectedInterests.length > 0
          ? selectedInterests
          : ['البرمجة والتقنية', 'الأخبار والمجتمع'],
      followersCount: 0,
      followingCount: 0,
      friendIds: [],
      followingIds: [],
      isOnline: true,
      settings: { ...DEFAULT_USER_SETTINGS },
    };

    const result = await callAuthApi('/api/auth/signup', newUser);
    if (result) {
      setToken(result.token);
      onRegisterSuccess(result.user);
    }
  };

  return (
    <div
      className={`min-h-screen transition-colors duration-200 ${
        darkMode
          ? 'dark bg-[#0F1514] text-[#FAF7F2]'
          : 'bg-[#FAF7F2] text-[#1F1A12]'
      }`}
    >
      {/* Top Attribution & Controls Header */}
      <header className="sticky top-0 z-30 bg-white/95 dark:bg-[#0F1514]/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <WanasBrandIcon className="w-10 h-10" />
            <div>
              <div className="text-lg font-extrabold tracking-tight text-[#0E6B63] dark:text-[#5FD0C4] leading-none">
                WANAS · ونس
              </div>
              <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400 mt-0.5">
                ABD.ALLAH ZOHAIR OMARA
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="inline-flex items-center p-1 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
              <button
                type="button"
                onClick={() => onToggleDarkMode(false)}
                className={`min-h-[30px] px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer ${
                  !darkMode
                    ? 'bg-white text-[#F2A93B] shadow-xs'
                    : 'text-slate-500 dark:text-slate-400'
                }`}
              >
                <Sun className="w-3.5 h-3.5" />
                <span>{isAr ? 'نهاري' : 'Light'}</span>
              </button>
              <button
                type="button"
                onClick={() => onToggleDarkMode(true)}
                className={`min-h-[30px] px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer ${
                  darkMode
                    ? 'bg-[#0F1514] text-[#5FD0C4] shadow-xs'
                    : 'text-slate-500 dark:text-slate-400'
                }`}
              >
                <Moon className="w-3.5 h-3.5" />
                <span>{isAr ? 'ليلي' : 'Dark'}</span>
              </button>
            </div>

            <button
              type="button"
              onClick={onToggleLang}
              className="min-h-[34px] px-3 py-1 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1.5 cursor-pointer"
            >
              <Globe className="w-3.5 h-3.5 text-[#0E6B63] dark:text-[#5FD0C4]" />
              <span>{isAr ? 'English' : 'العربية'}</span>
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-2xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-5">
        {/* Official Brand Hero Card: Above Logo -> Built by ABD.ALLAH ZOHAIR OMARA | Below Logo -> WANAS */}
        <div className="rounded-3xl p-6 bg-gradient-to-b from-[#0E6B63] via-[#0B4F49] to-[#0F1514] text-white text-center shadow-xl border border-[#5FD0C4]/25 space-y-3">
          {/* Above Logo: تم بناء وبرمجة هذا التطبيق بواسطة ABD.ALLAH ZOHAIR OMARA */}
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-black/30 border border-[#F2A93B]/40 text-[#F2A93B] text-xs font-extrabold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>تم بناء وبرمجة هذا التطبيق بواسطة</span>
            </div>
            <div
              dir="ltr"
              className="text-sm sm:text-base font-black tracking-wider text-white uppercase"
            >
              ABD.ALLAH ZOHAIR OMARA
            </div>
          </div>

          {/* Official Logo + English App Name Below */}
          <div className="flex flex-col items-center justify-center pt-1">
            <WanasBrandIcon className="w-20 h-20 rounded-2xl shadow-lg ring-3 ring-[#F2A93B]/60" />
            <div
              dir="ltr"
              className="mt-2.5 text-2xl sm:text-3xl font-black tracking-[0.2em] text-white"
            >
              WANAS
            </div>
            <p className="text-xs text-teal-100/90 mt-0.5">
              {isAr
                ? 'منصة ونس الرسمية للتواصل الاجتماعي والمجالس الصوتية'
                : 'WANAS Official Social Networking Platform'}
            </p>
          </div>
        </div>

        <div className="rounded-3xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xl">
          {/* Official Brand Cover Banner */}
          <CoverBannerVisual
            coverKey={selectedCover}
            customCoverUrl={customCoverUrl}
            heightClass="h-44 sm:h-52"
          >
            <div className="absolute inset-0 bg-gradient-to-t from-[#0F1514]/90 via-[#0F1514]/35 to-transparent p-4 sm:p-6 flex flex-col justify-between">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="px-2.5 py-1 rounded-xl bg-black/50 text-white text-[11px] font-bold">
                  {isAr ? 'تخصيص غلاف وصورة حسابك' : 'Customize Cover & Avatar'}
                </span>
                <div className="flex flex-wrap items-center gap-1 bg-black/55 backdrop-blur-md p-1 rounded-xl border border-white/10">
                  <ImageIcon className="w-3.5 h-3.5 text-[#F2A93B] ms-1.5" />
                  {COVER_OPTIONS.map((c) => (
                    <button
                      key={c.key}
                      type="button"
                      onClick={() => {
                        setSelectedCover(c.key);
                        setCustomCoverUrl(undefined);
                      }}
                      className={`px-2 py-1 rounded-lg text-[11px] font-bold transition-colors cursor-pointer ${
                        selectedCover === c.key && !customCoverUrl
                          ? 'bg-[#0E6B63] text-white'
                          : 'text-slate-300 hover:text-white'
                      }`}
                    >
                      {isAr ? c.labelAr : c.labelEn}
                    </button>
                  ))}
                  <label className="relative overflow-hidden px-2 py-1 rounded-lg text-[11px] font-bold bg-[#F2A93B] text-[#1F1A12] flex items-center gap-1 cursor-pointer">
                    <FolderOpen className="w-3 h-3" />
                    <span>{isAr ? 'غلاف من الهاتف' : 'Custom Cover'}</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleCoverFileChange}
                      className="absolute inset-0 opacity-0 cursor-pointer"
                    />
                  </label>
                </div>
              </div>

              <div className="flex items-center gap-3.5">
                <label
                  className="relative ring-3 ring-[#F2A93B] rounded-full cursor-pointer group overflow-hidden"
                  title={isAr ? 'تغيير الصورة الشخصية' : 'Change Profile Photo'}
                >
                  <UserAvatar
                    customAvatarUrl={customAvatarUrl}
                    name={fullNameInput || 'WANAS'}
                    size="lg"
                  />
                  <span className="absolute -bottom-1 -end-1 w-6 h-6 rounded-full bg-[#0E6B63] text-white flex items-center justify-center shadow-md border border-white">
                    <Camera className="w-3.5 h-3.5" />
                  </span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleAvatarFileChange}
                    className="absolute inset-0 opacity-0 cursor-pointer"
                  />
                </label>
                <div>
                  <h2 className="text-lg sm:text-xl font-extrabold text-white">
                    {isAr ? 'تسجيل الدخول وإنشاء الحساب' : 'Sign In & Create Account'}
                  </h2>
                  <p className="text-xs text-slate-200 mt-0.5">
                    {isAr
                      ? 'سجّل بالبريد الإلكتروني أو رقم الهاتف للتواصل مع الجميع'
                      : 'Sign in via Email or Phone Number'}
                  </p>
                </div>
              </div>
            </div>
          </CoverBannerVisual>

          <div className="p-5 sm:p-7 space-y-5">
            {/* Switch Tabs: إنشاء حساب جديد / تسجيل الدخول */}
            <div className="grid grid-cols-2 p-1.5 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
              <button
                type="button"
                onClick={() => {
                  setAuthMode('register');
                  setErrorMsg(null);
                }}
                className={`min-h-[44px] py-2.5 px-4 rounded-xl text-sm font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  authMode === 'register'
                    ? 'bg-[#0E6B63] text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                <UserPlus className="w-4 h-4" />
                <span>{isAr ? 'إنشاء حساب جديد' : 'Create Account'}</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setAuthMode('login');
                  setErrorMsg(null);
                }}
                className={`min-h-[44px] py-2.5 px-4 rounded-xl text-sm font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  authMode === 'login'
                    ? 'bg-[#0E6B63] text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                <LogIn className="w-4 h-4" />
                <span>{isAr ? 'تسجيل الدخول' : 'Sign In'}</span>
              </button>
            </div>

            {/* Method Selector: Email vs Phone */}
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => {
                  setContactMethod('email');
                  setErrorMsg(null);
                }}
                className={`min-h-[42px] px-4 py-2.5 rounded-xl border text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer ${
                  contactMethod === 'email'
                    ? 'border-[#0E6B63] bg-[#0E6B63]/10 text-[#0E6B63] dark:text-[#5FD0C4]'
                    : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                }`}
              >
                <Mail className="w-4 h-4" />
                <span>{isAr ? 'بالبريد الإلكتروني' : 'Via Email'}</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setContactMethod('phone');
                  setErrorMsg(null);
                }}
                className={`min-h-[42px] px-4 py-2.5 rounded-xl border text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer ${
                  contactMethod === 'phone'
                    ? 'border-[#0E6B63] bg-[#0E6B63]/10 text-[#0E6B63] dark:text-[#5FD0C4]'
                    : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                }`}
              >
                <Phone className="w-4 h-4" />
                <span>{isAr ? 'برقم الهاتف' : 'Via Phone'}</span>
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {authMode === 'register' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                      {isAr ? 'الاسم الكامل *' : 'Full Name *'}
                    </label>
                    <div className="relative">
                      <UserIcon className="w-4 h-4 text-slate-400 absolute top-1/2 -translate-y-1/2 start-3.5" />
                      <input
                        type="text"
                        value={fullNameInput}
                        onChange={(e) => setFullNameInput(e.target.value)}
                        placeholder={isAr ? 'اكتب اسمك الكامل' : 'Your full name'}
                        className="w-full ps-10 pe-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 text-sm focus:outline-none focus:border-[#0E6B63]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                      {isAr ? 'اسم المستخدم (اختياري)' : 'Username (Optional)'}
                    </label>
                    <input
                      type="text"
                      dir="ltr"
                      value={handleInput}
                      onChange={(e) => setHandleInput(e.target.value)}
                      placeholder="@username"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 text-sm focus:outline-none focus:border-[#0E6B63]"
                    />
                  </div>
                </div>
              )}

              {contactMethod === 'email' ? (
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    {isAr ? 'البريد الإلكتروني *' : 'Email Address *'}
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute top-1/2 -translate-y-1/2 start-3.5" />
                    <input
                      type="email"
                      dir="ltr"
                      value={emailInput}
                      onChange={(e) => setEmailInput(e.target.value)}
                      placeholder="name@example.com"
                      className="w-full ps-10 pe-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 text-sm focus:outline-none focus:border-[#0E6B63]"
                    />
                  </div>
                </div>
              ) : (
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    {isAr ? 'رقم الهاتف المحمول *' : 'Mobile Phone Number *'}
                  </label>
                  <div className="flex gap-2" dir="ltr">
                    <select
                      value={countryCode}
                      onChange={(e) => setCountryCode(e.target.value)}
                      className="px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs sm:text-sm font-semibold focus:outline-none focus:border-[#0E6B63]"
                    >
                      {COUNTRY_CODES.map((c) => (
                        <option key={c.code} value={c.code}>
                          {isAr ? c.labelAr : c.labelEn}
                        </option>
                      ))}
                    </select>
                    <div className="relative flex-1">
                      <Phone className="w-4 h-4 text-slate-400 absolute top-1/2 -translate-y-1/2 left-3.5" />
                      <input
                        type="tel"
                        value={phoneInput}
                        onChange={(e) => setPhoneInput(e.target.value)}
                        placeholder="1012345678"
                        className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 text-sm focus:outline-none focus:border-[#0E6B63]"
                      />
                    </div>
                  </div>
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  {isAr ? 'كلمة المرور *' : 'Password *'}
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute top-1/2 -translate-y-1/2 start-3.5" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={passwordInput}
                    onChange={(e) => setPasswordInput(e.target.value)}
                    placeholder={
                      isAr ? 'أدخل كلمة المرور الخاصة بك' : 'Enter your password'
                    }
                    className="w-full ps-10 pe-11 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 text-sm focus:outline-none focus:border-[#0E6B63]"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((prev) => !prev)}
                    className="absolute top-1/2 -translate-y-1/2 end-3 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                  >
                    {showPassword ? (
                      <EyeOff className="w-4 h-4" />
                    ) : (
                      <Eye className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </div>

              {authMode === 'register' && (
                <div className="space-y-4 pt-1">
                  {/* Country, Location & Interests for Smart Account Suggestions */}
                  <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-3">
                    <div className="flex items-center gap-1.5 text-xs font-extrabold text-[#0E6B63] dark:text-[#5FD0C4]">
                      <MapPin className="w-4 h-4 text-[#F2A93B]" />
                      <span>
                        {isAr
                          ? 'البلد والموقع والاهتمامات (لاقتراح أشخاص قد تعرفهم)'
                          : 'Country, City & Interests (For People Suggestions)'}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-300 mb-1">
                          {isAr ? 'البلد' : 'Country'}
                        </label>
                        <select
                          value={selectedCountry}
                          onChange={(e) => {
                            const nextCountry = e.target.value;
                            setSelectedCountry(nextCountry);
                            const found = AVAILABLE_COUNTRIES.find(
                              (c) => c.nameAr === nextCountry
                            );
                            if (found) setSelectedCity(found.citiesAr[0]);
                          }}
                          className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                        >
                          {AVAILABLE_COUNTRIES.map((c) => (
                            <option key={c.code} value={c.nameAr}>
                              {isAr ? c.nameAr : c.nameEn}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-300 mb-1">
                          {isAr ? 'المدينة / الموقع' : 'City / Location'}
                        </label>
                        <select
                          value={selectedCity}
                          onChange={(e) => setSelectedCity(e.target.value)}
                          className="w-full px-3 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                        >
                          {activeCountryObj.citiesAr.map((cityAr, idx) => (
                            <option key={cityAr} value={cityAr}>
                              {isAr ? cityAr : activeCountryObj.citiesEn[idx]}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-300 mb-1.5">
                        {isAr ? 'اختر اهتماماتك:' : 'Select Your Interests:'}
                      </label>
                      <div className="flex flex-wrap gap-1.5">
                        {AVAILABLE_INTERESTS.map((item) => {
                          const active = selectedInterests.includes(item.labelAr);
                          return (
                            <button
                              key={item.id}
                              type="button"
                              onClick={() => handleToggleInterest(item.labelAr)}
                              className={`px-2.5 py-1 rounded-xl text-[11px] font-bold transition-colors cursor-pointer ${
                                active
                                  ? 'bg-[#0E6B63] text-white'
                                  : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                              }`}
                            >
                              {isAr ? item.labelAr : item.labelEn}{' '}
                              {active ? '✓' : '+'}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>

                  {/* Profile Photo & Cover Photo Uploaders (Direct File Inputs) */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
                      <label className="block text-xs font-extrabold text-slate-700 dark:text-slate-200">
                        {isAr
                          ? 'الصورة الشخصية (من الهاتف أو الكاميرا)'
                          : 'Profile Picture (Files or Camera)'}
                      </label>
                      <div className="grid grid-cols-2 gap-1.5">
                        <label className="relative overflow-hidden min-h-[36px] px-2.5 py-1.5 rounded-xl bg-[#0E6B63] text-white text-[11px] font-bold flex items-center justify-center gap-1 cursor-pointer">
                          <FolderOpen className="w-3.5 h-3.5" />
                          <span>{isAr ? 'ملفات الهاتف' : 'Files'}</span>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={handleAvatarFileChange}
                            className="absolute inset-0 opacity-0 cursor-pointer"
                          />
                        </label>
                        <label className="relative overflow-hidden min-h-[36px] px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 text-[11px] font-bold flex items-center justify-center gap-1 cursor-pointer">
                          <Camera className="w-3.5 h-3.5 text-[#F2A93B]" />
                          <span>{isAr ? 'الكاميرا' : 'Camera'}</span>
                          <input
                            type="file"
                            accept="image/*"
                            capture="user"
                            onChange={handleAvatarFileChange}
                            className="absolute inset-0 opacity-0 cursor-pointer"
                          />
                        </label>
                      </div>
                      {customAvatarUrl && (
                        <div className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400">
                          {isAr
                            ? 'تم اختيار الصورة الشخصية ✓'
                            : 'Profile photo selected ✓'}
                        </div>
                      )}
                    </div>

                    <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
                      <label className="block text-xs font-extrabold text-slate-700 dark:text-slate-200">
                        {isAr
                          ? 'صورة الغلاف (الكاڤر من الهاتف أو الكاميرا)'
                          : 'Cover Photo (Files or Camera)'}
                      </label>
                      <div className="grid grid-cols-2 gap-1.5">
                        <label className="relative overflow-hidden min-h-[36px] px-2.5 py-1.5 rounded-xl bg-[#0E6B63] text-white text-[11px] font-bold flex items-center justify-center gap-1 cursor-pointer">
                          <FolderOpen className="w-3.5 h-3.5" />
                          <span>{isAr ? 'ملفات الهاتف' : 'Files'}</span>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={handleCoverFileChange}
                            className="absolute inset-0 opacity-0 cursor-pointer"
                          />
                        </label>
                        <label className="relative overflow-hidden min-h-[36px] px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 text-[11px] font-bold flex items-center justify-center gap-1 cursor-pointer">
                          <Camera className="w-3.5 h-3.5 text-[#F2A93B]" />
                          <span>{isAr ? 'الكاميرا' : 'Camera'}</span>
                          <input
                            type="file"
                            accept="image/*"
                            capture="environment"
                            onChange={handleCoverFileChange}
                            className="absolute inset-0 opacity-0 cursor-pointer"
                          />
                        </label>
                      </div>
                      {customCoverUrl && (
                        <div className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400">
                          {isAr
                            ? 'تم اختيار صورة الغلاف ✓'
                            : 'Cover photo selected ✓'}
                        </div>
                      )}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      {isAr ? 'السيرة الذاتية (اختياري)' : 'Short Bio (Optional)'}
                    </label>
                    <input
                      type="text"
                      value={bioInput}
                      onChange={(e) => setBioInput(e.target.value)}
                      placeholder={isAr ? 'نبذة قصيرة عنك...' : 'Short bio...'}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 text-xs sm:text-sm focus:outline-none focus:border-[#0E6B63]"
                    />
                  </div>
                </div>
              )}

              {errorMsg && (
                <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-xs font-bold text-rose-700 dark:text-rose-300">
                  {errorMsg}
                </div>
              )}

              <button
                type="submit"
                className="w-full min-h-[48px] py-3 px-6 rounded-xl bg-[#0E6B63] hover:bg-[#0b5650] text-white font-bold text-sm sm:text-base shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <Check className="w-5 h-5 text-[#F2A93B]" />
                <span>
                  {authMode === 'register'
                    ? isAr
                      ? 'إنشاء الحساب والدخول إلى ونس'
                      : 'Create Account & Enter WANAS'
                    : isAr
                    ? 'تسجيل الدخول إلى ونس'
                    : 'Sign In to WANAS'}
                </span>
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
