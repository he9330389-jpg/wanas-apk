import { useCallback, useEffect, useRef, useState } from 'react';
import { realtime } from '../utils/realtime.ts';
import { getApiUrl } from '../utils/mediaUtils.ts';
import type { MajlisRoom } from '../types.ts';

/**
 * Real voice for WANAS Majlis rooms — WebRTC audio mesh with the WANAS server as the signalling channel.
 *
 *  - Speakers/hosts publish their microphone; listeners only receive.
 *  - A peer connection exists between two members whenever at least one of them can speak.
 *  - "Perfect negotiation" handles simultaneous offers; ICE restarts recover from network changes.
 *  - Mute/unmute is driven by the server state, so a host muting you really silences your mic.
 *  - Speaking indicators come from analysing the real audio levels (not a fake animation).
 */

type IceServer = { urls: string | string[]; username?: string; credential?: string };

const FALLBACK_ICE: IceServer[] = [{ urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'] }];
let iceCache: { at: number; servers: IceServer[] } | null = null;

async function loadIceServers(): Promise<IceServer[]> {
  if (iceCache && Date.now() - iceCache.at < 5 * 60 * 1000) return iceCache.servers;
  try {
    const res = await fetch(getApiUrl('/api/rtc-config'));
    if (res.ok) {
      const j = (await res.json()) as { iceServers?: IceServer[] };
      if (Array.isArray(j.iceServers) && j.iceServers.length) {
        iceCache = { at: Date.now(), servers: j.iceServers };
        return j.iceServers;
      }
    }
  } catch {
    // fall through to the public STUN servers
  }
  return FALLBACK_ICE;
}

interface Peer {
  id: string;
  pc: RTCPeerConnection;
  polite: boolean;
  makingOffer: boolean;
  ignoreOffer: boolean;
  sender: RTCRtpSender;
  audio: HTMLAudioElement | null;
  disconnectTimer: number | null;
}

interface Meter {
  analyser: AnalyserNode;
  data: Uint8Array<ArrayBuffer>;
  source: MediaStreamAudioSourceNode;
  lastLoud: number;
}

export interface RoomVoiceState {
  isMember: boolean;
  canSpeak: boolean;
  isMuted: boolean;
  speaking: Record<string, boolean>;
  micError: 'denied' | 'unsupported' | null;
  audioBlocked: boolean;
  resumeAudio: () => void;
  connected: number; // how many peers currently have a live audio link
}

export function useRoomVoice(room: MajlisRoom | null, meId: string): RoomVoiceState {
  const me = room?.participants.find((p) => p.userId === meId) || null;
  const isMember = Boolean(room && me);
  const canSpeak = Boolean(me && me.role !== 'listener');
  const isMuted = me ? me.isMuted : true;

  const [speaking, setSpeaking] = useState<Record<string, boolean>>({});
  const [micError, setMicError] = useState<'denied' | 'unsupported' | null>(null);
  const [audioBlocked, setAudioBlocked] = useState(false);
  const [connected, setConnected] = useState(0);

  const peersRef = useRef<Map<string, Peer>>(new Map());
  const iceRef = useRef<IceServer[]>(FALLBACK_ICE);
  const iceReadyRef = useRef<Promise<void> | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const trackRef = useRef<MediaStreamTrack | null>(null);
  const acRef = useRef<AudioContext | null>(null);
  const metersRef = useRef<Map<string, Meter>>(new Map());
  const roomRef = useRef<MajlisRoom | null>(room);
  roomRef.current = room;
  const micStateRef = useRef({ canSpeak, isMuted });
  micStateRef.current = { canSpeak, isMuted };

  const getAudioContext = useCallback(() => {
    if (!acRef.current) {
      const Ctor = window.AudioContext || (window as any).webkitAudioContext;
      if (!Ctor) return null;
      acRef.current = new Ctor();
    }
    if (acRef.current.state === 'suspended') acRef.current.resume().catch(() => {});
    return acRef.current;
  }, []);

  const addMeter = useCallback(
    (id: string, stream: MediaStream) => {
      const ac = getAudioContext();
      if (!ac) return;
      metersRef.current.get(id)?.source.disconnect();
      const analyser = ac.createAnalyser();
      analyser.fftSize = 512;
      const source = ac.createMediaStreamSource(stream);
      source.connect(analyser); // not connected to destination: playback happens via <audio>
      metersRef.current.set(id, {
        analyser,
        data: new Uint8Array(analyser.fftSize) as Uint8Array<ArrayBuffer>,
        source,
        lastLoud: 0,
      });
    },
    [getAudioContext]
  );

  const sendSignal = (to: string, data: unknown) => realtime.send('rtc:signal', { to, data });

  const updateConnectedCount = () => {
    let n = 0;
    peersRef.current.forEach((p) => {
      if (p.pc.connectionState === 'connected') n++;
    });
    setConnected(n);
  };

  const closePeer = useCallback((id: string) => {
    const peer = peersRef.current.get(id);
    if (!peer) return;
    if (peer.disconnectTimer) window.clearTimeout(peer.disconnectTimer);
    peer.pc.onicecandidate = null;
    peer.pc.ontrack = null;
    peer.pc.onnegotiationneeded = null;
    peer.pc.onconnectionstatechange = null;
    try {
      peer.pc.close();
    } catch {
      // ignore
    }
    if (peer.audio) {
      peer.audio.pause();
      peer.audio.srcObject = null;
      peer.audio.remove();
    }
    metersRef.current.get(id)?.source.disconnect();
    metersRef.current.delete(id);
    peersRef.current.delete(id);
    updateConnectedCount();
  }, []);

  const createPeer = useCallback(
    (id: string): Peer => {
      const pc = new RTCPeerConnection({ iceServers: iceRef.current });
      const transceiver = pc.addTransceiver('audio', { direction: 'sendrecv' });
      const peer: Peer = {
        id,
        pc,
        polite: meId < id,
        makingOffer: false,
        ignoreOffer: false,
        sender: transceiver.sender,
        audio: null,
        disconnectTimer: null,
      };
      if (trackRef.current) transceiver.sender.replaceTrack(trackRef.current).catch(() => {});

      pc.onicecandidate = ({ candidate }) => {
        if (candidate) sendSignal(id, { candidate: candidate.toJSON() });
      };
      pc.onnegotiationneeded = async () => {
        try {
          peer.makingOffer = true;
          await pc.setLocalDescription();
          sendSignal(id, { description: pc.localDescription });
        } catch (err) {
          console.warn('[voice] negotiation failed', err);
        } finally {
          peer.makingOffer = false;
        }
      };
      pc.ontrack = (ev) => {
        const stream = ev.streams[0] || new MediaStream([ev.track]);
        if (!peer.audio) {
          const el = document.createElement('audio');
          el.autoplay = true;
          (el as HTMLAudioElement & { playsInline: boolean }).playsInline = true;
          el.style.display = 'none';
          document.body.appendChild(el);
          peer.audio = el;
        }
        peer.audio.srcObject = stream;
        peer.audio
          .play()
          .then(() => setAudioBlocked(false))
          .catch(() => setAudioBlocked(true));
        addMeter(id, stream);
      };
      pc.onconnectionstatechange = () => {
        if (peer.disconnectTimer) {
          window.clearTimeout(peer.disconnectTimer);
          peer.disconnectTimer = null;
        }
        if (pc.connectionState === 'failed') {
          pc.restartIce();
        } else if (pc.connectionState === 'disconnected') {
          peer.disconnectTimer = window.setTimeout(() => {
            if (pc.connectionState === 'disconnected') pc.restartIce();
          }, 4000);
        }
        updateConnectedCount();
      };
      peersRef.current.set(id, peer);
      return peer;
    },
    [meId, addMeter, closePeer]
  );

  const handleSignal = useCallback(
    async (from: string, data: { description?: RTCSessionDescriptionInit; candidate?: RTCIceCandidateInit | null }) => {
      const current = roomRef.current;
      if (!current || !current.participants.some((p) => p.userId === from)) return;
      if (iceReadyRef.current) await iceReadyRef.current;
      const peer = peersRef.current.get(from) || createPeer(from);
      const pc = peer.pc;
      try {
        if (data.description) {
          const desc = data.description;
          const collision = desc.type === 'offer' && (peer.makingOffer || pc.signalingState !== 'stable');
          peer.ignoreOffer = !peer.polite && collision;
          if (peer.ignoreOffer) return;
          await pc.setRemoteDescription(desc);
          if (desc.type === 'offer') {
            await pc.setLocalDescription();
            sendSignal(from, { description: pc.localDescription });
          }
        } else if (data.candidate !== undefined) {
          try {
            await pc.addIceCandidate(data.candidate ?? undefined);
          } catch (err) {
            if (!peer.ignoreOffer) console.warn('[voice] addIceCandidate', err);
          }
        }
      } catch (err) {
        console.warn('[voice] signal handling failed', err);
      }
    },
    [createPeer]
  );

  // Incoming signalling messages
  useEffect(() => {
    return realtime.on('rtc:signal', (p: { from: string; data: any }) => {
      if (p?.from && p.data) void handleSignal(p.from, p.data);
    });
  }, [handleSignal]);

  // Load ICE servers when entering a room
  useEffect(() => {
    if (isMember && !iceReadyRef.current) {
      iceReadyRef.current = loadIceServers().then((s) => {
        iceRef.current = s;
      });
    }
    if (!isMember) iceReadyRef.current = null;
  }, [isMember]);

  // Microphone: only speakers/hosts hold the mic
  useEffect(() => {
    let cancelled = false;
    async function acquire() {
      if (!navigator.mediaDevices?.getUserMedia) {
        setMicError('unsupported');
        return;
      }
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
        });
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        const track = stream.getAudioTracks()[0];
        trackRef.current = track;
        track.enabled = micStateRef.current.canSpeak && !micStateRef.current.isMuted;
        peersRef.current.forEach((p) => p.sender.replaceTrack(track).catch(() => {}));
        addMeter('__me', stream);
        setMicError(null);
      } catch {
        if (!cancelled) setMicError('denied');
      }
    }
    function release() {
      streamRef.current?.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
      trackRef.current = null;
      peersRef.current.forEach((p) => p.sender.replaceTrack(null).catch(() => {}));
      metersRef.current.get('__me')?.source.disconnect();
      metersRef.current.delete('__me');
    }
    if (isMember && canSpeak) {
      if (!streamRef.current) void acquire();
    } else {
      release();
      if (!isMember) setMicError(null);
    }
    return () => {
      cancelled = true;
    };
  }, [isMember, canSpeak, addMeter]);

  // Apply mute state (authoritative copy lives on the server)
  useEffect(() => {
    if (trackRef.current) trackRef.current.enabled = canSpeak && !isMuted;
  }, [isMuted, canSpeak]);

  // Keep peer connections in sync with who is in the room
  const participantKey = room
    ? room.participants.map((p) => `${p.userId}:${p.role === 'listener' ? 'l' : 's'}`).join(',')
    : '';
  useEffect(() => {
    if (!isMember || !room) return;
    let stale = false;
    (async () => {
      if (iceReadyRef.current) await iceReadyRef.current;
      if (stale) return;
      const wanted = new Set(
        room.participants
          .filter((p) => p.userId !== meId && (canSpeak || p.role !== 'listener'))
          .map((p) => p.userId)
      );
      wanted.forEach((id) => {
        if (!peersRef.current.has(id)) createPeer(id);
      });
      [...peersRef.current.keys()].forEach((id) => {
        if (!wanted.has(id)) closePeer(id);
      });
    })();
    return () => {
      stale = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [participantKey, isMember, canSpeak, meId]);

  // Tear everything down when leaving the room
  useEffect(() => {
    if (isMember) return;
    [...peersRef.current.keys()].forEach(closePeer);
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    trackRef.current = null;
    metersRef.current.forEach((m) => m.source.disconnect());
    metersRef.current.clear();
    if (acRef.current) {
      acRef.current.close().catch(() => {});
      acRef.current = null;
    }
    setSpeaking({});
    setAudioBlocked(false);
    setConnected(0);
  }, [isMember, closePeer]);

  useEffect(
    () => () => {
      [...peersRef.current.keys()].forEach(closePeer);
      streamRef.current?.getTracks().forEach((t) => t.stop());
      acRef.current?.close().catch(() => {});
    },
    [closePeer]
  );

  // Real speaking detection from audio levels
  useEffect(() => {
    if (!isMember) return;
    const id = window.setInterval(() => {
      const now = performance.now();
      const next: Record<string, boolean> = {};
      metersRef.current.forEach((m, key) => {
        m.analyser.getByteTimeDomainData(m.data);
        let sum = 0;
        for (let i = 0; i < m.data.length; i++) {
          const v = (m.data[i] - 128) / 128;
          sum += v * v;
        }
        const rms = Math.sqrt(sum / m.data.length);
        if (rms > 0.02) m.lastLoud = now;
        const userId = key === '__me' ? meId : key;
        const active = now - m.lastLoud < 350 && (key !== '__me' || (canSpeak && !isMuted));
        if (active) next[userId] = true;
      });
      setSpeaking((prev) => {
        const pk = Object.keys(prev);
        const nk = Object.keys(next);
        return pk.length === nk.length && nk.every((k) => prev[k]) ? prev : next;
      });
    }, 120);
    return () => window.clearInterval(id);
  }, [isMember, meId, canSpeak, isMuted]);

  const resumeAudio = useCallback(() => {
    getAudioContext();
    peersRef.current.forEach((p) => {
      p.audio?.play().then(() => setAudioBlocked(false)).catch(() => {});
    });
  }, [getAudioContext]);

  return { isMember, canSpeak, isMuted, speaking, micError, audioBlocked, resumeAudio, connected };
}
