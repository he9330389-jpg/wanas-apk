import express from 'express';
import type { Request, Response, NextFunction } from 'express';
import http from 'http';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import zlib from 'zlib';
import { fileURLToPath } from 'url';
import { WebSocketServer, WebSocket } from 'ws';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import type {
  User,
  Post,
  StoryItem,
  MajlisRoom,
  RoomMessage,
  RoomParticipant,
  DirectMessage,
  NewsItem,
  ReactionType,
} from './src/types.ts';
import {
  DEFAULT_USERS,
  DEFAULT_STORIES,
  DEFAULT_POSTS,
  DEFAULT_ROOMS,
  DEFAULT_DIRECT_MESSAGES,
  DEFAULT_NEWS,
} from './src/defaultData.ts';
import { createStore } from './server/db.ts';
import { createMediaStore } from './server/media.ts';
import {
  hashPassword,
  verifyPassword,
  signToken,
  verifyToken,
  createRateLimiter,
} from './server/auth.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// CRC32 Table for PNG & APK/ZIP Archiver
const crcTable = new Uint32Array(256);
for (let n = 0; n < 256; n++) {
  let c = n;
  for (let k = 0; k < 8; k++) {
    c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
  }
  crcTable[n] = c >>> 0;
}

function crc32(buf: Buffer): number {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c = crcTable[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ 0xffffffff) >>> 0;
}

// Generate Official WANAS Brand Icon PNG (#0E6B63 Teal Squircle + 2 White Overlapping Rings + #F2A93B Amber Lens)
function createPngBuffer(width: number, height: number): Buffer {
  const rawData = Buffer.alloc(height * (1 + width * 4));
  const cx1 = width * 0.422;
  const cx2 = width * 0.578;
  const cy = height * 0.5;
  const rOuter = width * 0.211;
  const rInner = width * 0.165;
  const strokeHalf = (rOuter - rInner) * 0.5;
  const rMid = (rOuter + rInner) * 0.5;
  const cornerR = width * 0.22;

  for (let y = 0; y < height; y++) {
    const rowStart = y * (1 + width * 4);
    rawData[rowStart] = 0; // filter type 0
    for (let x = 0; x < width; x++) {
      const px = rowStart + 1 + x * 4;

      // Squircle / rounded rect check
      const qx = Math.max(Math.abs(x - width * 0.5) - (width * 0.5 - cornerR), 0);
      const qy = Math.max(Math.abs(y - height * 0.5) - (height * 0.5 - cornerR), 0);
      const cornerDist = Math.sqrt(qx * qx + qy * qy);

      if (cornerDist > cornerR) {
        rawData[px] = 0;
        rawData[px + 1] = 0;
        rawData[px + 2] = 0;
        rawData[px + 3] = 0;
        continue;
      }

      // Base Primary Teal #0E6B63 -> (14, 107, 99)
      let r = 14;
      let g = 107;
      let b = 99;

      const d1 = Math.sqrt((x - cx1) ** 2 + (y - cy) ** 2);
      const d2 = Math.sqrt((x - cx2) ** 2 + (y - cy) ** 2);

      const onRing1 = Math.abs(d1 - rMid) <= strokeHalf;
      const onRing2 = Math.abs(d2 - rMid) <= strokeHalf;
      const inLens = d1 < rInner && d2 < rInner;

      if (onRing1 || onRing2) {
        r = 255;
        g = 255;
        b = 255;
      } else if (inLens) {
        r = 242;
        g = 169;
        b = 59;
      }

      rawData[px] = r;
      rawData[px + 1] = g;
      rawData[px + 2] = b;
      rawData[px + 3] = 255;
    }
  }

  const compressed = zlib.deflateSync(rawData);

  function makeChunk(type: string, data: Buffer): Buffer {
    const len = Buffer.alloc(4);
    len.writeUInt32BE(data.length, 0);
    const typeBuf = Buffer.from(type, 'ascii');
    const crcBuf = Buffer.alloc(4);
    crcBuf.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])), 0);
    return Buffer.concat([len, typeBuf, data, crcBuf]);
  }

  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;
  ihdr[9] = 6;
  ihdr[10] = 0;
  ihdr[11] = 0;
  ihdr[12] = 0;

  return Buffer.concat([
    signature,
    makeChunk('IHDR', ihdr),
    makeChunk('IDAT', compressed),
    makeChunk('IEND', Buffer.alloc(0)),
  ]);
}

function ensurePwaIcons() {
  const pubDir = path.join(__dirname, 'public');
  if (!fs.existsSync(pubDir)) {
    fs.mkdirSync(pubDir, { recursive: true });
  }
  const icons: { name: string; size: number }[] = [
    { name: 'pwa-192x192.png', size: 192 },
    { name: 'pwa-512x512.png', size: 512 },
    { name: 'pwa-maskable-512x512.png', size: 512 },
    { name: 'apple-touch-icon.png', size: 180 },
  ];
  for (const ic of icons) {
    const target = path.join(pubDir, ic.name);
    fs.writeFileSync(target, createPngBuffer(ic.size, ic.size));
  }
}

ensurePwaIcons();

// ---------------------------------------------------------------------------
// Persistent state: PostgreSQL (Supabase) when DATABASE_URL is set, JSON file otherwise.
// The server keeps a hot in-memory copy for fast reads/broadcasts and writes every change
// through to the database, so a restart or redeploy never loses data.
// ---------------------------------------------------------------------------
const dataDir = process.env.DATA_DIR || path.join(__dirname, 'data');
const legacyStatePath = path.join(dataDir, 'wanas_state.json');
const store = createStore(dataDir);
const media = createMediaStore(dataDir);

const users: User[] = [];
const newsList: NewsItem[] = [];
const stories: StoryItem[] = [];
const posts: Post[] = [];
const rooms: MajlisRoom[] = [];
const directMessages: DirectMessage[] = [];
let authSecret = '';

const MAX_SPEAKERS = Math.max(2, Number(process.env.MAX_ROOM_SPEAKERS) || 6);
const MAX_ROOM_MESSAGES = 200;

type AnyUser = User & { password?: string };

function publicUser(u: User): User {
  const { password: _p, email: _e, phone: _ph, ...rest } = u as AnyUser;
  return rest as User;
}
function selfUser(u: User): User {
  const { password: _p, ...rest } = u as AnyUser;
  return rest as User;
}
function storedUser(u: User): User {
  return selfUser(u);
}

const persistUser = (u: User) =>
  store.put('users', u.id, storedUser(u), null, u.lastActiveAtMs || Date.now());
const persistPost = (p: Post) =>
  store.put('posts', p.id, p, p.authorId, p.createdAtMs || Date.now());
const persistStory = (s: StoryItem) =>
  store.put('stories', s.id, s, s.authorId, s.createdAtMs || Date.now());
const persistNews = (n: NewsItem) =>
  store.put('news', n.id, n, null, n.createdAtMs || Date.now());
const persistRoom = (r: MajlisRoom, ts = Date.now()) =>
  store.put('rooms', r.id, { ...r, participants: [], messages: [] }, r.hostId, ts);
const persistRoomMessage = (roomId: string, m: RoomMessage) =>
  store.put('room_messages', m.id, { ...m, roomId }, roomId, m.createdAtMs || Date.now());
const persistDm = (m: DirectMessage) =>
  store.put('direct_messages', m.id, m, m.senderId, m.createdAtMs || Date.now());

async function migrateLegacyJson() {
  if (!fs.existsSync(legacyStatePath)) return;
  if ((await store.count('users')) > 0 || (await store.count('posts')) > 0) return;
  try {
    const legacy = JSON.parse(fs.readFileSync(legacyStatePath, 'utf-8'));
    let migrated = 0;
    for (const u of (legacy.users || []) as AnyUser[]) {
      const pass = u.password;
      const clean = storedUser(u);
      store.put('users', clean.id, clean, null, clean.lastActiveAtMs || Date.now());
      if (pass && (u.email || u.phone)) {
        try {
          await store.putCredential({
            userId: u.id,
            email: u.email ? u.email.trim().toLowerCase() : null,
            phone: u.phone ? u.phone.replace(/\s+/g, '') : null,
            passwordHash: await hashPassword(pass),
          });
        } catch (err) {
          console.error('[migrate] credential skipped for', u.id, (err as Error).message);
        }
      }
      migrated++;
    }
    const now = Date.now();
    (legacy.posts || []).forEach((p: Post, i: number) =>
      store.put('posts', p.id, p, p.authorId, p.createdAtMs || now - i)
    );
    (legacy.stories || []).forEach((s: StoryItem, i: number) =>
      store.put('stories', s.id, s, s.authorId, s.createdAtMs || now - i)
    );
    (legacy.rooms || []).forEach((r: MajlisRoom, i: number) => {
      store.put('rooms', r.id, { ...r, participants: [], messages: [] }, r.hostId, now - i);
      (r.messages || []).forEach((m) => persistRoomMessage(r.id, m));
    });
    (legacy.directMessages || []).forEach((m: DirectMessage, i: number) =>
      store.put('direct_messages', m.id, m, m.senderId, m.createdAtMs || now - 1000 + i)
    );
    (legacy.news || []).forEach((n: NewsItem, i: number) =>
      store.put('news', n.id, n, null, n.createdAtMs || now - i)
    );
    fs.renameSync(legacyStatePath, `${legacyStatePath}.migrated`);
    console.log(`[migrate] imported legacy JSON state (${migrated} users)`);
  } catch (err) {
    console.error('[migrate] legacy import failed:', err);
  }
}

async function seedIfEmpty() {
  if ((await store.count('users')) > 0) return;
  const now = Date.now();
  DEFAULT_USERS.forEach((u) => persistUser(u));
  DEFAULT_STORIES.forEach((s, i) => store.put('stories', s.id, s, s.authorId, s.createdAtMs || now - i));
  DEFAULT_POSTS.forEach((p, i) => store.put('posts', p.id, p, p.authorId, p.createdAtMs || now - i));
  DEFAULT_ROOMS.forEach((r, i) => persistRoom(r, now - i));
  DEFAULT_DIRECT_MESSAGES.forEach((m, i) =>
    store.put('direct_messages', m.id, m, m.senderId, m.createdAtMs || now - 1000 + i)
  );
  DEFAULT_NEWS.forEach((n, i) => store.put('news', n.id, n, null, n.createdAtMs || now - i));
  await store.flush();
}

async function bootstrap() {
  await store.init();
  await media.ensureBucket();
  await migrateLegacyJson();
  await store.flush();
  await seedIfEmpty();

  users.splice(0, users.length, ...((await store.load('users')) as User[]));
  posts.splice(0, posts.length, ...((await store.load('posts', { limit: 300 })) as Post[]));
  stories.splice(0, stories.length, ...((await store.load('stories', { limit: 120 })) as StoryItem[]));
  newsList.splice(0, newsList.length, ...((await store.load('news', { limit: 20 })) as NewsItem[]));
  const dms = (await store.load('direct_messages', { limit: 3000 })) as DirectMessage[];
  directMessages.splice(0, directMessages.length, ...dms.reverse());

  const loadedRooms = (await store.load('rooms')) as MajlisRoom[];
  const msgs = (await store.load('room_messages', { limit: 3000 })) as (RoomMessage & { roomId: string })[];
  msgs.reverse();
  rooms.splice(
    0,
    rooms.length,
    ...loadedRooms.map((r) => ({
      ...r,
      participants: [] as RoomParticipant[], // nobody is connected right after a (re)start
      messages: msgs
        .filter((m) => m.roomId === r.id)
        .slice(-MAX_ROOM_MESSAGES)
        .map(({ roomId: _r, ...m }) => m as RoomMessage),
    }))
  );

  let secret = await store.getMeta('auth_secret');
  if (!secret) {
    secret = process.env.AUTH_SECRET || crypto.randomBytes(48).toString('hex');
    await store.setMeta('auth_secret', secret);
  }
  authSecret = process.env.AUTH_SECRET || secret;
  console.log(
    `[wanas] storage=${store.mode} media=${media.useSupabase ? 'supabase' : 'local'} users=${users.length} posts=${posts.length} rooms=${rooms.length}`
  );
}

const rotatingLiveNewsPool: Omit<NewsItem, 'id' | 'publishedAtAr' | 'publishedAtEn'>[] = [
  {
    titleAr:
      'تحديث ونس ٣.٢ الرسمي: تفعيل الـ ٦ تفاعلات، استطلاعات الرأي، إعادة النشر، والتحكم الكامل بخصوصية الستوري والمنشورات',
    titleEn:
      'WANAS 3.2 Update: 6 Reactions, Interactive Polls, Reposts & Full Story/Post Privacy Controls',
    summaryAr:
      'يمكن لجميع أعضاء منصة ونس الآن رفع الفيديوهات والصوتيات مباشرة من ملفات الهاتف وحفظ الوسائط واستخدام مساعد الذكاء الاصطناعي.',
    summaryEn:
      'All WANAS members can now upload videos and audio directly from phone files, download media, and use the Gemini AI assistant.',
    sourceAr: 'غرفة أخبار ونس',
    sourceEn: 'WANAS Newsroom',
    category: 'breaking',
    viewsCount: 3120,
    isBreaking: true,
  },
  {
    titleAr:
      'ميزة إخفاء حالة النشاط وتحديد جمهور المنشور والستوري على طريقة واتساب متاحة الآن لجميع الحسابات',
    titleEn:
      'Hide Activity Status & WhatsApp-Style Story/Post Audience Controls Now Live',
    summaryAr:
      'تحكم كامل في ظهور حالتك النشطة ومن يشاهد قصصك ومنشوراتك (للعامة، للأصدقاء، لغير الأصدقاء، أو تخصيص أفراد).',
    summaryEn:
      'Full control over your active status and who can view your stories and posts.',
    sourceAr: 'تحديثات منصة ونس',
    sourceEn: 'WANAS Updates',
    category: 'community',
    viewsCount: 2490,
    isBreaking: true,
  },
];

let poolCursor = 0;

// ---------------------------------------------------------------------------
// WebRTC ICE servers (STUN is always on; TURN makes voice work behind mobile-carrier NAT).
// Configure ONE of: Cloudflare Calls TURN, Metered TURN, or any static TURN server.
// ---------------------------------------------------------------------------
type IceServer = { urls: string | string[]; username?: string; credential?: string };
let iceCache: { at: number; servers: IceServer[] } | null = null;

async function getIceServers(): Promise<IceServer[]> {
  if (iceCache && Date.now() - iceCache.at < 10 * 60 * 1000) return iceCache.servers;
  const servers: IceServer[] = [
    { urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'] },
    { urls: 'stun:global.stun.twilio.com:3478' },
  ];

  const cfId = process.env.CLOUDFLARE_TURN_KEY_ID;
  const cfToken = process.env.CLOUDFLARE_TURN_API_TOKEN;
  const meteredKey = process.env.METERED_API_KEY;
  const meteredApp = process.env.METERED_APP_NAME; // e.g. "wanas" for wanas.metered.live
  const staticUrls = (process.env.TURN_URLS || '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);

  try {
    if (cfId && cfToken) {
      const r = await fetch(
        `https://rtc.live.cloudflare.com/v1/turn/keys/${cfId}/credentials/generate-ice-servers`,
        {
          method: 'POST',
          headers: { Authorization: `Bearer ${cfToken}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({ ttl: 86400 }),
        }
      );
      if (r.ok) {
        const j = (await r.json()) as { iceServers?: IceServer[] | IceServer };
        const list = Array.isArray(j.iceServers) ? j.iceServers : j.iceServers ? [j.iceServers] : [];
        servers.push(...list);
      } else console.error('[rtc] Cloudflare TURN error', r.status);
    }
    if (meteredKey && meteredApp) {
      const r = await fetch(
        `https://${meteredApp}.metered.live/api/v1/turn/credentials?apiKey=${encodeURIComponent(meteredKey)}`
      );
      if (r.ok) servers.push(...((await r.json()) as IceServer[]));
      else console.error('[rtc] Metered TURN error', r.status);
    }
  } catch (err) {
    console.error('[rtc] TURN provider unreachable:', (err as Error).message);
  }

  if (staticUrls.length) {
    servers.push({
      urls: staticUrls,
      username: process.env.TURN_USERNAME,
      credential: process.env.TURN_CREDENTIAL,
    });
  }
  iceCache = { at: Date.now(), servers };
  return servers;
}

interface Conn extends WebSocket {
  userId?: string;
  roomId?: string;
  alive?: boolean;
}

const rid = () => crypto.randomBytes(4).toString('hex');
const clip = (v: unknown, max: number) => (typeof v === 'string' ? v.trim().slice(0, max) : '');

async function startServer() {
  await bootstrap();

  const app = express();
  app.set('trust proxy', 1);
  const server = http.createServer(app);
  const wss = new WebSocketServer({ server });

  // Enable CORS so the standalone Android APK (file://) can communicate with the live server
  app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    if (req.method === 'OPTIONS') {
      res.sendStatus(204);
      return;
    }
    next();
  });

  app.use(express.json({ limit: '60mb' }));

  /* ------------------------------ auth helpers ----------------------------- */
  const authUserIdFromReq = (req: Request): string | null => {
    const h = req.headers.authorization || '';
    return verifyToken(h.startsWith('Bearer ') ? h.slice(7) : '', authSecret);
  };
  const requireAuth = (req: Request, res: Response, next: NextFunction) => {
    const id = authUserIdFromReq(req);
    if (!id || !users.some((u) => u.id === id)) {
      res.status(401).json({ error: 'unauthorized' });
      return;
    }
    (req as Request & { userId: string }).userId = id;
    next();
  };
  const uidOf = (req: Request) => (req as Request & { userId: string }).userId;

  // Limits are per IP (mobile carriers share IPs, so keep them generous) and per account identifier.
  const loginLimiter = createRateLimiter(10, 10 * 60 * 1000);
  const signupLimiter = createRateLimiter(30, 60 * 60 * 1000);
  const loginIpLimiter = createRateLimiter(60, 10 * 60 * 1000);

  /* --------------------------- connections & rooms -------------------------- */
  const connsByUser = new Map<string, Set<Conn>>();

  function sendTo(ws: WebSocket, event: string, payload: unknown) {
    if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ event, payload }));
  }
  function sendToUser(userId: string, event: string, payload: unknown) {
    connsByUser.get(userId)?.forEach((c) => sendTo(c, event, payload));
  }
  function broadcast(event: string, payload: unknown) {
    const message = JSON.stringify({ event, payload });
    wss.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) client.send(message);
    });
  }

  // ---- audience / story privacy, enforced on the server (the client must never receive what it may not see) ----
  const userById = (id: string) => users.find((u) => u.id === id);
  const areFriends = (a: string, b: string) =>
    a === b || Boolean(userById(a)?.friendIds?.includes(b)) || Boolean(userById(b)?.friendIds?.includes(a));
  const shareFriend = (a: string, b: string) => {
    const fa = userById(a)?.friendIds || [];
    return fa.some((f) => areFriends(f, b));
  };
  function canViewPost(post: Post, uid: string | null): boolean {
    if (uid && (post.authorId === uid || post.repostedByAuthorId === uid)) return true;
    const aud = post.audience || 'public';
    if (aud === 'public') return true;
    if (!uid || aud === 'only_me') return false;
    const friend = areFriends(uid, post.authorId);
    return aud === 'friends' ? friend : aud === 'non_friends' ? !friend : true;
  }
  function canViewStory(st: StoryItem, uid: string | null): boolean {
    if (uid && st.authorId === uid) return true;
    const mode = st.privacyMode || 'public';
    if (mode === 'public') return true;
    if (!uid) return false;
    const friend = areFriends(uid, st.authorId);
    if (mode === 'friends_only') return friend;
    if (mode === 'public_except_friends') return !friend;
    if (mode === 'friends_of_friends') return friend || shareFriend(uid, st.authorId);
    if (mode === 'custom_include') return (st.allowedUserIds || []).includes(uid);
    if (mode === 'custom_exclude') return !(st.excludedUserIds || []).includes(uid);
    return false;
  }
  const broadcastPost = (event: 'post:created' | 'post:updated', post: Post) =>
    wss.clients.forEach((c) => {
      const conn = c as Conn;
      if (conn.readyState !== WebSocket.OPEN) return;
      if (canViewPost(post, conn.userId || null)) sendTo(conn, event, post);
      else sendTo(conn, 'post:deleted', { id: post.id });
    });
  const broadcastStory = (story: StoryItem) =>
    wss.clients.forEach((c) => {
      const conn = c as Conn;
      if (conn.readyState === WebSocket.OPEN && canViewStory(story, conn.userId || null))
        sendTo(conn, 'story:created', story);
    });

  function snapshotFor(uid: string | null) {
    return {
      users: users.map((u) => (u.id === uid ? selfUser(u) : publicUser(u))),
      stories: stories.filter((st) => canViewStory(st, uid)),
      posts: posts.filter((p) => canViewPost(p, uid)),
      rooms,
      // Private messages are only ever delivered to the two people in the conversation.
      directMessages: uid
        ? directMessages.filter((m) => m.senderId === uid || m.receiverId === uid)
        : [],
      news: newsList,
    };
  }

  const speakerCount = (room: MajlisRoom) =>
    room.participants.filter((p) => p.role !== 'listener').length;
  const pushParticipants = (room: MajlisRoom) =>
    broadcast('room:participants', { roomId: room.id, participants: room.participants });

  function detachFromRoom(conn: Conn) {
    const roomId = conn.roomId;
    conn.roomId = undefined;
    if (!roomId || !conn.userId) return;
    const room = rooms.find((r) => r.id === roomId);
    if (!room) return;
    // Another device of the same user may still be in the room — keep the seat then.
    const stillThere = [...(connsByUser.get(conn.userId) || [])].some((c) => c !== conn && c.roomId === roomId);
    if (stillThere) return;
    const leaving = room.participants.find((p) => p.userId === conn.userId);
    room.participants = room.participants.filter((p) => p.userId !== conn.userId);
    if (leaving?.role === 'host' && room.participants.length > 0) {
      // Pass moderation to the next speaker (or the longest-present member).
      const next = room.participants.find((p) => p.role === 'speaker') || room.participants[0];
      next.role = 'host';
      next.handRaised = false;
    }
    pushParticipants(room);
  }

  function attachToRoom(conn: Conn, room: MajlisRoom): boolean {
    if (!conn.userId) return false;
    if (conn.roomId && conn.roomId !== room.id) detachFromRoom(conn);
    // Same user joining from a second device takes over the seat.
    connsByUser.get(conn.userId)?.forEach((c) => {
      if (c !== conn && c.roomId) {
        if (c.roomId === room.id) sendTo(c, 'room:kicked', { roomId: room.id, reason: 'other_device' });
        c.roomId = undefined;
      }
    });
    let me = room.participants.find((p) => p.userId === conn.userId);
    if (!me) {
      const hasHost = room.participants.some((p) => p.role === 'host');
      const role: RoomParticipant['role'] =
        room.hostId === conn.userId || !hasHost
          ? 'host'
          : speakerCount(room) < MAX_SPEAKERS
          ? 'speaker'
          : 'listener';
      me = { userId: conn.userId, isMuted: true, isSpeaking: false, role, handRaised: false };
      room.participants.push(me);
    }
    conn.roomId = room.id;
    pushParticipants(room);
    return true;
  }

  const roomOf = (conn: Conn) => rooms.find((r) => r.id === conn.roomId);

  wss.on('connection', (rawWs) => {
    const ws = rawWs as Conn;
    ws.alive = true;
    ws.on('pong', () => (ws.alive = true));

    // Public data only until the client identifies itself with `hello`.
    sendTo(ws, 'init', snapshotFor(null));

    ws.on('message', async (raw) => {
      let data: { event?: string; payload?: any };
      try {
        data = JSON.parse(raw.toString());
      } catch {
        return;
      }
      const { event, payload } = data;
      try {
        if (event === 'ping') {
          sendTo(ws, 'pong', null);
          return;
        }

        if (event === 'hello') {
          const uid = verifyToken(payload?.token, authSecret);
          if (!uid || !users.some((u) => u.id === uid)) {
            sendTo(ws, 'hello:error', null);
            return;
          }
          if (ws.userId && ws.userId !== uid) {
            detachFromRoom(ws);
            connsByUser.get(ws.userId)?.delete(ws);
          }
          ws.userId = uid;
          if (!connsByUser.has(uid)) connsByUser.set(uid, new Set());
          connsByUser.get(uid)!.add(ws);
          sendTo(ws, 'hello:ok', { userId: uid });
          sendTo(ws, 'init', snapshotFor(uid));
          return;
        }

        const uid = ws.userId;
        if (!uid) return; // everything below needs an authenticated socket

        /* ------------------------------ rooms ------------------------------ */
        if (event === 'room:create') {
          const title = clip(payload?.title, 80);
          if (!title) return;
          const topic = clip(payload?.topic, 240) || 'نقاش مفتوح لأعضاء مجتمع ونس';
          const room: MajlisRoom = {
            id: `room_${Date.now().toString(36)}${rid()}`,
            title,
            titleEn: title,
            topic,
            topicEn: topic,
            category: 'majlis',
            isLive: true,
            hostId: uid,
            participants: [],
            messages: [],
          };
          rooms.unshift(room);
          persistRoom(room);
          attachToRoom(ws, room);
          broadcast('room:created', room);
        } else if (event === 'room:join') {
          const room = rooms.find((r) => r.id === payload?.roomId);
          if (!room) {
            sendTo(ws, 'room:error', { code: 'not_found' });
            return;
          }
          attachToRoom(ws, room);
        } else if (event === 'room:leave') {
          detachFromRoom(ws);
        } else if (event === 'room:mute') {
          const room = roomOf(ws);
          const me = room?.participants.find((p) => p.userId === uid);
          if (!room || !me) return;
          me.isMuted = me.role === 'listener' ? true : Boolean(payload?.muted);
          pushParticipants(room);
        } else if (event === 'room:hand') {
          const room = roomOf(ws);
          const me = room?.participants.find((p) => p.userId === uid);
          if (!room || !me || me.role !== 'listener') return;
          me.handRaised = Boolean(payload?.raised);
          pushParticipants(room);
        } else if (event === 'room:moderate') {
          const room = roomOf(ws);
          const mod = room?.participants.find((p) => p.userId === uid);
          if (!room || !mod || mod.role !== 'host') return;
          const target = room.participants.find((p) => p.userId === payload?.userId);
          if (!target || target.userId === uid) return;
          const action = payload?.action as string;
          if (action === 'promote' && target.role === 'listener') {
            if (speakerCount(room) >= MAX_SPEAKERS) {
              sendTo(ws, 'room:error', { code: 'speaker_limit', max: MAX_SPEAKERS });
              return;
            }
            target.role = 'speaker';
            target.isMuted = true;
            target.handRaised = false;
          } else if (action === 'demote' && target.role === 'speaker') {
            target.role = 'listener';
            target.isMuted = true;
          } else if (action === 'mute') {
            target.isMuted = true;
          } else if (action === 'kick') {
            room.participants = room.participants.filter((p) => p.userId !== target.userId);
            connsByUser.get(target.userId)?.forEach((c) => {
              if (c.roomId === room.id) {
                c.roomId = undefined;
                sendTo(c, 'room:kicked', { roomId: room.id, reason: 'kicked' });
              }
            });
          } else return;
          pushParticipants(room);
        } else if (event === 'room:close') {
          const room = rooms.find((r) => r.id === payload?.roomId);
          if (!room || room.hostId !== uid) return;
          rooms.splice(rooms.indexOf(room), 1);
          store.remove('rooms', room.id);
          store.removeWhere('room_messages', room.id);
          wss.clients.forEach((c) => {
            if ((c as Conn).roomId === room.id) (c as Conn).roomId = undefined;
          });
          broadcast('room:deleted', { id: room.id });
        } else if (event === 'room:message') {
          const room = roomOf(ws);
          const text = clip(payload?.message?.text, 500);
          if (!room || !text) return;
          const now = Date.now();
          const d = new Date(now);
          const message: RoomMessage = {
            id: clip(payload?.message?.id, 60) || `rm_${now}_${rid()}`,
            senderId: uid,
            text,
            createdAt: `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`,
            createdAtMs: now,
          };
          if (room.messages.some((m) => m.id === message.id)) return;
          room.messages.push(message);
          if (room.messages.length > MAX_ROOM_MESSAGES) room.messages.shift();
          persistRoomMessage(room.id, message);
          broadcast('room:message', { roomId: room.id, message });
        } else if (event === 'rtc:signal') {
          // Relay WebRTC offers/answers/ICE candidates between two members of the same room.
          const room = roomOf(ws);
          const to = String(payload?.to || '');
          if (!room || !room.participants.some((p) => p.userId === to)) return;
          connsByUser.get(to)?.forEach((c) => {
            if (c.roomId === room.id) sendTo(c, 'rtc:signal', { from: uid, data: payload?.data });
          });
        } else if (event === 'dm:message') {
          const raw = payload as DirectMessage;
          if (!raw?.id || !users.some((u) => u.id === raw.receiverId)) return;
          if (directMessages.some((m) => m.id === raw.id)) return;
          const msg: DirectMessage = { ...raw, senderId: uid };
          await media.externalize(msg);
          directMessages.push(msg);
          persistDm(msg);
          sendToUser(msg.senderId, 'dm:message', msg);
          if (msg.receiverId !== msg.senderId) sendToUser(msg.receiverId, 'dm:message', msg);
        }
      } catch (err) {
        console.error('WebSocket message error:', err);
      }
    });

    ws.on('close', () => {
      if (ws.userId) {
        detachFromRoom(ws);
        const set = connsByUser.get(ws.userId);
        set?.delete(ws);
        if (set && set.size === 0) connsByUser.delete(ws.userId);
      }
    });
  });

  // Drop dead sockets (phones that lost signal) so their seat in a voice room is freed.
  const heartbeat = setInterval(() => {
    wss.clients.forEach((c) => {
      const conn = c as Conn;
      if (conn.alive === false) {
        conn.terminate();
        return;
      }
      conn.alive = false;
      conn.ping();
    });
  }, 30000);
  wss.on('close', () => clearInterval(heartbeat));

  /* -------------------------------- REST API -------------------------------- */
  app.get('/api/health', (_req, res) => {
    res.json({
      ok: true,
      storage: store.mode,
      media: media.useSupabase ? 'supabase' : 'local',
      turn: Boolean(
        process.env.CLOUDFLARE_TURN_KEY_ID || process.env.METERED_API_KEY || process.env.TURN_URLS
      ),
    });
  });

  app.get('/api/rtc-config', async (_req, res) => {
    res.json({ iceServers: await getIceServers(), maxSpeakers: MAX_SPEAKERS });
  });

  if (!media.useSupabase) {
    app.use('/media', express.static(media.localDir, { maxAge: '30d', immutable: true }));
  }

  app.get('/api/state', (req, res) => {
    res.json(snapshotFor(authUserIdFromReq(req)));
  });

  /* ---------------------------------- auth ---------------------------------- */
  const normEmail = (v: unknown) =>
    typeof v === 'string' && v.trim() ? v.trim().toLowerCase().slice(0, 160) : null;
  const normPhone = (v: unknown) =>
    typeof v === 'string' && v.trim() ? v.replace(/\s+/g, '').slice(0, 30) : null;

  app.post('/api/auth/signup', async (req, res) => {
    if (!signupLimiter(req.ip || 'x')) {
      res.status(429).json({ error: 'too_many_attempts' });
      return;
    }
    const b = (req.body || {}) as AnyUser;
    const email = normEmail(b.email);
    const phone = normPhone(b.phone);
    const password = typeof b.password === 'string' ? b.password.trim() : '';
    const name = clip(b.name, 60);
    if (name.length < 2) {
      res.status(400).json({ error: 'invalid_name' });
      return;
    }
    if ((!email || !email.includes('@')) && (!phone || phone.length < 7)) {
      res.status(400).json({ error: 'invalid_contact' });
      return;
    }
    if (password.length < 6) {
      res.status(400).json({ error: 'weak_password' });
      return;
    }
    if (await store.findCredential({ email, phone })) {
      res.status(409).json({ error: 'account_exists' });
      return;
    }

    const id = `u_${Date.now().toString(36)}${crypto.randomBytes(3).toString('hex')}`;
    let base = clip(b.handle, 40).replace(/^@/, '').replace(/[^\p{L}\p{N}_.]/gu, '') || 'wanas_user';
    let handle = `@${base}`;
    let n = 1;
    while (users.some((u) => u.handle.toLowerCase() === handle.toLowerCase())) {
      handle = `@${base}${++n}`;
    }

    await media.externalize(b);
    const { password: _pw, id: _id, isVerified: _iv, ...rest } = b;
    const user: User = {
      ...(rest as User),
      id,
      name,
      nameEn: b.nameEn || name,
      handle,
      email: email ?? undefined,
      phone: phone ?? undefined,
      isVerified: false,
      isOnline: true,
      lastActiveAtMs: Date.now(),
      followersCount: 0,
      followingCount: 0,
    };
    try {
      await store.putCredential({
        userId: id,
        email,
        phone,
        passwordHash: await hashPassword(password),
      });
    } catch {
      res.status(409).json({ error: 'account_exists' });
      return;
    }
    users.unshift(user);
    persistUser(user);
    broadcast('user:updated', publicUser(user));
    res.json({ user: selfUser(user), token: signToken(id, authSecret) });
  });

  app.post('/api/auth/login', async (req, res) => {
    const email = normEmail(req.body?.email);
    const phone = normPhone(req.body?.phone);
    const password = typeof req.body?.password === 'string' ? req.body.password.trim() : '';
    if (!loginIpLimiter(`ip:${req.ip}`) || !loginLimiter(`id:${email || phone}`)) {
      res.status(429).json({ error: 'too_many_attempts' });
      return;
    }
    const cred = email || phone ? await store.findCredential({ email, phone }) : null;
    const ok = cred ? await verifyPassword(password, cred.passwordHash) : false;
    const user = cred && ok ? users.find((u) => u.id === cred.userId) : undefined;
    if (!user) {
      res.status(401).json({ error: 'invalid_credentials' });
      return;
    }
    user.isOnline = true;
    user.lastActiveAtMs = Date.now();
    persistUser(user);
    res.json({ user: selfUser(user), token: signToken(user.id, authSecret) });
  });

  app.get('/api/auth/me', requireAuth, (req, res) => {
    const user = users.find((u) => u.id === uidOf(req));
    res.json({ user: user ? selfUser(user) : null });
  });

  // Update MY profile / settings (and optionally change email, phone or password).
  const updateProfile = async (req: Request, res: Response) => {
    const uid = uidOf(req);
    const body = (req.body || {}) as AnyUser;
    if (body.id !== uid) {
      res.status(403).json({ error: 'forbidden' });
      return;
    }
    const idx = users.findIndex((u) => u.id === uid);
    if (idx === -1) {
      res.status(404).json({ error: 'not_found' });
      return;
    }
    const existing = users[idx];
    await media.externalize(body);
    const { password, email, phone, isVerified: _v, ...rest } = body;
    const next: User = { ...existing, ...(rest as User), id: uid, isVerified: existing.isVerified };

    const cred = await store.findCredential({ userId: uid });
    let newEmail = existing.email ?? null;
    let newPhone = existing.phone ?? null;
    if (email !== undefined) {
      const e = normEmail(email);
      if (e !== newEmail) {
        const clash = e ? await store.findCredential({ email: e }) : null;
        if (!clash || clash.userId === uid) newEmail = e;
      }
    }
    if (phone !== undefined) {
      const p = normPhone(phone);
      if (p !== newPhone) {
        const clash = p ? await store.findCredential({ phone: p }) : null;
        if (!clash || clash.userId === uid) newPhone = p;
      }
    }
    next.email = newEmail ?? undefined;
    next.phone = newPhone ?? undefined;

    const newPass = typeof password === 'string' && password.trim().length >= 6 ? password.trim() : '';
    if (cred || (newPass && (newEmail || newPhone))) {
      await store.putCredential({
        userId: uid,
        email: newEmail,
        phone: newPhone,
        passwordHash: newPass ? await hashPassword(newPass) : cred!.passwordHash,
      });
    }

    users[idx] = next;
    persistUser(next);
    broadcast('user:updated', publicUser(next));
    res.json(selfUser(next));
  };
  app.post('/api/auth/register', requireAuth, updateProfile);
  app.put('/api/auth/profile', requireAuth, updateProfile);

  /* ------------------------------ posts & stories ---------------------------- */
  app.post('/api/posts', requireAuth, async (req, res) => {
    const uid = uidOf(req);
    const incoming = req.body as Post;
    if (!incoming || !incoming.id) {
      res.status(400).json({ error: 'Invalid post payload' });
      return;
    }
    const idx = posts.findIndex((p) => p.id === incoming.id);
    if (idx === -1) {
      if (incoming.authorId !== uid && incoming.repostedByAuthorId !== uid) {
        res.status(403).json({ error: 'forbidden' });
        return;
      }
      await media.externalize(incoming);
      posts.unshift(incoming);
      persistPost(incoming);
      broadcastPost('post:created', incoming);
      res.json(incoming);
      return;
    }
    const existing = posts[idx];
    let next: Post;
    if (existing.authorId === uid) {
      await media.externalize(incoming);
      next = { ...incoming, authorId: existing.authorId };
    } else if (incoming.poll && existing.poll) {
      // Anyone may vote: only the caller's own vote is taken from the request.
      next = {
        ...existing,
        poll: {
          ...existing.poll,
          options: existing.poll.options.map((o) => {
            const inc = incoming.poll!.options.find((x) => x.id === o.id);
            const others = o.votes.filter((v) => v !== uid);
            return { ...o, votes: inc?.votes.includes(uid) ? [...others, uid] : others };
          }),
        },
      };
    } else {
      res.status(403).json({ error: 'forbidden' });
      return;
    }
    posts[idx] = next;
    persistPost(next);
    broadcastPost('post:updated', next);
    res.json(next);
  });

  app.delete('/api/posts/:id', requireAuth, (req, res) => {
    const uid = uidOf(req);
    const idx = posts.findIndex((p) => p.id === req.params.id);
    if (idx !== -1) {
      const p = posts[idx];
      if (p.authorId !== uid && p.repostedByAuthorId !== uid) {
        res.status(403).json({ error: 'forbidden' });
        return;
      }
      posts.splice(idx, 1);
      store.remove('posts', p.id);
      broadcast('post:deleted', { id: p.id });
    }
    res.json({ deleted: true, id: req.params.id });
  });

  // React to Post (6 Reactions: like, love, haha, support, angry, disagree)
  app.post('/api/posts/:id/react', requireAuth, (req, res) => {
    const userId = uidOf(req);
    const body = req.body as { reaction?: ReactionType; type?: ReactionType };
    const reaction = (body.reaction || body.type) as ReactionType;
    const post = posts.find((p) => p.id === req.params.id);
    const kinds: ReactionType[] = ['like', 'love', 'haha', 'support', 'angry', 'disagree'];
    if (!post || !reaction || !kinds.includes(reaction)) {
      res.status(post ? 400 : 404).json({ error: post ? 'Bad request' : 'Post not found' });
      return;
    }
    const reactions: Partial<Record<ReactionType, string[]>> = { ...(post.reactions || {}) };
    const had = (reactions[reaction] || []).includes(userId);
    for (const k of kinds) reactions[k] = (reactions[k] || []).filter((u) => u !== userId);
    if (!had) reactions[reaction] = [...(reactions[reaction] || []), userId];
    post.reactions = reactions;
    post.likes = reactions.like || [];
    persistPost(post);
    broadcastPost('post:updated', post);
    res.json(post);
  });

  // Legacy Like Endpoint
  app.post('/api/posts/:id/like', requireAuth, (req, res) => {
    const userId = uidOf(req);
    const post = posts.find((p) => p.id === req.params.id);
    if (!post) {
      res.status(404).json({ error: 'Post not found' });
      return;
    }
    const idx = post.likes.indexOf(userId);
    if (idx === -1) post.likes.push(userId);
    else post.likes.splice(idx, 1);
    persistPost(post);
    broadcastPost('post:updated', post);
    res.json(post);
  });

  // Add Comment on Post
  app.post('/api/posts/:id/comments', requireAuth, async (req, res) => {
    const uid = uidOf(req);
    const comment = req.body;
    const post = posts.find((p) => p.id === req.params.id);
    if (!post) {
      res.status(404).json({ error: 'Post not found' });
      return;
    }
    if (!comment?.id || comment.authorId !== uid) {
      res.status(403).json({ error: 'forbidden' });
      return;
    }
    await media.externalize(comment);
    const existingIdx = post.comments.findIndex((c) => c.id === comment.id);
    if (existingIdx === -1) post.comments.push(comment);
    else if (post.comments[existingIdx].authorId === uid) post.comments[existingIdx] = comment;
    persistPost(post);
    broadcastPost('post:updated', post);
    res.json(post);
  });

  // Publish Story
  app.post('/api/stories', requireAuth, async (req, res) => {
    const uid = uidOf(req);
    const newStory = req.body as StoryItem;
    if (!newStory || !newStory.id || newStory.authorId !== uid) {
      res.status(newStory?.id ? 403 : 400).json({ error: 'Invalid story payload' });
      return;
    }
    if (!stories.some((s) => s.id === newStory.id)) {
      await media.externalize(newStory);
      stories.unshift(newStory);
      persistStory(newStory);
      broadcastStory(newStory);
    }
    res.json(newStory);
  });

  // Refresh Home Feed & Latest Breaking News
  app.post('/api/refresh-all', requireAuth, async (req, res) => {
    let addedNews: NewsItem | null = null;

    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey && apiKey !== 'MY_GEMINI_API_KEY' && apiKey.length > 15) {
      try {
        const ai = new GoogleGenAI({
          apiKey,
          httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
        });
        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents:
            'أعطني خبراً اجتماعياً أو تقنياً حديثاً اليوم باللغتين العربية والإنجليزية بصيغة JSON.',
          config: {
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                titleAr: { type: Type.STRING },
                titleEn: { type: Type.STRING },
                summaryAr: { type: Type.STRING },
                summaryEn: { type: Type.STRING },
                sourceAr: { type: Type.STRING },
                sourceEn: { type: Type.STRING },
              },
              required: ['titleAr', 'titleEn', 'summaryAr', 'summaryEn', 'sourceAr', 'sourceEn'],
            },
          },
        });
        if (response.text) {
          const parsed = JSON.parse(response.text.trim());
          addedNews = {
            id: `news_${Date.now()}`,
            titleAr: parsed.titleAr,
            titleEn: parsed.titleEn,
            summaryAr: parsed.summaryAr,
            summaryEn: parsed.summaryEn,
            sourceAr: parsed.sourceAr || 'أخبار ونس المباشرة',
            sourceEn: parsed.sourceEn || 'WANAS Live News',
            category: 'breaking',
            publishedAtAr: 'الآن (محدث)',
            publishedAtEn: 'Just now',
            viewsCount: Math.floor(800 + Math.random() * 1500),
            isBreaking: true,
          };
        }
      } catch {
        // Fallback below
      }
    }

    if (!addedNews) {
      const template = rotatingLiveNewsPool[poolCursor % rotatingLiveNewsPool.length];
      poolCursor++;
      addedNews = {
        ...template,
        id: `news_${Date.now()}`,
        publishedAtAr: 'الآن (محدث)',
        publishedAtEn: 'Just now',
      };
    }

    if (!newsList.some((n) => n.titleAr === addedNews!.titleAr)) {
      addedNews.createdAtMs = Date.now();
      newsList.unshift(addedNews);
      if (newsList.length > 12) newsList.pop();
      persistNews(addedNews);
    }

    const snapshot = snapshotFor(uidOf(req));
    const payload = { ...snapshot, refreshedAt: new Date().toISOString() };
    broadcast('news:created', addedNews);
    res.json(payload);
  });

  // Gemini AI Assistant Endpoint (Write/Enhance Post, Summarize Post, Smart Comment Reply)
  app.post('/api/ai/assist', requireAuth, async (req, res) => {
    const { mode, text, lang } = req.body as {
      mode: 'enhance_post' | 'summarize' | 'smart_reply';
      text?: string;
      lang?: 'ar' | 'en';
    };
    const isAr = lang !== 'en';
    const input = (text || '').trim();

    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey && apiKey !== 'MY_GEMINI_API_KEY' && apiKey.length > 15) {
      try {
        const ai = new GoogleGenAI({
          apiKey,
          httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
        });

        let prompt = '';
        if (mode === 'enhance_post') {
          prompt = input
            ? isAr
              ? `قم بتحسين وصياغة هذا المنشور بأسلوب اجتماعي جذاب وراقٍ مع إضافة هاشتاجات مناسبة لمنصة ونس بدون مقدمات:\n${input}`
              : `Enhance and polish this social media post in an engaging style with relevant hashtags for WANAS (return only the post text):\n${input}`
            : isAr
            ? 'اكتب منشوراً اجتماعياً ملهماً وقصيراً للترحيب بالأصدقاء ومشاركة اللحظات الجميلة على منصة ونس مع هاشتاج #ونس.'
            : 'Write a short, inspiring social post welcoming friends on WANAS with #WANAS.';
        } else if (mode === 'summarize') {
          prompt = isAr
            ? `لخص هذا المنشور في جملة أو جملتين واضحتين ومختصرتين باللغة العربية:\n${input}`
            : `Summarize this post in 1-2 clear, concise sentences:\n${input}`;
        } else {
          prompt = isAr
            ? `اكتب تعليقاً ودوداً وذكياً ومختصراً للرد على هذا المنشور باللغة العربية بدون مقدمات:\n${input}`
            : `Write a friendly, smart, short comment replying to this post (return only the comment):\n${input}`;
        }

        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: prompt,
        });
        if (response.text) {
          res.json({ result: response.text.trim() });
          return;
        }
      } catch (err) {
        console.error('Gemini AI assist error:', err);
      }
    }

    // Intelligent deterministic fallback when no API key is configured
    let fallbackResult = '';
    if (mode === 'enhance_post') {
      fallbackResult = input
        ? `${input}\n\n✨ شاركونا آراءكم في التعليقات! #ونس #مجتمع_ونس`
        : isAr
        ? 'مساء الخير لمجتمع ونس الجميل ✨ شاركونا أجمل لحظاتكم اليوم، وما هي خططكم لهذا الأسبوع؟ #ونس #تواصل'
        : 'Good evening to the wonderful WANAS community ✨ Share your favorite moments today! #WANAS';
    } else if (mode === 'summarize') {
      const words = input.split(/\s+/).slice(0, 22).join(' ');
      fallbackResult = isAr
        ? `ملخص المنشور: ${words}${input.length > words.length ? '...' : ''}`
        : `Post Summary: ${words}${input.length > words.length ? '...' : ''}`;
    } else {
      fallbackResult = isAr
        ? 'منشور رائع ومميز جداً! شكراً لك على هذه المشاركة القيمة في مجتمع ونس 👏❤️'
        : 'Wonderful and insightful post! Thank you for sharing with the WANAS community 👏❤️';
    }

    res.json({ result: fallbackResult });
  });

  // Privacy policy page (required by Google Play). This is a starting template — review it before publishing.
  app.get('/privacy', (_req, res) => {
    const contact = process.env.PRIVACY_CONTACT_EMAIL || 'PRIVACY_CONTACT_EMAIL (set this env var)';
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.send(`<!DOCTYPE html>
<html lang="ar" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>سياسة الخصوصية — ونس WANAS</title>
<style>body{font-family:system-ui,'Cairo',sans-serif;max-width:720px;margin:0 auto;padding:24px;line-height:1.9;color:#1F1A12;background:#FAF7F2}
h1{color:#0E6B63}h2{margin-top:28px;color:#0E6B63;font-size:18px}.en{direction:ltr;text-align:left;margin-top:40px;padding-top:20px;border-top:1px solid #ddd}</style></head><body>
<h1>سياسة الخصوصية — ونس</h1>
<h2>البيانات التي نجمعها</h2>
<p>البريد الإلكتروني أو رقم الهاتف، كلمة المرور (تُخزَّن مشفّرة ولا يمكن قراءتها)، الاسم واسم المستخدم والصورة والنبذة، والمحتوى الذي تنشره (منشورات، قصص، تعليقات، رسائل).</p>
<h2>الميكروفون والكاميرا</h2>
<p>يُستخدم الميكروفون فقط أثناء وجودك داخل مجلس صوتي أو عند تسجيل رسالة صوتية، ولا يُسجَّل الصوت الحي في المجالس على السيرفر. تُستخدم الكاميرا فقط عند التقاطك صورة بنفسك.</p>
<h2>الرسائل الخاصة</h2>
<p>تُرسل الرسائل الخاصة إلى طرفي المحادثة فقط.</p>
<h2>التخزين والمشاركة</h2>
<p>تُحفظ البيانات في قاعدة بيانات ومساحة تخزين لدى مزوّد استضافة. لا نبيع بياناتك ولا نشاركها مع معلنين.</p>
<h2>حذف حسابك</h2>
<p>لطلب حذف حسابك وبياناتك راسلنا على: ${contact}</p>
<h2>الأطفال</h2>
<p>التطبيق غير موجّه لمن هم دون ١٣ عاماً.</p>
<div class="en"><h1>Privacy Policy — WANAS</h1>
<p><b>Data we collect:</b> email or phone number, a hashed password, profile details, and content you post (posts, stories, comments, messages).</p>
<p><b>Microphone &amp; camera:</b> the microphone is used only while you are inside a voice room or recording a voice note; live room audio is not recorded on our servers. The camera is used only when you take a photo.</p>
<p><b>Private messages</b> are delivered only to the two people in the conversation.</p>
<p><b>Storage:</b> data is stored with our hosting provider. We do not sell your data.</p>
<p><b>Delete your account:</b> email ${contact}</p>
<p><b>Children:</b> not intended for children under 13.</p></div>
</body></html>`);
  });

  // Official App Version & Update Check API for In-App / External Update Center
  app.get('/api/app-version', (_req, res) => {
    res.json({
      version: '3.3.0',
      versionCode: 330,
      releasedAt: new Date().toISOString(),
      apkDownloadUrl: '/WANAS-v3.2.0-official.apk',
      changelogAr: [
        'مجالس صوتية حقيقية: صوت مباشر بين الأعضاء (WebRTC) مع متحدثين ومستمعين ورفع اليد وإشراف المضيف.',
        'نقل كل البيانات إلى قاعدة بيانات (Supabase / PostgreSQL) والوسائط إلى Storage، فلا تضيع البيانات عند إعادة تشغيل السيرفر.',
        'تسجيل دخول آمن بكلمات مرور مشفّرة، والرسائل الخاصة لا تصل إلا لطرفيها.',
        'هيدر جديد أخف مع قائمة جانبية، وزر إنشاء في الشريط السفلي، وعدّاد للرسائل غير المقروءة.',
      ],
      changelogEn: [
        'Real voice rooms: live audio between members (WebRTC) with speakers, listeners, raise-hand and host moderation.',
        'All data moved to a database (Supabase / PostgreSQL) and media to Storage, so nothing is lost on server restarts.',
        'Secure login with hashed passwords; private messages are delivered only to the two people involved.',
        'Lighter header with a side menu, a Create button in the bottom bar, and an unread-messages badge.',
      ],
    });
  });

  // Dedicated Arabic Direct Download Page (/download) that supports instant APK download
  app.get(['/download', '/apk-page'], (_req, res) => {
    const v32Path = path.join(__dirname, 'public', 'WANAS-v3.2.0-official.apk');
    const sizeBytes = fs.existsSync(v32Path) ? fs.statSync(v32Path).size : 12708824;
    const sizeMb = (sizeBytes / (1024 * 1024)).toFixed(2);
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.send(`<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>تحميل تطبيق ونس الرسمي — WANAS v3.2.0 Official APK</title>
  <style>
    * { box-sizing: border-box; font-family: 'Cairo', system-ui, sans-serif; }
    body {
      margin: 0; min-height: 100vh; background: #0F1514; color: #FAF7F2;
      display: flex; align-items: center; justify-content: center; padding: 20px;
    }
    .card {
      max-width: 480px; width: 100%; background: #151D1C;
      border: 2px solid rgba(14, 107, 99, 0.5); border-radius: 28px;
      padding: 28px 24px; text-align: center; box-shadow: 0 25px 60px rgba(0,0,0,0.6);
    }
    .credit {
      display: inline-block; background: rgba(242, 169, 59, 0.12);
      border: 1px solid rgba(242, 169, 59, 0.35); color: #F2A93B;
      padding: 6px 14px; border-radius: 14px; font-size: 11px; font-weight: 800;
      margin-bottom: 16px;
    }
    .logo {
      width: 84px; height: 84px; border-radius: 22px; margin: 0 auto 8px;
      display: block; box-shadow: 0 10px 25px rgba(14,107,99,0.4);
    }
    .eng-name {
      font-size: 24px; font-weight: 900; letter-spacing: 0.25em; color: #FFFFFF;
      margin-bottom: 6px;
    }
    .sub { font-size: 13px; color: #94a3b8; margin-bottom: 20px; }
    .meta {
      background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.08);
      border-radius: 18px; padding: 14px; margin-bottom: 20px; font-size: 13px;
      display: grid; grid-template-columns: 1fr 1fr; gap: 10px;
    }
    .meta div span { display: block; font-size: 11px; color: #94a3b8; }
    .meta div strong { color: #5FD0C4; font-size: 14px; }
    .btn {
      display: block; width: 100%; padding: 16px 20px; border-radius: 18px;
      background: linear-gradient(135deg, #0E6B63, #0a524c); color: #FFFFFF;
      font-size: 16px; font-weight: 800; text-decoration: none;
      box-shadow: 0 10px 25px rgba(14,107,99,0.45); margin-bottom: 12px;
      border: 1px solid #5FD0C4;
    }
    .btn-sec {
      display: block; width: 100%; padding: 12px 16px; border-radius: 14px;
      background: rgba(242, 169, 59, 0.15); color: #F2A93B;
      font-size: 13px; font-weight: 700; text-decoration: none;
      border: 1px solid rgba(242, 169, 59, 0.35);
    }
  </style>
</head>
<body>
  <div class="card">
    <div class="credit">تم بناء وبرمجة هذا التطبيق بواسطة ABD.ALLAH ZOHAIR OMARA</div>
    <img src="/pwa-192x192.png" alt="WANAS" class="logo" />
    <div class="eng-name" dir="ltr">WANAS</div>
    <div class="sub">نسخة أندرويد الرسمية الكاملة الموقعة (V1 + V2 Signed APK)</div>
    <div class="meta">
      <div><span>اسم الملف</span><strong dir="ltr">WANAS-v3.2.0-official.apk</strong></div>
      <div><span>الحجم الكامل</span><strong dir="ltr">${sizeMb} MB (${sizeBytes.toLocaleString()} B)</strong></div>
    </div>
    <a class="btn" href="/WANAS-v3.2.0-official.apk" download="WANAS-v3.2.0-official.apk">
      ⬇️ تحميل ملف APK الكامل الآن (${sizeMb} MB)
    </a>
    <a class="btn-sec" href="/">
      🌐 فتح منصة ونس مباشرة
    </a>
  </div>
</body>
</html>`);
  });

  // Serve Cryptographically Signed (V1 + V2) Official WANAS Android APK Package
  app.get(
    [
      '/WANAS-v3.2.0-official.apk',
      '/WANAS-v3.1.0-official.apk',
      '/WANAS-v3.0.0-official.apk',
      '/WANAS-v2.5.0-full-release.apk',
      '/WANAS-v2.4.0-universal-release.apk',
      '/WANAS.apk',
      '/api/apk/download',
      '/api/download-apk',
      '/download-apk',
    ],
    (req, res) => {
      const v32Path = path.join(__dirname, 'public', 'WANAS-v3.2.0-official.apk');
      const v31Path = path.join(__dirname, 'public', 'WANAS-v3.1.0-official.apk');
      const signedApkPath = path.join(__dirname, 'public', 'WANAS-v3.0.0-official.apk');
      const fallbackPath = path.join(__dirname, 'public', 'WANAS-v2.4.0-universal-release.apk');
      const targetPath = fs.existsSync(v32Path)
        ? v32Path
        : fs.existsSync(v31Path)
        ? v31Path
        : fs.existsSync(signedApkPath)
        ? signedApkPath
        : fallbackPath;

      if (fs.existsSync(targetPath)) {
        const stat = fs.statSync(targetPath);
        const dlName = req.path.includes('v3.1.0')
          ? 'WANAS-v3.1.0-official.apk'
          : req.path.includes('v3.0.0')
          ? 'WANAS-v3.0.0-official.apk'
          : 'WANAS-v3.2.0-official.apk';
        res.setHeader('Content-Type', 'application/vnd.android.package-archive');
        res.setHeader('Content-Disposition', `attachment; filename="${dlName}"`);
        res.setHeader('Content-Length', stat.size.toString());
        res.setHeader(
          'Cache-Control',
          'no-store, no-cache, must-revalidate, proxy-revalidate'
        );
        const stream = fs.createReadStream(targetPath);
        stream.pipe(res);
        return;
      }
      res.status(404).send('APK package not found');
    }
  );

  // Vite middleware in development or static serving in production
  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const PORT = Number(process.env.PORT) || 3000;
  server.listen(PORT, '0.0.0.0', () => {
    console.log(`WANAS server listening on http://0.0.0.0:${PORT}`);
  });

  const shutdown = async () => {
    await store.flush().catch(() => {});
    process.exit(0);
  };
  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}

startServer().catch((err) => {
  console.error('Fatal startup error:', err);
  process.exit(1);
});
